package com.denizgizem.rotam;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

final class RankingEngine {
    private RankingEngine() {}

    static int parseStartYear(String value) {
        if (value == null) return 0;
        String digits = value.replaceAll("[^0-9]", " ").trim();
        if (digits.isEmpty()) return 0;
        for (String part : digits.split("\\s+")) {
            if (part.length() == 4) {
                try {
                    int year = Integer.parseInt(part);
                    if (year >= 1000 && year <= 2100) return year;
                } catch (NumberFormatException ignored) {}
            }
        }
        return 0;
    }

    static Models.Category detectCategory(Models.Place p) {
        String natural = p.tag("natural");
        String leisure = p.tag("leisure");
        String amenity = p.tag("amenity");
        String historic = p.tag("historic");
        String tourism = p.tag("tourism");

        if ("beach".equals(natural) || "beach_resort".equals(leisure)) return Models.Category.BEACH;
        if (amenity.matches("restaurant|fast_food|food_court")) return Models.Category.FOOD;
        if (!historic.trim().isEmpty() || "archaeological_site".equals(p.tag("site")) ||
                "cave_entrance".equals(natural) || "museum".equals(tourism)) {
            return Models.Category.MYSTERY;
        }
        if (tourism.matches("guest_house|hostel|motel|camp_site|caravan_site|apartment|chalet")) {
            return Models.Category.LODGING;
        }
        return null;
    }

    static List<Models.Place> rank(Models.Category category, List<Models.Place> input, int limit) {
        return rank(category, input, limit, "");
    }

    static List<Models.Place> rank(Models.Category category, List<Models.Place> input, int limit, String foodPreferences) {
        List<Models.Place> list = new ArrayList<>();
        for (Models.Place p : input) {
            p.category = detectCategory(p);
            if (p.category != category) continue;
            score(p, category, foodPreferences);
            list.add(p);
        }

        if (category == Models.Category.FOOD) return rankFood(list, limit);

        list.sort(Comparator
                .comparingInt((Models.Place p) -> p.score).reversed()
                .thenComparingDouble(p -> p.distanceKm));
        return uniqueByName(list, limit);
    }

    static boolean hasVerifiedHeritage(Models.Place p) {
        return p != null && (p.startYear > 0 || p.has("wikipedia") || p.has("wikidata"));
    }

    private static List<Models.Place> rankFood(List<Models.Place> list, int limit) {
        List<Models.Place> independent = new ArrayList<>();
        for (Models.Place p : list) if (!isChain(p)) independent.add(p);
        if (independent.isEmpty()) return independent;

        List<Models.Place> verified = new ArrayList<>();
        for (Models.Place p : independent) if (hasVerifiedHeritage(p)) verified.add(p);

        List<Models.Place> output = new ArrayList<>();
        if (!verified.isEmpty()) {
            verified.sort((a, b) -> {
                boolean ay = a.startYear > 0;
                boolean by = b.startYear > 0;
                if (ay && by && a.startYear != b.startYear) return Integer.compare(a.startYear, b.startYear);
                if (ay != by) return ay ? -1 : 1;
                int tasteCompare = Integer.compare(b.tasteScore, a.tasteScore);
                if (tasteCompare != 0) return tasteCompare;
                int scoreCompare = Integer.compare(b.score, a.score);
                return scoreCompare != 0 ? scoreCompare : Double.compare(a.distanceKm, b.distanceKm);
            });
            output.add(verified.get(0));
        } else {
            independent.sort(Comparator
                    .comparingInt((Models.Place p) -> p.tasteScore).reversed()
                    .thenComparing(Comparator.comparingInt((Models.Place p) -> p.score).reversed())
                    .thenComparingDouble(p -> p.distanceKm));
            output.add(independent.get(0));
        }

        if (limit > 1) {
            List<Models.Place> economic = new ArrayList<>(independent);
            economic.sort(Comparator
                    .comparingInt((Models.Place p) -> p.economicScore).reversed()
                    .thenComparing(Comparator.comparingInt((Models.Place p) -> p.tasteScore).reversed())
                    .thenComparingDouble(p -> p.distanceKm));
            for (Models.Place candidate : economic) {
                if (!samePlace(output.get(0), candidate)) {
                    output.add(candidate);
                    break;
                }
            }
        }
        return output;
    }

    private static void score(Models.Place p, Models.Category category, String foodPreferences) {
        int score = 0;
        int economic = 0;
        String name = fold(p.name);
        String cuisine = fold(p.tag("cuisine"));

        if (p.has("wikipedia")) score += 70;
        if (p.has("wikidata")) score += 55;
        if (p.has("heritage")) score += 35;
        if (p.has("website")) score += 6;
        if (p.has("opening_hours")) score += 3;
        if (p.startYear > 0) score += Math.max(25, 100 - Math.max(0, p.startYear - 1850) / 2);
        score += Math.max(0, 22 - (int) Math.round(p.distanceKm));

        if (category == Models.Category.FOOD) {
            String combined = name + " " + cuisine + " " + fold(p.tag("description"));
            int taste = tasteScore(combined, foodPreferences);
            p.tasteScore = taste;
            score += taste;

            if (containsAny(combined, "lokanta", "esnaf", "aile", "kofte", "kebap", "kebab", "pide", "lahmacun", "ev yemek", "ocakbasi", "doner")) economic += 55;
            if (containsAny(cuisine, "turkish", "regional", "home_cooking")) economic += 20;
            if ("yes".equals(p.tag("takeaway"))) economic += 5;
            if (containsAny(combined, "fine dining", "lux", "luks", "resort", "chef", "steakhouse")) economic -= 80;
            if (p.has("brand") || p.has("brand:wikidata")) economic -= 40;
            economic += Math.max(0, 28 - (int) Math.round(p.distanceKm));
        } else if (category == Models.Category.MYSTERY) {
            if (!p.tag("historic").trim().isEmpty()) score += 45;
            if ("archaeological_site".equals(p.tag("historic")) || "archaeological_site".equals(p.tag("site"))) score += 55;
            if ("castle".equals(p.tag("historic")) || "ruins".equals(p.tag("historic"))) score += 35;
            if ("cave_entrance".equals(p.tag("natural"))) score += 35;
        } else if (category == Models.Category.LODGING) {
            String tourism = p.tag("tourism");
            if (tourism.matches("guest_house|hostel|motel")) score += 35;
            if (tourism.matches("camp_site|caravan_site")) score += 45;
            if (containsAny(name, "pansiyon", "apart", "motel", "kamp", "camp")) score += 25;
            if (containsAny(name, "resort", "spa", "lux", "luks", "palace")) score -= 100;
        } else if (category == Models.Category.BEACH) {
            if ("beach".equals(p.tag("natural"))) score += 45;
            if (p.has("surface")) score += 5;
        }

        p.score = score;
        p.economicScore = economic;
    }

    private static int tasteScore(String combined, String preferences) {
        String pref = fold(preferences);
        if (pref.trim().isEmpty()) pref = "kebap kofte pide ev yemekleri esnaf lokantasi";
        int score = 0;
        if (pref.contains("kebap") && containsAny(combined, "kebap", "kebab", "ocakbasi", "grill")) score += 55;
        if (pref.contains("kofte") && containsAny(combined, "kofte", "meatball")) score += 55;
        if (pref.contains("pide") && containsAny(combined, "pide", "lahmacun")) score += 50;
        if ((pref.contains("ev yemek") || pref.contains("esnaf") || pref.contains("lokanta")) &&
                containsAny(combined, "ev yemek", "home_cooking", "lokanta", "esnaf", "regional", "turkish")) score += 55;
        if ((pref.contains("balik") || pref.contains("deniz")) && containsAny(combined, "balik", "fish", "seafood")) score += 50;
        if (pref.contains("doner") && containsAny(combined, "doner", "döner")) score += 45;
        if (pref.contains("iskender") && combined.contains("iskender")) score += 55;
        if (pref.contains("corba") && containsAny(combined, "corba", "soup")) score += 40;
        return score;
    }

    private static boolean isChain(Models.Place p) {
        String name = fold(p.name);
        String chainTag = fold(p.tag("brand:wikidata") + " " + p.tag("branch") + " " + p.tag("network"));
        if (!chainTag.trim().isEmpty()) return true;
        return containsAny(name,
                "kofteci yusuf", "mcdonald", "burger king", "popeyes", "kfc", "domino", "pizza hut",
                "starbucks", "kahve dunyasi", "tavuk dunyasi", "baydoner", "hd iskender", "usta donerci",
                "arby", "subway", "bigchefs", "big chefs", "sbarro", "ustadonerci");
    }

    static String fold(String input) {
        if (input == null) return "";
        String s = input.toLowerCase(new Locale("tr", "TR"))
                .replace('ı', 'i').replace('ğ', 'g').replace('ü', 'u')
                .replace('ş', 's').replace('ö', 'o').replace('ç', 'c');
        return Normalizer.normalize(s, Normalizer.Form.NFD).replaceAll("\\p{M}", "");
    }

    private static boolean containsAny(String value, String... needles) {
        for (String needle : needles) if (value.contains(needle)) return true;
        return false;
    }

    private static List<Models.Place> uniqueByName(List<Models.Place> list, int limit) {
        List<Models.Place> out = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        for (Models.Place p : list) {
            String key = fold(p.name);
            if (key.trim().isEmpty() || seen.add(key)) out.add(p);
            if (out.size() >= limit) break;
        }
        return out;
    }

    private static boolean samePlace(Models.Place a, Models.Place b) {
        return fold(a.name).equals(fold(b.name)) ||
                (Math.abs(a.lat - b.lat) < 0.0001 && Math.abs(a.lon - b.lon) < 0.0001);
    }
}
