# Deniz ve Gizem Rotam V10.2

Bu sürüm, gerçek kullanım testinde görülen üç temel hatayı düzeltir.

## Düzeltilenler

1. **Aynı adlı yanlış bölge seçimi**
   - Örneğin yalnızca “Erdek” yazıldığında köy/mahalle yerine ilçe ve şehir türündeki sonuçlara öncelik verilir.
   - İl bilgisi yazılırsa kesin olarak dikkate alınır: `Erdek, Balıkesir`.
   - `Bursa, İznik` girişi otomatik olarak `İznik, Bursa` mantığıyla çözülür.

2. **Eski sonuç ekranda kalmıyor**
   - Yeni arama başlarken önceki yemek/plaj/gizem kartı anında temizlenir.
   - Arama sürerken başka butona basılamaz; sonuçların birbirine karışması engellenir.

3. **Köfteci Yusuf gibi zincirlerin “köklü/meşhur” gösterilmesi engellendi**
   - Bilinen ulusal zincirler yemek sonuçlarından çıkarılır.
   - “En eski” etiketi yalnızca kuruluş yılı açık kaynakta kayıtlıysa kullanılır.
   - Kuruluş yılı doğrulanamıyorsa uygulama bunu açıkça söyler ve damak tadına uygun yerel aday gösterir.

4. **Damak tadı alanı eklendi**
   - Varsayılan: kebap, köfte, pide, ev yemekleri, esnaf lokantası.
   - Kullanıcı alanı değiştirerek balık, çorba, döner gibi tercihleri ekleyebilir.

5. **Arama süresi kısaltıldı**
   - Gereksiz geniş veri sorguları azaltıldı.
   - Canlı veri kaynağı gecikirse uzun süre sonsuz beklemek yerine hata mesajı gösterilir.

## Sürüm

- versionCode: 12
- versionName: 10.2
- Paket adı: `com.denizgizem.rotam`
- Önceki V10.1 ile aynı imza anahtarı kullanılır; üzerine güncelleme yapılabilir.
