# Deniz ve Gizem Rotam V10.6

Bu sürüm V10.5 üzerine efsane, rivayet, söylence ve halk inanışı araştırmasını ekler.

- Plaj, tarih/gizem ve ekonomik konaklama sonuçları seçilen bölgenin mesafe sınırı içinde topluca gösterilir.
- Yemekte en fazla iki köklü/meşhur yer gösterilir.
- Tarih/gizem kartlarında kaynak bulunursa tarihsel bilgi ile efsane/rivayet ayrı başlıklarla gösterilir.
- Ayrıca bölgeye ait kaynaklı efsane ve rivayetler ayrı bir bölümde listelenir.
- Anlatı bir tarihsel gerçek gibi sunulmaz; güven durumu ve kaynak adı açıkça yazılır.
- Kaynak bulunamazsa uygulama efsane veya söylenti uydurmaz.
- Google arama sayfasına, haritaya veya tarayıcıya yönlendirme yoktur.
- Paket adı ve kalıcı imza V10.5 ile aynıdır; APK güncelleme olarak kurulabilir.
