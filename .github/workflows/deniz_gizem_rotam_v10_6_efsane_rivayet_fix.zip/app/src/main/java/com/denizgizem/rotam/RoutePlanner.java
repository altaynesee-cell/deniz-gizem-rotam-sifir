package com.denizgizem.rotam;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

final class RoutePlanner {
    interface ProgressCallback {
        void onProgress(int completed, int total);
    }

    private final DataRepository repository;

    RoutePlanner(DataRepository repository) {
        this.repository = repository;
    }

    Models.RouteResult build(String startText, String endText, int days, ProgressCallback progress) throws Exception {
        int safeDays = Math.max(1, Math.min(days, 10));
        Models.GeoPoint start = repository.geocode(startText);
        Thread.sleep(1100L);
        Models.GeoPoint end = repository.geocode(endText);
        JSONObject route = repository.route(start, end);
        double totalKm = route.optDouble("distance", 0) / 1000.0;
        JSONArray coordinates = route.getJSONObject("geometry").getJSONArray("coordinates");

        List<Models.DayPlan> plans = new ArrayList<>();
        for (int day = 1; day <= safeDays; day++) {
            int index = safeDays == 1
                    ? coordinates.length() - 1
                    : (int) Math.round((coordinates.length() - 1) * (day / (double) safeDays));
            JSONArray pair = coordinates.getJSONArray(Math.max(0, Math.min(index, coordinates.length() - 1)));
            Models.GeoPoint point = new Models.GeoPoint(pair.getDouble(1), pair.getDouble(0), "Gün " + day + " durağı");
            List<Models.Place> nearby = repository.queryBundle(point, 25);
            Models.Place beach = first(RankingEngine.rank(Models.Category.BEACH, nearby, 1));
            Models.Place food = first(RankingEngine.rank(Models.Category.FOOD, nearby, 1));
            Models.Place mystery = first(RankingEngine.rank(Models.Category.MYSTERY, nearby, 1));
            Models.Place lodging = first(RankingEngine.rank(Models.Category.LODGING, nearby, 1));
            plans.add(new Models.DayPlan(day, point, beach, food, mystery, lodging));
            if (progress != null) progress.onProgress(day, safeDays);
        }
        return new Models.RouteResult(start, end, totalKm, plans);
    }

    private Models.Place first(List<Models.Place> list) {
        return list.isEmpty() ? null : list.get(0);
    }
}
