package com.denizgizem.rotam;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

final class DataRepository {
    interface ResultCallback<T> {
        void onSuccess(T value);
        void onError(String message);
    }

    private static final String USER_AGENT = "DenizGizemRotam/10.0 (personal travel research app)";
    private static final String[] OVERPASS_ENDPOINTS = {
            "https://overpass-api.de/api/interpreter",
            "https://overpass.kumi.systems/api/interpreter"
    };

    Models.GeoPoint geocode(String rawQuery) throws Exception {
        List<String> attempts = locationAttempts(rawQuery);
        for (String query : attempts) {
            String encoded = URLEncoder.encode(query, StandardCharsets.UTF_8.name());
            String url = "https://nominatim.openstreetmap.org/search?format=jsonv2&limit=1&countrycodes=tr&addressdetails=1&q=" + encoded;
            JSONArray array = new JSONArray(get(url));
            if (array.length() > 0) {
                JSONObject obj = array.getJSONObject(0);
                return new Models.GeoPoint(
                        Double.parseDouble(obj.getString("lat")),
                        Double.parseDouble(obj.getString("lon")),
                        obj.optString("display_name", query)
                );
            }
            Thread.sleep(1100L);
        }
        throw new IllegalArgumentException("Yazdığınız bölge Türkiye içinde bulunamadı. İl ve ilçeyi birlikte yazın.");
    }

    Models.SearchResult search(Models.Category category, String locationText, int radiusKm) throws Exception {
        Models.GeoPoint center = geocode(locationText);
        List<Models.Place> raw = queryCategory(center, category, radiusKm);
        List<Models.Place> ranked = RankingEngine.rank(category, raw, 2);
        String note = ranked.isEmpty()
                ? "Belirlenen " + radiusKm + " km sınırında uygun sonuç bulunamadı. Başka şehirden sonuç gösterilmedi."
                : "Sonuçlar yalnızca seçilen merkezin " + radiusKm + " km çevresinden getirildi.";
        return new Models.SearchResult(center, ranked, note);
    }

    List<Models.Place> queryCategory(Models.GeoPoint center, Models.Category category, int radiusKm) throws Exception {
        int radiusM = radiusKm * 1000;
        String selectors;
        switch (category) {
            case BEACH:
                selectors = "nwr(around:" + radiusM + "," + center.lat + "," + center.lon + ")[\"natural\"=\"beach\"];" +
                        "nwr(around:" + radiusM + "," + center.lat + "," + center.lon + ")[\"leisure\"=\"beach_resort\"];";
                break;
            case FOOD:
                selectors = "nwr(around:" + radiusM + "," + center.lat + "," + center.lon + ")[\"amenity\"~\"restaurant|fast_food|food_court\"];";
                break;
            case MYSTERY:
                selectors = "nwr(around:" + radiusM + "," + center.lat + "," + center.lon + ")[\"historic\"];" +
                        "nwr(around:" + radiusM + "," + center.lat + "," + center.lon + ")[\"site\"=\"archaeological_site\"];" +
                        "nwr(around:" + radiusM + "," + center.lat + "," + center.lon + ")[\"natural\"=\"cave_entrance\"];" +
                        "nwr(around:" + radiusM + "," + center.lat + "," + center.lon + ")[\"tourism\"~\"attraction|museum\"];";
                break;
            case LODGING:
                selectors = "nwr(around:" + radiusM + "," + center.lat + "," + center.lon + ")[\"tourism\"~\"guest_house|hostel|motel|camp_site|caravan_site|apartment|chalet\"];";
                break;
            default:
                throw new IllegalArgumentException("Geçersiz kategori");
        }
        String query = "[out:json][timeout:30];(" + selectors + ");out center tags;";
        return parsePlaces(overpass(query), center, radiusKm);
    }

    List<Models.Place> queryBundle(Models.GeoPoint center, int radiusKm) throws Exception {
        int r = radiusKm * 1000;
        String around = "(around:" + r + "," + center.lat + "," + center.lon + ")";
        String query = "[out:json][timeout:35];(" +
                "nwr" + around + "[\"natural\"=\"beach\"];" +
                "nwr" + around + "[\"amenity\"~\"restaurant|fast_food|food_court\"];" +
                "nwr" + around + "[\"historic\"];" +
                "nwr" + around + "[\"site\"=\"archaeological_site\"];" +
                "nwr" + around + "[\"natural\"=\"cave_entrance\"];" +
                "nwr" + around + "[\"tourism\"~\"guest_house|hostel|motel|camp_site|caravan_site|apartment|chalet\"];" +
                ");out center tags;";
        return parsePlaces(overpass(query), center, radiusKm);
    }

    JSONObject route(Models.GeoPoint start, Models.GeoPoint end) throws Exception {
        String url = String.format(Locale.US,
                "https://router.project-osrm.org/route/v1/driving/%.6f,%.6f;%.6f,%.6f?overview=full&geometries=geojson&steps=false",
                start.lon, start.lat, end.lon, end.lat);
        JSONObject root = new JSONObject(get(url));
        if (!"Ok".equalsIgnoreCase(root.optString("code"))) {
            throw new IllegalStateException("Araç rotası oluşturulamadı.");
        }
        return root.getJSONArray("routes").getJSONObject(0);
    }

    private String overpass(String query) throws Exception {
        Exception last = null;
        for (String endpoint : OVERPASS_ENDPOINTS) {
            try {
                return postForm(endpoint, "data=" + URLEncoder.encode(query, StandardCharsets.UTF_8.name()));
            } catch (Exception ex) {
                last = ex;
            }
        }
        throw new IllegalStateException("Canlı yer verisine şu anda ulaşılamadı.", last);
    }

    private List<Models.Place> parsePlaces(String json, Models.GeoPoint center, int radiusKm) throws Exception {
        JSONArray elements = new JSONObject(json).optJSONArray("elements");
        List<Models.Place> out = new ArrayList<>();
        if (elements == null) return out;

        for (int i = 0; i < elements.length(); i++) {
            JSONObject e = elements.getJSONObject(i);
            JSONObject tagsObj = e.optJSONObject("tags");
            if (tagsObj == null) continue;
            String name = firstNonBlank(
                    tagsObj.optString("name:tr"),
                    tagsObj.optString("name"),
                    tagsObj.optString("official_name")
            );
            if (name.trim().isEmpty()) continue;

            double lat;
            double lon;
            if (e.has("lat") && e.has("lon")) {
                lat = e.getDouble("lat");
                lon = e.getDouble("lon");
            } else {
                JSONObject c = e.optJSONObject("center");
                if (c == null) continue;
                lat = c.getDouble("lat");
                lon = c.getDouble("lon");
            }

            double distance = haversine(center.lat, center.lon, lat, lon);
            if (distance > radiusKm + 0.25) continue;

            Map<String, String> tags = new HashMap<>();
            for (String key : tagsObj.keySet()) tags.put(key, tagsObj.optString(key, ""));
            out.add(new Models.Place(name, lat, lon, distance, tags));
        }
        return out;
    }

    private List<String> locationAttempts(String raw) {
        String clean = raw == null ? "" : raw.trim().replaceAll("\\s+", " ");
        if (clean.trim().isEmpty()) throw new IllegalArgumentException("Önce il veya ilçe yazın.");
        List<String> attempts = new ArrayList<>();
        attempts.add(clean);
        String simplified = clean.replaceAll("(?i)\\b(adası|adasi|bölgesi|bolgesi|merkez|civarı|civari)\\b", " ")
                .replaceAll("\\s+", " ").trim();
        if (!simplified.equalsIgnoreCase(clean) && !simplified.trim().isEmpty()) attempts.add(simplified);
        if (!RankingEngine.fold(clean).contains("turkiye")) attempts.add(simplified + ", Türkiye");
        return attempts;
    }

    private String get(String urlText) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(urlText).openConnection();
        c.setRequestMethod("GET");
        c.setConnectTimeout(15000);
        c.setReadTimeout(25000);
        c.setRequestProperty("User-Agent", USER_AGENT);
        c.setRequestProperty("Accept", "application/json");
        return readResponse(c);
    }

    private String postForm(String urlText, String body) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(urlText).openConnection();
        c.setRequestMethod("POST");
        c.setDoOutput(true);
        c.setConnectTimeout(18000);
        c.setReadTimeout(45000);
        c.setRequestProperty("User-Agent", USER_AGENT);
        c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
        c.setFixedLengthStreamingMode(bytes.length);
        try (OutputStream os = c.getOutputStream()) { os.write(bytes); }
        return readResponse(c);
    }

    private String readResponse(HttpURLConnection c) throws Exception {
        int code = c.getResponseCode();
        InputStream stream = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
        StringBuilder sb = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) sb.append(line);
        } finally {
            c.disconnect();
        }
        if (code < 200 || code >= 300) throw new IllegalStateException("Sunucu yanıtı: " + code);
        return sb.toString();
    }

    static double haversine(double lat1, double lon1, double lat2, double lon2) {
        double r = 6371.0088;
        double dLat = Math.toRadians(lat2 - lat1);
        double dLon = Math.toRadians(lon2 - lon1);
        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) *
                        Math.sin(dLon / 2) * Math.sin(dLon / 2);
        return 2 * r * Math.asin(Math.sqrt(a));
    }

    private String firstNonBlank(String... values) {
        for (String value : values) if (value != null && !value.trim().isEmpty()) return value;
        return "";
    }
}
