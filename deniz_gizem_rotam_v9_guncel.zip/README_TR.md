# Deniz ve Gizem Rotam V9

Bu sürüm sabit örnek yerler kullanmaz. Kullanıcının yazdığı bölgeyi canlı olarak çözer ve yalnızca seçilen yarıçap içindeki sonuçları uygulama ekranında gösterir.

## V9 özellikleri

- Katı bölge filtresi: İznik yazıldığında Erdek veya Marmaris sonucu gelmez.
- Yakında sonuç yoksa uzak şehirden örnek göstermez.
- Plaj, yemek, tarih-gizem ve ekonomik konaklama için en fazla iki öneri.
- Yemekte ilk kart: doğrulanabilen en eski veya en köklü/meşhur aday.
- Yemekte ikinci kart: esnaf lokantası, aile lokantası, kebap, pide, köfte ve benzeri ekonomik alternatif.
- Meşhur işletmenin ekonomik olması şart değildir.
- Lüks otel, resort ve spa konaklama sonuçları filtre dışında tutulur.
- Google arama sayfasına yönlendirme yoktur.
- 1–10 günlük araç rotası; yol üzerindeki günlük noktalarda plaj, yemek, tarih-gizem ve konaklama taraması.
- Sabit paket adı: `com.denizgizem.rotam`
- Sürüm: `versionCode 9`, `versionName 9.0`
- Sabit imza anahtarı: Bundan sonraki V9 tabanlı sürümler eskisini silmeden güncellenebilir.

## Önemli: İlk V9 kurulumu

Eski APK farklı bir debug anahtarıyla imzalandıysa Android ilk V9 kurulumunda imza uyuşmazlığı verir. Bu durumda eski uygulama **bir kez** kaldırılmalıdır. V9 kurulduktan sonra `release-key.jks` korunursa sonraki sürümler üzerine güncellenir.

`app/release-key.jks` dosyasını silmeyin ve yedekleyin. Repo herkese açıksa bu anahtarı yayımlamak güvenli değildir; mümkünse depoyu private yapın.

## Veri kaynakları

- OpenStreetMap / Overpass: Yer ve işletme kayıtları
- Nominatim: Bölge çözümleme
- OSRM: Araç rotası

Fiyat verisi açık kaynakta kesin değilse uygulama rakam uydurmaz. “Ekonomik alternatif” seçimi işletme türü ve yerel yemek etiketlerine göre yapılır.
