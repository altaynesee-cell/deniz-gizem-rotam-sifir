package com.altayaytin.denizgizemrotamsifir

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BeachAccess
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Hotel
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            DenizGizemTheme {
                DenizGizemApp()
            }
        }
    }
}

private val AppColors: ColorScheme = darkColorScheme(
    primary = Color(0xFF8ED6F1),
    onPrimary = Color(0xFF06202A),
    secondary = Color(0xFFE7C97D),
    background = Color(0xFF15171B),
    surface = Color(0xFF20252A),
    surfaceVariant = Color(0xFF293138),
    onBackground = Color(0xFFF1F2F4),
    onSurface = Color(0xFFF1F2F4),
    onSurfaceVariant = Color(0xFFD6DCE1),
    error = Color(0xFFFFB4AB)
)

@Composable
private fun DenizGizemTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = AppColors, content = content)
}

private enum class ExploreTab(val label: String) {
    OVERVIEW("Özet"),
    SEA("Deniz"),
    FOOD("Lezzet"),
    DISCOVER("Keşfet"),
    STAY("Konak")
}

private data class DestinationResults(
    val center: GeoPoint,
    val beaches: List<PlaceItem> = emptyList(),
    val localFlavors: List<PlaceItem> = emptyList(),
    val rootedFood: List<PlaceItem> = emptyList(),
    val foodAlternatives: List<PlaceItem> = emptyList(),
    val sights: List<PlaceItem> = emptyList(),
    val ancient: List<PlaceItem> = emptyList(),
    val cavesAndCastles: List<PlaceItem> = emptyList(),
    val legends: List<PlaceItem> = emptyList(),
    val stays: List<PlaceItem> = emptyList()
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ApiKeySetupScreen(onSaved: (String) -> Unit) {
    var key by rememberSaveable { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                ScreenHeader(
                    title = "Deniz & Gizem Gezi Asistanı",
                    subtitle = "Canlı yer araması için Geoapify anahtarını bir kez kaydet. Anahtar yalnız bu telefonda tutulur."
                )
            }
            item {
                ElevatedCard {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text("Geoapify API anahtarı", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        OutlinedTextField(
                            value = key,
                            onValueChange = {
                                key = it.trim()
                                error = null
                            },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("API anahtarını yapıştır") },
                            singleLine = true,
                            visualTransformation = PasswordVisualTransformation(),
                            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                                keyboardType = KeyboardType.Password,
                                imeAction = ImeAction.Done
                            )
                        )
                        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                        Button(
                            onClick = {
                                val cleaned = key.trim()
                                if (cleaned.length < 20 || cleaned.any { it.isWhitespace() }) {
                                    error = "Anahtar eksik görünüyor."
                                } else {
                                    onSaved(cleaned)
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("KAYDET VE AÇ")
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DenizGizemApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var apiKey by rememberSaveable { mutableStateOf(ApiKeyStore.load(context)) }
    if (apiKey.isBlank()) {
        ApiKeySetupScreen { savedKey ->
            ApiKeyStore.save(context, savedKey)
            ApiService.configureGeoapifyApiKey(savedKey)
            apiKey = savedKey
        }
        return
    }
    ApiService.configureGeoapifyApiKey(apiKey)

    var query by rememberSaveable { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var results by remember { mutableStateOf<DestinationResults?>(null) }
    var selectedTab by rememberSaveable { mutableStateOf(ExploreTab.OVERVIEW) }

    fun loadDestination(center: GeoPoint) {
        loading = true
        error = null
        scope.launch {
            runCatching { fetchDestination(center) }
                .onSuccess {
                    results = it
                    query = it.center.name
                    selectedTab = ExploreTab.OVERVIEW
                }
                .onFailure { error = it.userMessage() }
            loading = false
        }
    }

    fun searchDestination() {
        val cleaned = query.trim()
        if (cleaned.isBlank()) {
            error = "Gideceğin yeri yaz. Örnek: Çeşme, Kaş, Ayvalık, Didim."
            return
        }
        loading = true
        error = null
        scope.launch {
            runCatching { ApiService.geocode(cleaned) }
                .onSuccess { center ->
                    runCatching { fetchDestination(center) }
                        .onSuccess {
                            results = it
                            query = it.center.name
                            selectedTab = ExploreTab.OVERVIEW
                        }
                        .onFailure { error = it.userMessage() }
                }
                .onFailure { error = it.userMessage() }
            loading = false
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        if (grants.values.any { it }) {
            loading = true
            scope.launch {
                runCatching { LocationHelper.currentPoint(context) }
                    .onSuccess { loadDestination(it) }
                    .onFailure {
                        loading = false
                        error = it.userMessage()
                    }
            }
        } else {
            error = "Konum izni verilmedi. Gideceğin yeri kutuya yazarak kullanabilirsin."
        }
    }

    Scaffold(
        bottomBar = {
            NavigationBar {
                ExploreTab.entries.forEach { tab ->
                    NavigationBarItem(
                        selected = selectedTab == tab,
                        onClick = { selectedTab = tab },
                        icon = {
                            Icon(
                                imageVector = when (tab) {
                                    ExploreTab.OVERVIEW -> Icons.Default.Place
                                    ExploreTab.SEA -> Icons.Default.BeachAccess
                                    ExploreTab.FOOD -> Icons.Default.Restaurant
                                    ExploreTab.DISCOVER -> Icons.Default.Explore
                                    ExploreTab.STAY -> Icons.Default.Hotel
                                },
                                contentDescription = tab.label
                            )
                        },
                        label = { Text(tab.label, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Clip) }
                    )
                }
            }
        }
    ) { innerPadding ->
        Surface(
            modifier = Modifier.fillMaxSize().padding(innerPadding),
            color = MaterialTheme.colorScheme.background
        ) {
            when {
                results == null -> DestinationSearchScreen(
                    query = query,
                    onQueryChanged = { query = it },
                    loading = loading,
                    error = error,
                    onSearch = ::searchDestination,
                    onUseLocation = {
                        error = null
                        if (LocationHelper.hasPermission(context)) {
                            loading = true
                            scope.launch {
                                runCatching { LocationHelper.currentPoint(context) }
                                    .onSuccess { loadDestination(it) }
                                    .onFailure {
                                        loading = false
                                        error = it.userMessage()
                                    }
                            }
                        } else {
                            permissionLauncher.launch(
                                arrayOf(
                                    Manifest.permission.ACCESS_FINE_LOCATION,
                                    Manifest.permission.ACCESS_COARSE_LOCATION
                                )
                            )
                        }
                    },
                    onResetApiKey = {
                        ApiKeyStore.clear(context)
                        apiKey = ""
                    }
                )

                else -> DestinationResultsScreen(
                    data = results!!,
                    selectedTab = selectedTab,
                    query = query,
                    onQueryChanged = { query = it },
                    loading = loading,
                    error = error,
                    onSearch = ::searchDestination,
                    onTabChanged = { selectedTab = it },
                    onMap = { place -> openMap(context, place.latitude, place.longitude, place.name) }
                )
            }
        }
    }
}

private suspend fun fetchDestination(center: GeoPoint): DestinationResults = coroutineScope {
    val beachesDeferred = async { runCatching { ApiService.searchPlaces(center, PoiCategory.BEACH) }.getOrDefault(emptyList()) }
    val allFoodDeferred = async { runCatching { ApiService.searchFoodSearch(center, FoodKind.ALL) }.getOrNull() }
    val kofteDeferred = async { runCatching { ApiService.searchFoodSearch(center, FoodKind.KOFTE) }.getOrNull() }
    val pideDeferred = async { runCatching { ApiService.searchFoodSearch(center, FoodKind.PIDE) }.getOrNull() }
    val kebabDeferred = async { runCatching { ApiService.searchFoodSearch(center, FoodKind.KEBAB) }.getOrNull() }
    val sightsDeferred = async { runCatching { ApiService.searchGeneralSights(center) }.getOrDefault(emptyList()) }
    val ancientDeferred = async { runCatching { ApiService.searchDiscoveryPlaces(center, DiscoveryKind.ANCIENT) }.getOrDefault(emptyList()) }
    val caveDeferred = async { runCatching { ApiService.searchDiscoveryPlaces(center, DiscoveryKind.FORTRESS_CAVE) }.getOrDefault(emptyList()) }
    val legendaryDeferred = async { runCatching { ApiService.searchDiscoveryPlaces(center, DiscoveryKind.LEGENDARY) }.getOrDefault(emptyList()) }
    val legendArticleDeferred = async { runCatching { ApiService.searchLegendArticles(center) }.getOrDefault(emptyList()) }
    val flavorArticleDeferred = async { runCatching { ApiService.searchLocalFlavorArticles(center) }.getOrDefault(emptyList()) }
    val stayDeferred = async { runCatching { ApiService.searchPlaces(center, PoiCategory.STAY) }.getOrDefault(emptyList()) }

    val beaches = beachesDeferred.await().sortedBy { beachPreferenceScore(it) }.take(12)
    val allFood = allFoodDeferred.await()
    val kofteFood = kofteDeferred.await()
    val pideFood = pideDeferred.await()
    val kebabFood = kebabDeferred.await()
    val rooted = listOfNotNull(kofteFood, pideFood, kebabFood)
        .flatMap { it.featured }
        .distinctBy { placeKey(it) }
        .take(8)
    val alternatives = (
        allFood?.featured.orEmpty() +
            allFood?.alternatives.orEmpty() +
            listOfNotNull(kofteFood, pideFood, kebabFood).flatMap { it.alternatives }
        )
        .distinctBy { placeKey(it) }
        .filterNot { candidate -> rooted.any { placeKey(it) == placeKey(candidate) } }
        .take(12)

    val localFlavor = (SpecialCatalog.localFlavorResults(center) + flavorArticleDeferred.await())
        .distinctBy { placeKey(it) }
        .take(8)
    val legends = (
        SpecialCatalog.legendResults(center) +
            legendaryDeferred.await() +
            legendArticleDeferred.await()
        )
        .distinctBy { placeKey(it) }
        .take(16)

    DestinationResults(
        center = center,
        beaches = beaches,
        localFlavors = localFlavor,
        rootedFood = rooted,
        foodAlternatives = alternatives,
        sights = sightsDeferred.await().distinctBy { placeKey(it) }.take(18),
        ancient = ancientDeferred.await().distinctBy { placeKey(it) }.take(16),
        cavesAndCastles = caveDeferred.await().distinctBy { placeKey(it) }.take(16),
        legends = legends,
        stays = stayDeferred.await().distinctBy { placeKey(it) }.take(16)
    )
}

private fun placeKey(place: PlaceItem): String = (place.mapSearchQuery ?: place.webSearchQuery ?: place.name).lowercase()

private fun beachPreferenceScore(place: PlaceItem): Int {
    val text = (place.name + " " + place.subtitle + " " + place.note.orEmpty() + " " + place.details.joinToString(" ")).lowercase()
    var score = 100
    if ("kum" in text || "sandy" in text) score -= 35
    if ("sığ" in text || "sig" in text || "shallow" in text) score -= 35
    if ("sakin" in text || "korunaklı" in text || "dalga" in text && "düşük" in text) score -= 20
    if ("çakıl" in text || "cakil" in text || "kayalık" in text || "kayalik" in text) score += 25
    score += place.priority.coerceIn(-20, 40)
    return score
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DestinationSearchScreen(
    query: String,
    onQueryChanged: (String) -> Unit,
    loading: Boolean,
    error: String?,
    onSearch: () -> Unit,
    onUseLocation: () -> Unit,
    onResetApiKey: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            ScreenHeader(
                title = "Deniz & Gizem Gezi Asistanı",
                subtitle = "10 günlük rota yok. Gideceğin yeri yaz; plaj, lezzet, tarih-gizem ve uygun konaklama tek seferde gelsin."
            )
        }
        item {
            ElevatedCard {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("Nereye gidiyorsun?", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    OutlinedTextField(
                        value = query,
                        onValueChange = onQueryChanged,
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Örnek: Alaçatı, Didim, Kaş, Ayvalık") },
                        singleLine = true
                    )
                    Button(onClick = onSearch, enabled = !loading, modifier = Modifier.fillMaxWidth()) {
                        if (loading) {
                            CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                            Spacer(Modifier.width(8.dp))
                            Text("Araştırılıyor…")
                        } else {
                            Icon(Icons.Default.Search, null)
                            Spacer(Modifier.width(8.dp))
                            Text("BÖLGEYİ ARAŞTIR")
                        }
                    }
                    OutlinedButton(onClick = onUseLocation, enabled = !loading, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.LocationOn, null)
                        Spacer(Modifier.width(8.dp))
                        Text("ŞU ANKİ KONUMUMU KULLAN")
                    }
                }
            }
        }
        item {
            InfoCard("Uygulama sığ-kumlu plajları öne alır; yöresel yemekleri, doğrulanmış köklü işletmeleri, antik kentleri, efsane/gizem noktalarını ve ekonomik pansiyon-apart-kamp seçeneklerini ayrı gösterir.")
        }
        error?.let { item { ErrorCard(it) } }
        item {
            TextButton(onClick = onResetApiKey) { Text("Geoapify anahtarını değiştir") }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DestinationResultsScreen(
    data: DestinationResults,
    selectedTab: ExploreTab,
    query: String,
    onQueryChanged: (String) -> Unit,
    loading: Boolean,
    error: String?,
    onSearch: () -> Unit,
    onTabChanged: (ExploreTab) -> Unit,
    onMap: (PlaceItem) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            ScreenHeader(
                title = data.center.name,
                subtitle = "Bölge rehberi • plaj • lezzet • tarih & gizem • konaklama"
            )
        }
        item {
            ElevatedCard {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = query,
                        onValueChange = onQueryChanged,
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Başka bir yer yaz") },
                        singleLine = true
                    )
                    Button(onClick = onSearch, enabled = !loading, modifier = Modifier.fillMaxWidth()) {
                        if (loading) {
                            CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                            Spacer(Modifier.width(8.dp))
                            Text("Araştırılıyor…")
                        } else {
                            Icon(Icons.Default.Search, null)
                            Spacer(Modifier.width(8.dp))
                            Text("YENİDEN ARA")
                        }
                    }
                }
            }
        }
        error?.let { item { ErrorCard(it) } }

        if (selectedTab == ExploreTab.OVERVIEW) {
            item {
                SummaryCard(data, onTabChanged)
            }
            item { SectionTitle("İlk bakışta öne çıkanlar", "Her kategoriden kısa seçki") }
            items(data.beaches.take(2)) { PlaceCard(it, onMap) }
            items(data.rootedFood.take(2)) { PlaceCard(it, onMap) }
            items(data.sights.take(2)) { PlaceCard(it, onMap) }
            items(data.ancient.take(2)) { PlaceCard(it, onMap) }
            items(data.legends.take(2)) { PlaceCard(it, onMap) }
            items(data.stays.take(2)) { PlaceCard(it, onMap) }
        }

        if (selectedTab == ExploreTab.SEA) {
            item {
                SectionTitle(
                    "Sığ & kumlu plajlar",
                    "Kum, sığlık ve korunaklı/sakin kıyı bilgisi bulunan yerler öne alınır."
                )
            }
            if (data.beaches.isEmpty()) item { EmptyCard("Bu bölgede doğrulanabilir plaj sonucu bulunamadı.") }
            items(data.beaches, key = { "beach-${placeKey(it)}" }) { PlaceCard(it, onMap) }
        }

        if (selectedTab == ExploreTab.FOOD) {
            item { SectionTitle("Yörenin meşhur lezzetleri", "Önce ne yenir; sonra nerede yenir.") }
            if (data.localFlavors.isEmpty()) item { EmptyCard("Bölgeye özel yöresel lezzet kaydı bulunamadı.") }
            items(data.localFlavors, key = { "flavor-${placeKey(it)}" }) { PlaceCard(it, onMap) }

            item { SectionTitle("En eski / köklü işletmeler", "Kuruluş yılı ve tarihçesi doğrulanmış kayıtlar varsa burada görünür.") }
            if (data.rootedFood.isEmpty()) item { EmptyCard("Bu bölge için kuruluş yılı doğrulanmış köklü köfteci/pideci/kebapçı kaydı henüz yok.") }
            items(data.rootedFood, key = { "rooted-${placeKey(it)}" }) { PlaceCard(it, onMap) }

            item { SectionTitle("Yakın ekonomik alternatifler", "Popülerlik, köklülük anlamına gelmez; bunlar yakın seçeneklerdir.") }
            if (data.foodAlternatives.isEmpty()) item { EmptyCard("Yakın yemek alternatifi bulunamadı.") }
            items(data.foodAlternatives, key = { "food-${placeKey(it)}" }) { PlaceCard(it, onMap) }
        }

        if (selectedTab == ExploreTab.DISCOVER) {
            item { SectionTitle("Gezilecek yerler", "Bölgedeki önemli tarihî ve turistik duraklar") }
            if (data.sights.isEmpty()) item { EmptyCard("Yakında gezilecek yer sonucu bulunamadı.") }
            items(data.sights, key = { "sight-${placeKey(it)}" }) { PlaceCard(it, onMap) }

            item { SectionTitle("Antik kentler & arkeolojik yerler", "Ören yeri, höyük, nekropol, tapınak ve antik kalıntılar") }
            if (data.ancient.isEmpty()) item { EmptyCard("Yakında antik/arkeolojik sonuç bulunamadı.") }
            items(data.ancient, key = { "ancient-${placeKey(it)}" }) { PlaceCard(it, onMap) }

            item { SectionTitle("Kale, mağara & yeraltı", "Kaleler, mağaralar, tüneller ve sıra dışı keşif noktaları") }
            if (data.cavesAndCastles.isEmpty()) item { EmptyCard("Yakında kale/mağara/yeraltı sonucu bulunamadı.") }
            items(data.cavesAndCastles, key = { "cave-${placeKey(it)}" }) { PlaceCard(it, onMap) }

            item { SectionTitle("Efsaneler & gizemli yerler", "Yerel rivayet, mitoloji ve modern söylentiler ayrı notlarla gösterilir.") }
            if (data.legends.isEmpty()) item { EmptyCard("Bölgeyle doğrudan eşleşen efsane veya gizem kaydı bulunamadı.") }
            items(data.legends, key = { "legend-${placeKey(it)}" }) { PlaceCard(it, onMap) }
        }

        if (selectedTab == ExploreTab.STAY) {
            item {
                SectionTitle(
                    "Uygun konaklama",
                    "Pansiyon, apart, kamp ve daha ekonomik seçenekler önceliklidir. Canlı fiyat olmadığı yerde uygulama kesin ücret uydurmaz."
                )
            }
            if (data.stays.isEmpty()) item { EmptyCard("Bu bölgede uygun konaklama sonucu bulunamadı.") }
            items(data.stays, key = { "stay-${placeKey(it)}" }) { PlaceCard(it, onMap) }
        }
    }
}

@Composable
private fun SummaryCard(data: DestinationResults, onTabChanged: (ExploreTab) -> Unit) {
    ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("${data.center.name} için hazır", fontSize = 21.sp, fontWeight = FontWeight.Bold)
            Text("İstediğin başlığa dokunup tüm sonuçları görebilirsin.", fontSize = 13.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                FilterChip(
                    selected = false,
                    onClick = { onTabChanged(ExploreTab.SEA) },
                    label = { Text("Plaj ${data.beaches.size}") },
                    leadingIcon = { Icon(Icons.Default.BeachAccess, null, Modifier.size(18.dp)) }
                )
                FilterChip(
                    selected = false,
                    onClick = { onTabChanged(ExploreTab.FOOD) },
                    label = { Text("Lezzet") },
                    leadingIcon = { Icon(Icons.Default.Restaurant, null, Modifier.size(18.dp)) }
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                FilterChip(
                    selected = false,
                    onClick = { onTabChanged(ExploreTab.DISCOVER) },
                    label = { Text("Keşfet") },
                    leadingIcon = { Icon(Icons.Default.Explore, null, Modifier.size(18.dp)) }
                )
                FilterChip(
                    selected = false,
                    onClick = { onTabChanged(ExploreTab.STAY) },
                    label = { Text("Konak ${data.stays.size}") },
                    leadingIcon = { Icon(Icons.Default.Hotel, null, Modifier.size(18.dp)) }
                )
            }
        }
    }
}

@Composable
private fun PlaceCard(place: PlaceItem, onMap: (PlaceItem) -> Unit) {
    ElevatedCard {
        Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text(place.name, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            if (place.subtitle.isNotBlank()) {
                Text(place.subtitle, fontSize = 13.sp, color = MaterialTheme.colorScheme.secondary)
            }
            place.note?.takeIf { it.isNotBlank() }?.let { Text(it, fontSize = 13.sp) }
            place.details.take(8).forEach { detail ->
                if (detail.isNotBlank()) Text("• $detail", fontSize = 12.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (!place.isSearchCard && place.latitude != 0.0 && place.longitude != 0.0) {
                OutlinedButton(onClick = { onMap(place) }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Map, null)
                    Spacer(Modifier.width(8.dp))
                    Text("HARİTADA AÇ")
                }
            }
        }
    }
}

@Composable
private fun ScreenHeader(title: String, subtitle: String) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(title, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text(subtitle, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun SectionTitle(title: String, subtitle: String) {
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(title, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text(subtitle, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun InfoCard(text: String) {
    ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Text(text, modifier = Modifier.padding(15.dp), fontSize = 13.sp)
    }
}

@Composable
private fun ErrorCard(text: String) {
    ElevatedCard {
        Text(text, modifier = Modifier.padding(15.dp), color = MaterialTheme.colorScheme.error, fontSize = 13.sp)
    }
}

@Composable
private fun EmptyCard(text: String) {
    ElevatedCard {
        Text(text, modifier = Modifier.padding(15.dp), color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
    }
}

private fun openMap(context: Context, latitude: Double, longitude: Double, label: String) {
    val encodedLabel = Uri.encode(label)
    val geo = Uri.parse("geo:$latitude,$longitude?q=$latitude,$longitude($encodedLabel)")
    val intent = Intent(Intent.ACTION_VIEW, geo)
    runCatching { context.startActivity(intent) }
        .onFailure {
            val browser = Intent(
                Intent.ACTION_VIEW,
                Uri.parse("https://www.google.com/maps/search/?api=1&query=$latitude,$longitude")
            )
            context.startActivity(browser)
        }
}

private fun Throwable.userMessage(): String = when (this) {
    is SecurityException -> message ?: "İzin gerekli."
    else -> message?.takeIf { it.isNotBlank() } ?: "İşlem sırasında bağlantı hatası oluştu."
}
