# Deniz & Gizem Gezi Asistanı — V27

Sürüm: **27.0-gezi-asistani**

Bu sürümde 10 günlük rota mantığı kaldırıldı. Kullanıcı yalnızca gideceği il, ilçe veya bölgeyi yazar; uygulama tek aramada bölge rehberi oluşturur.

## Ana bölümler
- **Deniz:** Kumlu, sığ ve korunaklı/sakin kıyı bilgisi olan plajları öne alır.
- **Lezzet:** Yöresel yemekleri, kuruluş yılı doğrulanmış köklü işletmeleri ve yakın ekonomik alternatifleri ayrı gösterir.
- **Keşfet:** Genel gezilecek yerler, antik/arkeolojik alanlar, kaleler-mağaralar-yeraltı noktaları ve efsane/gizem kayıtlarını ayrı başlıklarda sunar.
- **Konak:** Pansiyon, apart, hostel, kamp, karavan alanı ve ekonomik küçük otel türlerini önceler. Canlı fiyat bulunmadığında kesin ücret uydurmaz.

## Veri yaklaşımı
- Canlı yakın yer araması Geoapify/OpenStreetMap verisi kullanır.
- Yerleşik katalogdaki köklü işletmeler kuruluş yılı/tarihçe kaydı doğrulanmış adaylardır.
- Efsane/rivayet ile tarihî bilgi aynı şeymiş gibi sunulmaz.
- Başka şehirden sonuç doldurulmaz.
- Geoapify anahtarı yalnız telefonda saklanır.
