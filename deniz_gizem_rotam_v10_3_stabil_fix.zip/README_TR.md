# Deniz ve Gizem Rotam V10.3

- Güncel Overpass sunucuları kullanılır.
- Ağır sorgular hafifletildi.
- Sonuç servisi yanıt vermezse Nominatim yedek araması devreye girer.
- Aynı sorgular 10 dakika önbellekten hızlı açılır.
- Bölge ve mesafe filtresi korunur.
- Zincir yemek işletmeleri elenir.
- Kuruluş yılı doğrulanmıyorsa “en eski” denmez.
