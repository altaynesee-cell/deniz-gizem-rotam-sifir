package com.denizgizem.rotam;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int NAVY = Color.rgb(8, 47, 51);
    private static final int TEAL = Color.rgb(12, 107, 102);
    private static final int GOLD = Color.rgb(242, 193, 78);
    private static final int CREAM = Color.rgb(248, 246, 238);
    private static final int TEXT = Color.rgb(28, 39, 40);
    private static final int MUTED = Color.rgb(91, 105, 105);

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final DataRepository repository = new DataRepository();
    private final DecimalFormat oneDecimal = new DecimalFormat("0.0");

    private LinearLayout content;
    private EditText locationInput;
    private EditText tasteInput;
    private Spinner radiusSpinner;
    private ProgressBar progressBar;
    private TextView statusText;
    private SharedPreferences prefs;
    private final List<Button> actionButtons = new ArrayList<>();
    private Button routeButton;
    private volatile int searchRequestId = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("rotam", MODE_PRIVATE);
        buildScreen();
    }

    @Override
    protected void onDestroy() {
        executor.shutdownNow();
        super.onDestroy();
    }

    private void buildScreen() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(CREAM);

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(18), dp(24), dp(18), dp(40));
        scroll.addView(content, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView title = text("DENİZ VE GİZEM ROTAM", 25, Color.WHITE, true);
        title.setGravity(Gravity.CENTER);
        title.setPadding(dp(12), dp(18), dp(12), dp(8));
        TextView subtitle = text("Bölgeyi sen seç, uygulama bulsun ve süzsün", 14, Color.rgb(220, 237, 236), false);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(dp(12), 0, dp(12), dp(8));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setBackground(rounded(NAVY, 22, 0));
        header.addView(title);
        header.addView(subtitle);

        TextView version = text("V10.3 • HIZLI ARAMA + YEDEK SERVİS", 13, GOLD, true);
        version.setGravity(Gravity.CENTER);
        version.setPadding(dp(12), 0, dp(12), dp(16));
        header.addView(version);
        content.addView(header, matchWrap(0, dp(14)));

        locationInput = new EditText(this);
        locationInput.setHint("Örnek: Bursa, İznik");
        locationInput.setText(prefs.getString("last_location", "Bursa, İznik"));
        locationInput.setTextSize(17);
        locationInput.setSingleLine(true);
        locationInput.setTextColor(TEXT);
        locationInput.setHintTextColor(Color.rgb(130, 140, 140));
        locationInput.setPadding(dp(16), dp(14), dp(16), dp(14));
        locationInput.setBackground(rounded(Color.WHITE, 16, Color.rgb(214, 221, 219)));
        content.addView(locationInput, matchWrap(0, dp(10)));

        radiusSpinner = new Spinner(this);
        String[] distances = {"10 km – Çok yakın", "25 km – Yakın çevre", "50 km – Geniş çevre"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, distances);
        radiusSpinner.setAdapter(adapter);
        int savedRadius = prefs.getInt("radius", 25);
        radiusSpinner.setSelection(savedRadius == 10 ? 0 : savedRadius == 50 ? 2 : 1);
        radiusSpinner.setBackground(rounded(Color.WHITE, 14, Color.rgb(214, 221, 219)));
        content.addView(radiusSpinner, matchWrap(0, dp(10)));

        TextView tasteLabel = text("Damak tadım", 12, MUTED, true);
        tasteLabel.setPadding(dp(6), 0, dp(6), dp(5));
        content.addView(tasteLabel);

        tasteInput = new EditText(this);
        tasteInput.setHint("Örnek: kebap, köfte, pide, ev yemekleri");
        tasteInput.setText(prefs.getString("food_taste", "kebap, köfte, pide, ev yemekleri, esnaf lokantası"));
        tasteInput.setTextSize(15);
        tasteInput.setSingleLine(true);
        tasteInput.setTextColor(TEXT);
        tasteInput.setHintTextColor(Color.rgb(130, 140, 140));
        tasteInput.setPadding(dp(16), dp(12), dp(16), dp(12));
        tasteInput.setBackground(rounded(Color.WHITE, 14, Color.rgb(214, 221, 219)));
        content.addView(tasteInput, matchWrap(0, dp(14)));

        TextView rule = text("Katı bölge filtresi açık: İlçe adı çakışırsa il bilgisi dikkate alınır; zincir yemek işletmeleri elenir.", 13, MUTED, false);
        rule.setPadding(dp(6), 0, dp(6), dp(14));
        content.addView(rule);

        addCategoryButton("🏖  PLAJLARI BUL", Models.Category.BEACH);
        addCategoryButton("🍽  YEMEK YERİ BUL", Models.Category.FOOD);
        addCategoryButton("🏛  TARİH VE GİZEM BUL", Models.Category.MYSTERY);
        addCategoryButton("🛏  EKONOMİK KONAKLAMA BUL", Models.Category.LODGING);

        routeButton = button("🧭  GÜNLÜK GEZİ ROTASI OLUŞTUR", GOLD, NAVY);
        routeButton.setOnClickListener(v -> showRouteDialog());
        actionButtons.add(routeButton);
        content.addView(routeButton, matchWrap(0, dp(18)));

        progressBar = new ProgressBar(this);
        progressBar.setIndeterminate(true);
        progressBar.setVisibility(View.GONE);
        content.addView(progressBar, centeredWrap());

        statusText = text("", 14, MUTED, false);
        statusText.setGravity(Gravity.CENTER);
        statusText.setPadding(dp(8), dp(8), dp(8), dp(12));
        content.addView(statusText);

        TextView footer = text("V10.3: Hızlı açık harita araması yapılır; ana servis yanıt vermezse yedek arama otomatik devreye girer. Zincir işletmeler elenir.", 12, MUTED, false);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(dp(8), dp(22), dp(8), 0);
        content.addView(footer);

        setContentView(scroll);
    }

    private void addCategoryButton(String label, Models.Category category) {
        Button b = button(label, TEAL, Color.WHITE);
        b.setOnClickListener(v -> runCategorySearch(category));
        actionButtons.add(b);
        content.addView(b, matchWrap(0, dp(10)));
    }

    private void runCategorySearch(Models.Category category) {
        if (!hasInternet()) {
            toast("İnternet bağlantısı gerekli.");
            return;
        }
        String location = locationInput.getText().toString().trim();
        int radius = selectedRadius();
        if (location.trim().isEmpty()) {
            locationInput.setError("Bölge yazın");
            return;
        }
        String foodTaste = tasteInput.getText().toString().trim();
        prefs.edit().putString("last_location", location).putInt("radius", radius)
                .putString("food_taste", foodTaste).apply();
        removeOldResult();
        final int requestId = ++searchRequestId;
        setLoading(true, category.title + " araştırılıyor… Ana servis yanıt vermezse yedek arama otomatik devreye girer.");

        executor.execute(() -> {
            try {
                Models.SearchResult result = repository.search(category, location, radius, foodTaste);
                mainHandler.post(() -> {
                    if (requestId != searchRequestId) return;
                    setLoading(false, "");
                    showSearchResult(category, result);
                });
            } catch (Exception ex) {
                mainHandler.post(() -> {
                    if (requestId != searchRequestId) return;
                    setLoading(false, "");
                    showError(ex.getMessage());
                });
            }
        });
    }

    private void showSearchResult(Models.Category category, Models.SearchResult result) {
        LinearLayout box = resultContainer();
        box.addView(sectionTitle(category.title));
        box.addView(text("Aranan merkez: " + compactLocation(result.center.displayName), 14, MUTED, false), matchWrap(0, dp(10)));

        if (result.places.isEmpty()) {
            box.addView(infoCard(result.note));
        } else {
            for (int i = 0; i < result.places.size(); i++) {
                String badge;
                if (category == Models.Category.FOOD) {
                    badge = i == 0 ? famousBadge(result.places.get(i)) : "EKONOMİK ALTERNATİF";
                } else if (category == Models.Category.LODGING) {
                    badge = i == 0 ? "UYGUN KONAKLAMA" : "İKİNCİ ALTERNATİF";
                } else {
                    badge = i == 0 ? "BİRİNCİ ÖNERİ" : "İKİNCİ ÖNERİ";
                }
                box.addView(placeCard(result.places.get(i), category, badge), matchWrap(0, dp(12)));
            }
            box.addView(text(result.note, 12, MUTED, false));
        }
        box.addView(updatedText());
        insertResultBox(box);
    }

    private String famousBadge(Models.Place p) {
        if (p.startYear > 0) return "DOĞRULANMIŞ EN ESKİ ADAY · " + p.startYear;
        if (p.has("wikipedia") || p.has("wikidata")) return "KAYNAKLI KÖKLÜ / MEŞHUR ADAY";
        return "DAMAK TADINA UYGUN YEREL ADAY";
    }

    private View placeCard(Models.Place p, Models.Category category, String badge) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(15), dp(15), dp(15), dp(15));
        card.setBackground(rounded(Color.WHITE, 16, Color.rgb(220, 225, 223)));

        TextView badgeView = text(badge, 11, TEAL, true);
        badgeView.setLetterSpacing(0.06f);
        card.addView(badgeView, matchWrap(0, dp(5)));
        card.addView(text(p.name, 19, TEXT, true), matchWrap(0, dp(6)));
        card.addView(text(oneDecimal.format(p.distanceKm) + " km uzaklıkta", 13, MUTED, false), matchWrap(0, dp(8)));

        String description = descriptionFor(p, category);
        card.addView(text(description, 14, TEXT, false), matchWrap(0, dp(8)));

        String details = detailsFor(p, category);
        if (!details.trim().isEmpty()) card.addView(text(details, 13, MUTED, false));
        return card;
    }

    private String descriptionFor(Models.Place p, Models.Category category) {
        if (category == Models.Category.FOOD) {
            String cuisine = cleanTag(p.tag("cuisine"));
            if (p.startYear > 0) return "Kuruluş yılı açık kaynakta " + p.startYear + " olarak kayıtlı. " +
                    (cuisine.trim().isEmpty() ? "Bağımsız ve köklü işletme adayı." : "Mutfak: " + cuisine + ".");
            if (p.has("wikipedia") || p.has("wikidata")) return "Kaynak kaydı bulunan bağımsız yerel işletme. " +
                    (cuisine.trim().isEmpty() ? "" : "Mutfak: " + cuisine + ".");
            if (!cuisine.trim().isEmpty()) return "Damak tadı tercihinizle eşleşen bağımsız yerel aday. Mutfak: " + cuisine + ".";
            return "Zincir işletmeler dışarıda bırakılarak damak tadınıza göre seçilen yerel aday.";
        }
        if (category == Models.Category.BEACH) {
            String surface = cleanTag(p.tag("surface"));
            return surface.trim().isEmpty() ? "Seçilen merkezin yakın çevresindeki gerçek plaj kaydı." : "Zemin bilgisi: " + surface + ".";
        }
        if (category == Models.Category.MYSTERY) {
            String historic = cleanTag(p.tag("historic"));
            return historic.trim().isEmpty() ? "Tarihî veya kültürel niteliği bulunan yakın çevre noktası." : "Kayıt türü: " + historic + ".";
        }
        return "Lüks otel ve resort sonuçları dışarıda bırakılarak ekonomik tesis türlerinden seçildi.";
    }

    private String detailsFor(Models.Place p, Models.Category category) {
        StringBuilder sb = new StringBuilder();
        if (p.startYear > 0 && category != Models.Category.FOOD) sb.append("Başlangıç yılı: ").append(p.startYear).append("\n");
        if (p.has("opening_hours")) sb.append("Çalışma saatleri: ").append(p.tag("opening_hours")).append("\n");
        if (category == Models.Category.FOOD && p.economicScore > 0) {
            sb.append("Ekonomik değerlendirme: işletme türü ve yerel yemek özelliklerine göre güçlü aday.\n");
        }
        if ((category == Models.Category.FOOD || category == Models.Category.LODGING) && !p.has("charge")) {
            sb.append("Fiyat: Açık veride güncel tutar doğrulanamadı; uygulama fiyat uydurmaz.");
        }
        return sb.toString().trim();
    }

    private void showRouteDialog() {
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(20), dp(8), dp(20), 0);

        EditText start = dialogInput("Başlangıç: Bursa");
        start.setText(prefs.getString("route_start", "Bursa"));
        EditText end = dialogInput("Bitiş: Antalya");
        end.setText(prefs.getString("route_end", "Antalya"));
        EditText days = dialogInput("Gün sayısı: 10");
        days.setInputType(InputType.TYPE_CLASS_NUMBER);
        days.setText(String.valueOf(prefs.getInt("route_days", 10)));
        form.addView(start, matchWrap(0, dp(10)));
        form.addView(end, matchWrap(0, dp(10)));
        form.addView(days);

        new AlertDialog.Builder(this)
                .setTitle("Gezi rotası")
                .setView(form)
                .setNegativeButton("Vazgeç", null)
                .setPositiveButton("Oluştur", (dialog, which) -> {
                    int dayCount;
                    try { dayCount = Integer.parseInt(days.getText().toString()); }
                    catch (Exception ignored) { dayCount = 10; }
                    dayCount = Math.max(1, Math.min(dayCount, 10));
                    prefs.edit().putString("route_start", start.getText().toString())
                            .putString("route_end", end.getText().toString())
                            .putInt("route_days", dayCount).apply();
                    runRoute(start.getText().toString(), end.getText().toString(), dayCount);
                })
                .show();
    }

    private void runRoute(String start, String end, int days) {
        if (!hasInternet()) {
            toast("İnternet bağlantısı gerekli.");
            return;
        }
        if (start.trim().isEmpty() || end.trim().isEmpty()) {
            toast("Başlangıç ve bitiş yerini yazın.");
            return;
        }
        setLoading(true, "Araç rotası ve günlük duraklar hazırlanıyor…");
        RoutePlanner planner = new RoutePlanner(repository);
        executor.execute(() -> {
            try {
                Models.RouteResult result = planner.build(start, end, days,
                        (completed, total) -> mainHandler.post(() -> statusText.setText("Günlük plan hazırlanıyor: " + completed + "/" + total)));
                mainHandler.post(() -> {
                    setLoading(false, "");
                    showRouteResult(result);
                });
            } catch (Exception ex) {
                mainHandler.post(() -> {
                    setLoading(false, "");
                    showError(ex.getMessage());
                });
            }
        });
    }

    private void showRouteResult(Models.RouteResult result) {
        LinearLayout box = resultContainer();
        box.addView(sectionTitle("Günlük Gezi Rotası"));
        box.addView(text(compactLocation(result.start.displayName) + " → " + compactLocation(result.end.displayName), 15, TEXT, true), matchWrap(0, dp(5)));
        box.addView(text("Yaklaşık araç rotası: " + Math.round(result.totalKm) + " km", 13, MUTED, false), matchWrap(0, dp(12)));

        for (Models.DayPlan day : result.days) {
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(14), dp(14), dp(14), dp(14));
            card.setBackground(rounded(Color.WHITE, 16, Color.rgb(220, 225, 223)));
            card.addView(text(day.day + ". GÜN", 15, TEAL, true), matchWrap(0, dp(8)));
            card.addView(routeLine("Plaj", day.beach));
            card.addView(routeLine("Yemek", day.food));
            card.addView(routeLine("Tarih/Gizem", day.mystery));
            card.addView(routeLine("Konaklama", day.lodging));
            box.addView(card, matchWrap(0, dp(10)));
        }
        box.addView(text("Rota, yol üzerindeki günlük noktalarda 25 km çevre taranarak oluşturuldu. Sonuç bulunmayan başlıkta uzak şehirden örnek eklenmez.", 12, MUTED, false));
        box.addView(updatedText());
        insertResultBox(box);
    }

    private TextView routeLine(String label, Models.Place place) {
        String value = place == null ? "Yakında uygun sonuç bulunamadı" : place.name + " (" + oneDecimal.format(place.distanceKm) + " km)";
        TextView t = text(label + ": " + value, 14, TEXT, false);
        t.setPadding(0, dp(4), 0, dp(4));
        return t;
    }

    private LinearLayout resultContainer() {
        LinearLayout box = new LinearLayout(this);
        box.setTag("RESULT_BOX");
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(16), dp(16), dp(16));
        box.setBackground(rounded(Color.rgb(236, 241, 237), 20, Color.rgb(198, 211, 207)));
        return box;
    }

    private void insertResultBox(LinearLayout box) {
        removeOldResult();
        int index = content.indexOfChild(progressBar) + 2;
        content.addView(box, Math.min(index, content.getChildCount()), matchWrap(dp(6), dp(8)));
        box.post(() -> box.requestFocus());
    }

    private void removeOldResult() {
        for (int i = content.getChildCount() - 1; i >= 0; i--) {
            View child = content.getChildAt(i);
            if ("RESULT_BOX".equals(child.getTag())) content.removeViewAt(i);
        }
    }

    private TextView updatedText() {
        String date = new SimpleDateFormat("dd.MM.yyyy HH:mm", new Locale("tr", "TR")).format(new Date());
        TextView t = text("Kontrol zamanı: " + date, 11, MUTED, false);
        t.setPadding(0, dp(12), 0, 0);
        return t;
    }

    private TextView sectionTitle(String value) {
        TextView t = text(value, 21, NAVY, true);
        t.setPadding(0, 0, 0, dp(8));
        return t;
    }

    private View infoCard(String message) {
        TextView t = text(message, 15, TEXT, false);
        t.setPadding(dp(14), dp(14), dp(14), dp(14));
        t.setBackground(rounded(Color.WHITE, 14, Color.rgb(220, 225, 223)));
        return t;
    }

    private void showError(String message) {
        removeOldResult();
        LinearLayout box = resultContainer();
        box.addView(sectionTitle("Sonuç alınamadı"));
        box.addView(infoCard(message == null || message.trim().isEmpty() ? "Canlı veri kaynağına ulaşılamadı." : message));
        insertResultBox(box);
    }

    private EditText dialogInput(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setSingleLine(true);
        e.setTextSize(16);
        e.setPadding(dp(12), dp(10), dp(12), dp(10));
        e.setBackground(rounded(Color.rgb(247, 248, 246), 12, Color.rgb(210, 216, 214)));
        return e;
    }

    private void setLoading(boolean loading, String status) {
        progressBar.setVisibility(loading ? View.VISIBLE : View.GONE);
        statusText.setText(status == null ? "" : status);
        locationInput.setEnabled(!loading);
        tasteInput.setEnabled(!loading);
        radiusSpinner.setEnabled(!loading);
        for (Button button : actionButtons) button.setEnabled(!loading);
    }

    private int selectedRadius() {
        int pos = radiusSpinner.getSelectedItemPosition();
        return pos == 0 ? 10 : pos == 2 ? 50 : 25;
    }

    private boolean hasInternet() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) return false;
        NetworkCapabilities caps = cm.getNetworkCapabilities(cm.getActiveNetwork());
        return caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
    }

    private String compactLocation(String display) {
        if (display == null) return "";
        String[] parts = display.split(",");
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < Math.min(parts.length, 2); i++) {
            if (i > 0) sb.append(", ");
            sb.append(parts[i].trim());
        }
        return sb.toString();
    }

    private String cleanTag(String value) {
        if (value == null || value.trim().isEmpty()) return "";
        String cleaned = value.replace(';', ',').replace('_', ' ');
        cleaned = cleaned.replace("turkish", "Türk mutfağı")
                .replace("regional", "yöresel mutfak")
                .replace("home cooking", "ev yemekleri")
                .replace("kebab", "kebap")
                .replace("grill", "ızgara")
                .replace("meat", "et yemekleri")
                .replace("fish", "balık")
                .replace("seafood", "deniz ürünleri");
        return cleaned;
    }

    private TextView text(String value, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setLineSpacing(0, 1.08f);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private Button button(String value, int background, int foreground) {
        Button b = new Button(this);
        b.setText(value);
        b.setTextSize(15);
        b.setTextColor(foreground);
        b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setPadding(dp(12), dp(13), dp(12), dp(13));
        b.setBackground(rounded(background, 15, 0));
        return b;
    }

    private GradientDrawable rounded(int color, int radiusDp, int strokeColor) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        if (strokeColor != 0) d.setStroke(dp(1), strokeColor);
        return d;
    }

    private LinearLayout.LayoutParams matchWrap(int top, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.setMargins(0, top, 0, bottom);
        return p;
    }

    private LinearLayout.LayoutParams centeredWrap() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.gravity = Gravity.CENTER_HORIZONTAL;
        return p;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }
}
