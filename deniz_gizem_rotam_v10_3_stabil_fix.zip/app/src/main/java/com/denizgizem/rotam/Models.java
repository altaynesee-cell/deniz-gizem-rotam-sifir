package com.denizgizem.rotam;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

final class Models {
    private Models() {}

    enum Category {
        BEACH("Plajlar"),
        FOOD("Yemek"),
        MYSTERY("Tarih ve Gizem"),
        LODGING("Konaklama");

        final String title;
        Category(String title) { this.title = title; }
    }

    static final class GeoPoint {
        final double lat;
        final double lon;
        final String displayName;

        GeoPoint(double lat, double lon, String displayName) {
            this.lat = lat;
            this.lon = lon;
            this.displayName = displayName;
        }
    }

    static final class Place {
        final String name;
        final double lat;
        final double lon;
        final double distanceKm;
        final Map<String, String> tags;
        Models.Category category;
        int score;
        int economicScore;
        int tasteScore;
        int startYear;

        Place(String name, double lat, double lon, double distanceKm, Map<String, String> tags) {
            this.name = name;
            this.lat = lat;
            this.lon = lon;
            this.distanceKm = distanceKm;
            this.tags = Collections.unmodifiableMap(new HashMap<>(tags));
            this.startYear = RankingEngine.parseStartYear(tags.get("start_date"));
        }

        String tag(String key) { return tags.getOrDefault(key, ""); }
        boolean has(String key) { return tags.containsKey(key) && !tag(key).trim().isEmpty(); }
    }

    static final class SearchResult {
        final GeoPoint center;
        final List<Place> places;
        final String note;

        SearchResult(GeoPoint center, List<Place> places, String note) {
            this.center = center;
            this.places = Collections.unmodifiableList(new ArrayList<>(places));
            this.note = note;
        }
    }

    static final class DayPlan {
        final int day;
        final GeoPoint point;
        final Place beach;
        final Place food;
        final Place mystery;
        final Place lodging;

        DayPlan(int day, GeoPoint point, Place beach, Place food, Place mystery, Place lodging) {
            this.day = day;
            this.point = point;
            this.beach = beach;
            this.food = food;
            this.mystery = mystery;
            this.lodging = lodging;
        }
    }

    static final class RouteResult {
        final GeoPoint start;
        final GeoPoint end;
        final double totalKm;
        final List<DayPlan> days;

        RouteResult(GeoPoint start, GeoPoint end, double totalKm, List<DayPlan> days) {
            this.start = start;
            this.end = end;
            this.totalKm = totalKm;
            this.days = Collections.unmodifiableList(new ArrayList<>(days));
        }
    }
}
