package com.denizgizem.rotam;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

final class DataRepository {
    private static final String USER_AGENT = "DenizGizemRotam/10.3 (personal travel research app)";
    private static final String[] OVERPASS_ENDPOINTS = {
            "https://overpass.private.coffee/api/interpreter",
            "https://overpass-api.de/api/interpreter",
            "https://maps.mail.ru/osm/tools/overpass/api/interpreter"
    };
    private static final Object NOMINATIM_LOCK = new Object();
    private static long lastNominatimRequestAt = 0L;
    private static final long NOMINATIM_MIN_INTERVAL_MS = 1100L;

    private final Map<String, CacheEntry> responseCache = new HashMap<>();
    private static final long CACHE_TTL_MS = 10 * 60 * 1000L;

    private static final Set<String> PROVINCES = new HashSet<>(Arrays.asList(
            "adana", "adiyaman", "afyonkarahisar", "agri", "amasya", "ankara", "antalya", "artvin", "aydin",
            "balikesir", "bilecik", "bingol", "bitlis", "bolu", "burdur", "bursa", "canakkale", "cankiri",
            "corum", "denizli", "diyarbakir", "edirne", "elazig", "erzincan", "erzurum", "eskisehir", "gaziantep",
            "giresun", "gumushane", "hakkari", "hatay", "isparta", "mersin", "istanbul", "izmir", "kars",
            "kastamonu", "kayseri", "kirklareli", "kirsehir", "kocaeli", "konya", "kutahya", "malatya", "manisa",
            "kahramanmaras", "mardin", "mugla", "mus", "nevsehir", "nigde", "ordu", "rize", "sakarya", "samsun",
            "siirt", "sinop", "sivas", "tekirdag", "tokat", "trabzon", "tunceli", "sanliurfa", "usak", "van",
            "yozgat", "zonguldak", "aksaray", "bayburt", "karaman", "kirikkale", "batman", "sirnak", "bartin",
            "ardahan", "igdir", "yalova", "karabuk", "kilis", "osmaniye", "duzce"
    ));

    Models.GeoPoint geocode(String rawQuery) throws Exception {
        String clean = cleanLocation(rawQuery);
        List<String> attempts = locationAttempts(clean);
        GeocodeCandidate best = null;

        for (int attemptIndex = 0; attemptIndex < attempts.size(); attemptIndex++) {
            String query = attempts.get(attemptIndex);
            String encoded = URLEncoder.encode(query, StandardCharsets.UTF_8.name());
            String url = "https://nominatim.openstreetmap.org/search?format=jsonv2&limit=10&countrycodes=tr&addressdetails=1&namedetails=1&accept-language=tr&q=" + encoded;
            JSONArray array = new JSONArray(nominatimGet(url));
            for (int i = 0; i < array.length(); i++) {
                JSONObject obj = array.getJSONObject(i);
                GeocodeCandidate candidate = scoreGeocodeCandidate(obj, clean, attemptIndex);
                if (best == null || candidate.score > best.score) best = candidate;
            }
            if (best != null && best.score >= 145) break;
        }

        if (best == null || best.score < 35) {
            throw new IllegalArgumentException("Bölge kesin olarak bulunamadı. İlçeyi ve ili birlikte yazın; örnek: Erdek, Balıkesir.");
        }
        return new Models.GeoPoint(best.lat, best.lon, best.shortName);
    }

    Models.SearchResult search(Models.Category category, String locationText, int radiusKm) throws Exception {
        return search(category, locationText, radiusKm, "");
    }

    Models.SearchResult search(Models.Category category, String locationText, int radiusKm, String foodPreferences) throws Exception {
        Models.GeoPoint center = geocode(locationText);
        List<Models.Place> raw = queryCategory(center, category, radiusKm, foodPreferences);
        List<Models.Place> ranked = RankingEngine.rank(category, raw, 2, foodPreferences);

        String note;
        if (ranked.isEmpty()) {
            note = "Belirlenen " + radiusKm + " km sınırında uygun sonuç bulunamadı. Başka şehirden sonuç gösterilmedi.";
        } else if (category == Models.Category.FOOD && !RankingEngine.hasVerifiedHeritage(ranked.get(0))) {
            note = "Zincir işletmeler elendi. Kuruluş yılı doğrulanmış köklü işletme bulunamadığında ilk sonuç damak tadınıza uyan bağımsız yerel aday olarak gösterilir.";
        } else if (category == Models.Category.FOOD) {
            note = "İlk sonuç doğrulanabilen kuruluş yılı veya kaynak kaydına göre; ikinci sonuç ekonomik ve damak tadına uygun yerel alternatif olarak seçildi.";
        } else {
            note = "Sonuçlar yalnızca seçilen merkezin " + radiusKm + " km çevresinden getirildi.";
        }
        return new Models.SearchResult(center, ranked, note);
    }

    List<Models.Place> queryCategory(Models.GeoPoint center, Models.Category category, int radiusKm) throws Exception {
        return queryCategory(center, category, radiusKm, "");
    }

    List<Models.Place> queryCategory(Models.GeoPoint center, Models.Category category, int radiusKm, String foodPreferences) throws Exception {
        int queryRadiusKm = radiusKm;
        if (category == Models.Category.FOOD || category == Models.Category.LODGING) {
            queryRadiusKm = Math.min(radiusKm, 25);
        }

        List<Models.Place> places = new ArrayList<>();
        Exception overpassError = null;
        try {
            places.addAll(queryOverpassCategory(center, category, queryRadiusKm));
        } catch (Exception ex) {
            overpassError = ex;
        }

        if (places.size() < 2) {
            try {
                mergeUnique(places, queryNominatimCategory(center, category, radiusKm));
            } catch (Exception ignored) {
                if (places.isEmpty() && overpassError != null) {
                    throw new IllegalStateException("Canlı yer servisleri şu anda yanıt vermedi. Birkaç saniye sonra yeniden deneyin.", overpassError);
                }
            }
        }
        return places;
    }

    private List<Models.Place> queryOverpassCategory(Models.GeoPoint center, Models.Category category, int radiusKm) throws Exception {
        int radiusM = radiusKm * 1000;
        String around = "(around:" + radiusM + "," + center.lat + "," + center.lon + ")";
        String selectors;
        switch (category) {
            case BEACH:
                selectors = "nwr" + around + "[\"natural\"=\"beach\"][\"name\"];" +
                        "nwr" + around + "[\"leisure\"=\"beach_resort\"][\"name\"];";
                break;
            case FOOD:
                selectors = "nwr" + around + "[\"amenity\"~\"restaurant|fast_food|food_court\"][\"name\"];";
                break;
            case MYSTERY:
                selectors = "nwr" + around + "[\"historic\"][\"name\"];" +
                        "nwr" + around + "[\"site\"=\"archaeological_site\"][\"name\"];" +
                        "nwr" + around + "[\"natural\"=\"cave_entrance\"][\"name\"];" +
                        "nwr" + around + "[\"tourism\"=\"museum\"][\"name\"];";
                break;
            case LODGING:
                selectors = "nwr" + around + "[\"tourism\"~\"guest_house|hostel|motel|camp_site|caravan_site|apartment|chalet\"][\"name\"];";
                break;
            default:
                throw new IllegalArgumentException("Geçersiz kategori");
        }
        String query = "[out:json][timeout:12];(" + selectors + ");out tags center qt 180;";
        return parsePlaces(overpass(query), center, radiusKm);
    }

    List<Models.Place> queryBundle(Models.GeoPoint center, int radiusKm) throws Exception {
        int r = Math.min(radiusKm, 25) * 1000;
        String around = "(around:" + r + "," + center.lat + "," + center.lon + ")";
        String query = "[out:json][timeout:12];(" +
                "nwr" + around + "[\"natural\"=\"beach\"][\"name\"];" +
                "nwr" + around + "[\"amenity\"~\"restaurant|fast_food\"][\"name\"];" +
                "nwr" + around + "[\"historic\"][\"name\"];" +
                "nwr" + around + "[\"site\"=\"archaeological_site\"][\"name\"];" +
                "nwr" + around + "[\"natural\"=\"cave_entrance\"][\"name\"];" +
                "nwr" + around + "[\"tourism\"~\"guest_house|hostel|motel|camp_site|caravan_site|apartment|chalet\"][\"name\"];" +
                ");out tags center qt 260;";
        try {
            return parsePlaces(overpass(query), center, radiusKm);
        } catch (Exception ex) {
            return new ArrayList<>();
        }
    }

    JSONObject route(Models.GeoPoint start, Models.GeoPoint end) throws Exception {
        String url = String.format(Locale.US,
                "https://router.project-osrm.org/route/v1/driving/%.6f,%.6f;%.6f,%.6f?overview=full&geometries=geojson&steps=false",
                start.lon, start.lat, end.lon, end.lat);
        JSONObject root = new JSONObject(get(url, 7000, 14000));
        if (!"Ok".equalsIgnoreCase(root.optString("code"))) {
            throw new IllegalStateException("Araç rotası oluşturulamadı.");
        }
        return root.getJSONArray("routes").getJSONObject(0);
    }

    private String overpass(String query) throws Exception {
        String cacheKey = "overpass:" + query;
        String cached = cached(cacheKey);
        if (cached != null) return cached;

        Exception last = null;
        long deadline = System.currentTimeMillis() + 18000L;
        String body = "data=" + URLEncoder.encode(query, StandardCharsets.UTF_8.name());
        for (String endpoint : OVERPASS_ENDPOINTS) {
            if (System.currentTimeMillis() >= deadline) break;
            try {
                String response = postForm(endpoint, body, 4500, 8500);
                putCache(cacheKey, response);
                return response;
            } catch (Exception ex) {
                last = ex;
            }
        }
        throw new IllegalStateException("Açık harita sunucuları yoğun.", last);
    }

    private List<Models.Place> queryNominatimCategory(Models.GeoPoint center, Models.Category category, int radiusKm) throws Exception {
        List<Models.Place> out = new ArrayList<>();
        String[] queries;
        switch (category) {
            case BEACH:
                queries = new String[]{"[beach]"};
                break;
            case FOOD:
                queries = new String[]{"[restaurant]", "[fast food]"};
                break;
            case MYSTERY:
                queries = new String[]{"[archaeological site]", "[castle]", "[museum]", "[cave entrance]"};
                break;
            case LODGING:
                queries = new String[]{"[guest house]", "[hostel]", "[camp site]", "[motel]"};
                break;
            default:
                return out;
        }

        double latDelta = radiusKm / 111.0;
        double lonScale = Math.max(0.25, Math.cos(Math.toRadians(center.lat)));
        double lonDelta = radiusKm / (111.0 * lonScale);
        double left = center.lon - lonDelta;
        double top = center.lat + latDelta;
        double right = center.lon + lonDelta;
        double bottom = center.lat - latDelta;
        String viewbox = String.format(Locale.US, "%.6f,%.6f,%.6f,%.6f", left, top, right, bottom);

        for (String q : queries) {
            String url = "https://nominatim.openstreetmap.org/search?format=jsonv2&limit=20&countrycodes=tr" +
                    "&addressdetails=1&extratags=1&namedetails=1&accept-language=tr&bounded=1&layer=poi,natural,manmade" +
                    "&viewbox=" + URLEncoder.encode(viewbox, StandardCharsets.UTF_8.name()) +
                    "&q=" + URLEncoder.encode(q, StandardCharsets.UTF_8.name());
            JSONArray array = new JSONArray(nominatimGet(url));
            mergeUnique(out, parseNominatimPlaces(array, center, category, radiusKm));
            if (out.size() >= 8) break;
        }
        return out;
    }

    private List<Models.Place> parseNominatimPlaces(JSONArray array, Models.GeoPoint center, Models.Category category, int radiusKm) throws Exception {
        List<Models.Place> out = new ArrayList<>();
        for (int i = 0; i < array.length(); i++) {
            JSONObject obj = array.getJSONObject(i);
            String name = firstNonBlank(obj.optString("name"), firstPart(obj.optString("display_name")));
            if (name.trim().isEmpty()) continue;
            double lat = Double.parseDouble(obj.optString("lat", "0"));
            double lon = Double.parseDouble(obj.optString("lon", "0"));
            double distance = haversine(center.lat, center.lon, lat, lon);
            if (distance > radiusKm + 0.25) continue;

            Map<String, String> tags = new HashMap<>();
            JSONObject extras = obj.optJSONObject("extratags");
            if (extras != null) {
                Iterator<String> keys = extras.keys();
                while (keys.hasNext()) {
                    String key = keys.next();
                    tags.put(key, extras.optString(key, ""));
                }
            }
            tags.put("nominatim_importance", String.valueOf(obj.optDouble("importance", 0.0)));
            String type = RankingEngine.fold(obj.optString("type"));
            String objCategory = RankingEngine.fold(obj.optString("category", obj.optString("class")));

            if (category == Models.Category.FOOD) {
                tags.put("amenity", type.contains("fast_food") ? "fast_food" : "restaurant");
            } else if (category == Models.Category.BEACH) {
                tags.put("natural", "beach");
            } else if (category == Models.Category.MYSTERY) {
                if (type.contains("museum")) tags.put("tourism", "museum");
                else if (type.contains("cave")) tags.put("natural", "cave_entrance");
                else {
                    String historicType = type.trim().isEmpty() ? objCategory : type;
                    if (historicType.contains("archaeological")) {
                        tags.put("site", "archaeological_site");
                        tags.put("historic", "archaeological_site");
                    } else {
                        tags.put("historic", historicType.trim().isEmpty() ? "yes" : historicType);
                    }
                }
            } else if (category == Models.Category.LODGING) {
                String tourism = type;
                if (tourism.contains("guest")) tourism = "guest_house";
                else if (tourism.contains("camp")) tourism = "camp_site";
                else if (tourism.contains("hostel")) tourism = "hostel";
                else if (tourism.contains("motel")) tourism = "motel";
                else tourism = "guest_house";
                tags.put("tourism", tourism);
            }
            out.add(new Models.Place(name, lat, lon, distance, tags));
        }
        return out;
    }

    private List<Models.Place> parsePlaces(String json, Models.GeoPoint center, int radiusKm) throws Exception {
        JSONArray elements = new JSONObject(json).optJSONArray("elements");
        List<Models.Place> out = new ArrayList<>();
        if (elements == null) return out;

        for (int i = 0; i < elements.length(); i++) {
            JSONObject e = elements.getJSONObject(i);
            JSONObject tagsObj = e.optJSONObject("tags");
            if (tagsObj == null) continue;
            String name = firstNonBlank(
                    tagsObj.optString("name:tr"),
                    tagsObj.optString("name"),
                    tagsObj.optString("official_name")
            );
            if (name.trim().isEmpty()) continue;

            double lat;
            double lon;
            if (e.has("lat") && e.has("lon")) {
                lat = e.getDouble("lat");
                lon = e.getDouble("lon");
            } else {
                JSONObject c = e.optJSONObject("center");
                if (c == null) continue;
                lat = c.getDouble("lat");
                lon = c.getDouble("lon");
            }

            double distance = haversine(center.lat, center.lon, lat, lon);
            if (distance > radiusKm + 0.25) continue;

            Map<String, String> tags = new HashMap<>();
            Iterator<String> keys = tagsObj.keys();
            while (keys.hasNext()) {
                String key = keys.next();
                tags.put(key, tagsObj.optString(key, ""));
            }
            out.add(new Models.Place(name, lat, lon, distance, tags));
        }
        return out;
    }

    private GeocodeCandidate scoreGeocodeCandidate(JSONObject obj, String raw, int attemptIndex) {
        String display = obj.optString("display_name", "");
        String name = firstNonBlank(
                obj.optString("name", ""),
                obj.optJSONObject("namedetails") == null ? "" : obj.optJSONObject("namedetails").optString("name", ""),
                display.split(",")[0]
        );
        String addresstype = RankingEngine.fold(obj.optString("addresstype", obj.optString("type", "")));
        JSONObject address = obj.optJSONObject("address");
        String addressText = address == null ? "" : address.toString();
        String haystack = RankingEngine.fold(name + " " + display + " " + addressText);
        List<String> tokens = meaningfulLocationTokens(raw);
        int score = (int) Math.round(obj.optDouble("importance", 0) * 100.0) - attemptIndex * 4;

        for (String token : tokens) {
            if (haystack.contains(token)) score += 35;
            else score -= 45;
            if (RankingEngine.fold(name).equals(token)) score += 85;
        }

        if (matchesAny(addresstype, "city", "town", "municipality", "district", "county", "administrative")) score += 50;
        if (matchesAny(addresstype, "village")) score -= tokens.size() == 1 ? 15 : 5;
        if (matchesAny(addresstype, "hamlet", "locality", "isolated_dwelling", "neighbourhood")) score -= 70;

        String requestedProvince = requestedProvince(raw);
        if (!requestedProvince.isEmpty()) {
            String provinceText = address == null ? "" : firstNonBlank(address.optString("province"), address.optString("state"));
            if (RankingEngine.fold(provinceText).contains(requestedProvince) || haystack.contains(requestedProvince)) score += 100;
            else score -= 130;
        }

        double lat = Double.parseDouble(obj.optString("lat", "0"));
        double lon = Double.parseDouble(obj.optString("lon", "0"));
        return new GeocodeCandidate(lat, lon, shortLocation(obj, name), score);
    }

    private String shortLocation(JSONObject obj, String fallbackName) {
        JSONObject address = obj.optJSONObject("address");
        if (address == null) return obj.optString("display_name", fallbackName);
        String specific = firstNonBlank(
                address.optString("town"),
                address.optString("city"),
                address.optString("municipality"),
                address.optString("district"),
                address.optString("county"),
                address.optString("village"),
                fallbackName
        );
        String province = firstNonBlank(address.optString("province"), address.optString("state"));
        if (!province.trim().isEmpty() && !RankingEngine.fold(specific).equals(RankingEngine.fold(province))) {
            return specific + ", " + province;
        }
        return specific;
    }

    private String cleanLocation(String raw) {
        String clean = raw == null ? "" : raw.trim().replaceAll("\\s+", " ");
        clean = clean.replaceAll("(?i)\\b(adası|adasi|bölgesi|bolgesi|civarı|civari)\\b", " ")
                .replaceAll("\\s+", " ").replaceAll("\\s*,\\s*", ", ").trim();
        if (clean.isEmpty()) throw new IllegalArgumentException("Önce il veya ilçe yazın.");
        return clean;
    }

    private List<String> locationAttempts(String clean) {
        List<String> attempts = new ArrayList<>();
        String[] rawParts = clean.split(",");
        List<String> parts = new ArrayList<>();
        for (String part : rawParts) if (!part.trim().isEmpty()) parts.add(part.trim());

        if (parts.size() >= 2) {
            String first = parts.get(0);
            String second = parts.get(1);
            boolean firstProvince = PROVINCES.contains(RankingEngine.fold(first));
            boolean secondProvince = PROVINCES.contains(RankingEngine.fold(second));
            if (firstProvince && !secondProvince) attempts.add(second + ", " + first + ", Türkiye");
            else attempts.add(first + ", " + second + ", Türkiye");
        } else {
            attempts.add(clean + (RankingEngine.fold(clean).contains("turkiye") ? "" : ", Türkiye"));
        }
        if (!attempts.get(0).equalsIgnoreCase(clean)) attempts.add(clean);
        return attempts;
    }

    private List<String> meaningfulLocationTokens(String raw) {
        List<String> out = new ArrayList<>();
        for (String part : raw.split("[, ]+")) {
            String token = RankingEngine.fold(part).replaceAll("[^a-z0-9]", "");
            if (token.length() < 3 || matchesAny(token, "turkiye", "merkez")) continue;
            out.add(token);
        }
        return out;
    }

    private String requestedProvince(String raw) {
        for (String part : raw.split("[, ]+")) {
            String token = RankingEngine.fold(part).replaceAll("[^a-z0-9]", "");
            if (PROVINCES.contains(token)) return token;
        }
        return "";
    }

    private String nominatimGet(String url) throws Exception {
        String cacheKey = "nominatim:" + url;
        String cached = cached(cacheKey);
        if (cached != null) return cached;

        synchronized (NOMINATIM_LOCK) {
            cached = cached(cacheKey);
            if (cached != null) return cached;
            long wait = NOMINATIM_MIN_INTERVAL_MS - (System.currentTimeMillis() - lastNominatimRequestAt);
            if (wait > 0) Thread.sleep(wait);
            String response = get(url, 6000, 10000);
            lastNominatimRequestAt = System.currentTimeMillis();
            putCache(cacheKey, response);
            return response;
        }
    }

    private String get(String urlText, int connectTimeout, int readTimeout) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(urlText).openConnection();
        c.setRequestMethod("GET");
        c.setConnectTimeout(connectTimeout);
        c.setReadTimeout(readTimeout);
        c.setRequestProperty("User-Agent", USER_AGENT);
        c.setRequestProperty("Accept", "application/json");
        c.setRequestProperty("Accept-Language", "tr-TR,tr;q=0.9,en;q=0.5");
        return readResponse(c);
    }

    private String postForm(String urlText, String body, int connectTimeout, int readTimeout) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(urlText).openConnection();
        c.setRequestMethod("POST");
        c.setDoOutput(true);
        c.setConnectTimeout(connectTimeout);
        c.setReadTimeout(readTimeout);
        c.setRequestProperty("User-Agent", USER_AGENT);
        c.setRequestProperty("Accept", "application/json");
        c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
        c.setFixedLengthStreamingMode(bytes.length);
        try (OutputStream os = c.getOutputStream()) { os.write(bytes); }
        return readResponse(c);
    }

    private String readResponse(HttpURLConnection c) throws Exception {
        int code = c.getResponseCode();
        InputStream stream = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
        StringBuilder sb = new StringBuilder();
        if (stream != null) {
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) sb.append(line);
            }
        }
        c.disconnect();
        if (code < 200 || code >= 300) throw new IllegalStateException("Sunucu yanıtı: " + code);
        return sb.toString();
    }

    private String cached(String key) {
        CacheEntry entry = responseCache.get(key);
        if (entry == null) return null;
        if (System.currentTimeMillis() - entry.createdAt > CACHE_TTL_MS) {
            responseCache.remove(key);
            return null;
        }
        return entry.value;
    }

    private void putCache(String key, String value) {
        if (responseCache.size() > 40) responseCache.clear();
        responseCache.put(key, new CacheEntry(value, System.currentTimeMillis()));
    }

    private void mergeUnique(List<Models.Place> target, List<Models.Place> additions) {
        Map<String, Models.Place> unique = new LinkedHashMap<>();
        for (Models.Place p : target) unique.put(placeKey(p), p);
        for (Models.Place p : additions) unique.putIfAbsent(placeKey(p), p);
        target.clear();
        target.addAll(unique.values());
    }

    private String placeKey(Models.Place p) {
        return RankingEngine.fold(p.name) + "|" + Math.round(p.lat * 10000) + "|" + Math.round(p.lon * 10000);
    }

    private String firstPart(String value) {
        if (value == null || value.trim().isEmpty()) return "";
        int comma = value.indexOf(',');
        return comma >= 0 ? value.substring(0, comma).trim() : value.trim();
    }

    static double haversine(double lat1, double lon1, double lat2, double lon2) {
        double r = 6371.0088;
        double dLat = Math.toRadians(lat2 - lat1);
        double dLon = Math.toRadians(lon2 - lon1);
        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) *
                        Math.sin(dLon / 2) * Math.sin(dLon / 2);
        return 2 * r * Math.asin(Math.sqrt(a));
    }

    private boolean matchesAny(String value, String... candidates) {
        for (String candidate : candidates) if (value.equals(candidate) || value.contains(candidate)) return true;
        return false;
    }

    private String firstNonBlank(String... values) {
        for (String value : values) if (value != null && !value.trim().isEmpty()) return value;
        return "";
    }

    private static final class GeocodeCandidate {
        final double lat;
        final double lon;
        final String shortName;
        final int score;

        GeocodeCandidate(double lat, double lon, String shortName, int score) {
            this.lat = lat;
            this.lon = lon;
            this.shortName = shortName;
            this.score = score;
        }
    }

    private static final class CacheEntry {
        final String value;
        final long createdAt;

        CacheEntry(String value, long createdAt) {
            this.value = value;
            this.createdAt = createdAt;
        }
    }
}
