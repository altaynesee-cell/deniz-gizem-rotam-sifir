# Deniz Gizem Rotam V18

Sürüm: **19.0-antik-gizem-ayrimi**

- Pide, köfte, esnaf lokantası, kebap/döner ve sulu yemek ayrı butonlarla aranır.
- Seçilmeyen yemek türleri sonuçlara karıştırılmaz.
- Sonuçlar bölge merkezine veya telefon konumuna göre en yakından uzağa sıralanır.
- Pastane, kafe, unlu mamuller, tatlıcı, fırın, pizza, burger ve lüks restoranlar elenir.
- Kuruluş yılı doğrulanmadan hiçbir işletmeye “en eski” denmez.


## V19 düzeltmesi

- Antik/ören yeri, kale/mağara ve gizemli/efsaneli sonuçlar ayrı butonlara ayrıldı.
- Genel turistik yer ve sıradan müze sonuçları artık gizem listesine karışmaz.
- Antik sonuçlar yalnız arkeolojik alan, kalıntı, nekropol, tümülüs, mezar ve tapınak kategorilerinden gelir.
- Gizemli/efsaneli sonuçlar yalnız bölgeyle coğrafi bağı olan yerleşik anlatılar ve kaynaklı Türkçe Vikipedi özetlerinden gelir.
- Başka şehirden sonuç doldurma kaldırıldı; kategori eşleşmiyorsa açıkça sonuç bulunamadığı yazılır.
