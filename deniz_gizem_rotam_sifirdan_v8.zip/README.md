# Deniz ve Gizem Rotam — V15

Bu sürüm günlük rota planı ile yöresel/meşhur yemek kartlarındaki iki temel hatayı düzeltir.

## V15 yenilikleri

- Günlük gezi kartları artık “Yakında uygun sonuç bulunamadı” satırlarıyla boş kalmaz.
- Her gün için saatli bir plan hazırlanır: sabah deniz, öğlen ekonomik yemek, öğleden sonra tarih/gizem, akşam ekonomik konaklama.
- Yerleşik somut yer varsa doğrudan tam adı gösterilir.
- Somut kayıt yoksa başka şehirden rastgele yer doldurulmaz; günlük durağın adıyla bölge kilitli canlı harita araması gösterilir.
- Günlük rota içindeki arama kartları artık yalnız koordinatı değil, doğru arama sorgusunu açar.
- “Marmaris Muğla”, “İznik Bursa”, “Kıyıkışlacık Milas” gibi ilçe + il girişlerinde en özgül bölge seçilir.
- Yöresel lezzet ekranında mekan adları tek kelimeye kırpılmaz; tam mekan adı, yemek türü ve ne yenebileceği birlikte gösterilir.
- Marmaris için Gurman Atlas / Vedat Milor kayıtları tam adlarıyla gösterilir.
- Vedat Milor/Gurman Atlas kaydı, fiyat doğrulanmadan “ekonomik” kabul edilmez; ekonomik ana yemek listesinden ayrı tutulur.
- Pastane, kafe, tatlıcı, zincir, resort, spa ve lüks seçenekleri dışarıda tutan filtreler korunur.

Sürüm: `15.0-gunluk-plan-yoresel-duzeltme`
