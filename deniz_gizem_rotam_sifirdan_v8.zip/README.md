# Deniz Gizem Rotam

Sürüm: **26.0-ulusal-dogrulanmis-yemek-katalogu**

Türkiye genelinde deniz, rota, ekonomik yemek, gizem ve konaklama araştırması yapan Android uygulaması.

V26 ile yemek araması ikiye ayrılmıştır:

- Kaynakla doğrulanmış köklü/meşhur işletmeler
- Seçilen merkeze veya telefon konumuna göre yakın ekonomik alternatifler

Pide, köfte ve kebapta canlı popülerlik “en eski” sayılmaz. Doğrulanmış tarihçe kaydı yoksa uygulama bunu açıkça belirtir.
