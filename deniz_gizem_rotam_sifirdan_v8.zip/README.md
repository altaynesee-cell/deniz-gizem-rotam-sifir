# Deniz Gizem Rotam — V26

Sürüm: **26.0-dogrulanmis-mekan-katalogu**

Bu sürümde pide, köfte ve kebap için “en eski / meşhur” kartları yalnız kaynakla doğrulanmış katalogdan gelir. Canlı harita sonuçları üst karta çıkmaz; yalnız **Alternatifleri Göster** bölümünde görünür.

Yeni doğrulanmış kayıtlar:
- Şanlıurfa: Şark Kebap — 1959
- İzmir / Ödemiş: Meşhur Tarihi Töngül Pide Fırını — 1892
- Bursa: Besler İnegöl Köftecisi — 1893
- Bursa: Kebapçı İskender / Tarihi Mavi Dükkân — 1867
- Bursa: Acı Dayı Cantık Salonu — 1959
- Antalya: Piyazcı Sami — 1933

Önemli: 81 ilin tamamında doğrulanmış işletme kaydı henüz yoksa uygulama rastgele popüler bir işletmeyi “en eski” diye göstermez; açıkça katalogda doğrulanmış kayıt bulunmadığını söyler ve yakın seçenekleri alternatif olarak sunar.
