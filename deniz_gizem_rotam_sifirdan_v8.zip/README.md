# Deniz Gizem Rotam

Sürüm: **23.0-turkiye-geneli-tutarli-rota**

Bu sürüm Türkiye genelindeki il, ilçe, köy, mahalle, koy ve rota duraklarında bölge tutarlılığı ile günlük gezi planını güçlendirir.

## V23 düzeltmeleri

- Telefon konumu ters konumlandırma ile gerçek ilçe/mahalle adına bağlanır; yemek ve konaklama sonuçları bu merkeze göre sıralanır.
- İl merkezi aramalarında çevre yarıçapı il ölçeğine genişler. Bursa gibi aramalarda yakın göl ve kıyı seçenekleri araştırılır.
- İlçe, köy ve koy aramalarında daha dar bölge kilidi kullanılır; başka şehirden alakasız sonuç doldurulmaz.
- Efsane ve rivayet sonuçları yalnız bölge adı içerikte geçiyorsa veya yer bölgenin yakınındaysa gösterilir.
- Kur'an, genel din ve mitoloji sayfaları yerel efsane sonucu olarak gösterilmez.
- Dalyan/Kaunos ve Ölüdeniz/Belcekız anlatıları yerleşik kaynak özetine eklenmiştir.
- Günlük rota, tur programı biçiminde deniz, ekonomik yemek, antik/tarihî keşif, yakın ek gezilecek yerler ve ekonomik konaklama sunar.
- Plaj seçiminde dalga ve rüzgârı yüksek adaylar geri plana atılır; sakin seçenek doğrulanamazsa durum açıkça belirtilir.
- Her rota durağının araştırması süre sınırına alınmıştır; tek bir servis gecikmesi tüm planı bozmaz.
