# Deniz ve Gizem Rotam — V11

Bu sürüm tek bir şehre özel yama değildir. Türkiye genelindeki il, ilçe, belde ve turistik bölge girişleri için **genel bölge kilidi** uygular.

## V11 düzeltmeleri

- `Bursa, İznik`, `Muğla, Fethiye`, `Antalya / Kaş`, `Mersin / Tarsus` gibi girişlerde daha özel yer seçilir.
- Yer adı Open-Meteo ve Nominatim sonuçları içinden il/ilçe eşleşmesine göre puanlanır; ilk rastgele sonuç kabul edilmez.
- Plaj ve gizem sonuçları seçilen merkezin sınırlı kilometre çevresinden gelir; uzak şehirden sonuç doldurulmaz.
- Yemek araması 5 km, konaklama 7 km çevresine kilitlidir.
- Yemekte yalnız aile/esnaf lokantası, ev yemekleri, sulu yemek, kebap, pide, lahmacun, döner, köfte ve benzeri ekonomik türler kabul edilir.
- Pastane, kafe, tatlıcı, unlu mamuller, burger, pizza ve pahalı turistik türler elenir.
- Konaklamada pansiyon, apart, kamp, karavan, hostel, motel ve açıkça ekonomik küçük oteller kabul edilir.
- Resort, spa, lüks, deluxe, premium ve 4–5 yıldızlı tesisler elenir.
- Canlı açık harita araması en fazla birkaç saniye beklenir. Servis yavaşsa başka şehirden yanlış sonuç yerine seçilen bölgeye kilitli harita arama kartı gösterilir.
- Fiyatlar kesinmiş gibi uydurulmaz; yalnız `2026 tahmini fiyat bandı` olarak gösterilir ve güncel doğrulama istenir.

Sürüm: `11.0-genel-bolge-kilidi`
