# Deniz ve Gizem Rotam — V16

Bu sürümde araştırma sonuçları Google aramasına bırakılmaz. Yerleşik bölge kataloğu ile canlı açık veri sonuçları uygulamanın içinde birleştirilir.

## V16 yenilikleri

- Plaj, yemek, konaklama ve tarih/gizem aramalarındaki genel Google arama kartları kaldırıldı.
- Yerleşik sonuçlar hemen görünür; canlı OpenStreetMap sonuçları uygulamanın içine eklenir.
- Sonuç bulunamazsa başka şehirden yer gösterilmez ve Google aramasına gönderilmez.
- Efsane/rivayet ve yöresel lezzet bölümüne uygulama içi Türkçe Wikipedia özetleri eklendi.
- Yöresel lezzet ekranında yakın ekonomik aile/esnaf lokantaları canlı olarak uygulama içinde listelenir.
- Günlük rota önce hızlı hazırlanır; eksik günlük kartlar canlı açık veriyle uygulama içinde zenginleştirilir.
- Plaj kartlarındaki zemin, sığlık, rüzgâr, dalga ve metal dedektör uygunluğu bilgileri korunur.
- Harita düğmesi yalnız bulunan somut yerin konumunu açar. Harita yedeği Google yerine OpenStreetMap kullanır.
- Ekonomik yemek ve konaklama filtreleri korunur; pastane, kafe, zincir, resort, spa ve lüks seçenekler elenir.

Sürüm: `16.0-uygulama-ici-canli-arastirma`
