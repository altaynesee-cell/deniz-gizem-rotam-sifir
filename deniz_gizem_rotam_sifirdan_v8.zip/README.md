# Deniz ve Gizem Rotam — V12

Bu sürümde kendi oluşturulan rota durakları Deniz, Yemek, Gizem ve Konak ekranlarında doğrudan seçilebilir. Her manuel durak kartında dört araştırma kısayolu bulunur.

## V12 düzeltmeleri

- Manuel rota durağından bir araştırma bölümü açıldığında arama otomatik başlar.

- Kendi rotamdaki şehir/ilçe/belde durakları tüm araştırma ekranlarındaki rota seçicisine eklenir.
- Manuel durak kartından doğrudan Deniz, Yemek, Gizem veya Konak ekranı açılır.
- Kıyıkışlacık / Kıyı Kışlacık / İasos girişleri doğru Kıyıkışlacık merkezine eşlenir.
- Konum servisinin yazılan yerle zayıf eşleşen sonucu kabul edilmez; yanlış şehir sonucu engellenir.
- Plaj araması 14 km, gizem 12 km, yemek 5 km, konak 7 km bölge kilidiyle çalışır.
- Yerleşik öneriler ve canlı açık harita sonuçları birlikte gösterilir.
- Plaj kartlarında zemin, sığlık, metal dedektör hobisi, güncel bölgesel rüzgâr ve dalga bilgisi bulunur.
- Güncel deniz koşulları her plaj için ayrı ayrı değil, bölge başına tek istekle alınır; bekleme azaltılır.

Sürüm: `12.0-manuel-rota-deniz-profili`
