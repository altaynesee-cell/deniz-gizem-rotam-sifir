# Deniz Gizem Rotam

Sürüm: **26.0-dogrulanmis-katalog-yakin-alternatif**

## V25

- Türkiye'nin 81 ili için ortak il kilidi uygulanır.
- İl, ilçe, köy, mahalle ve koy aramalarında canlı sonuçlar yalnız aynı il içinde tutulur.
- Sınır bölgelerinde komşu ülke ve komşu il sonuçları elenir.
- Plaj, yemek, konaklama, antik yer, kale/mağara ve efsane aramaları aynı il kuralını kullanır.
- 81 ilin tamamı için yöresel imza lezzeti profili bulunur.
- Pide, köfte ve kebapta yalnız kuruluş yılı kaynakla doğrulanmış işletmeler öne çıkar; doğrulanmayan yerler alternatiflerde kalır.
- Efsane/rivayet bulunamazsa alakasız genel metin veya başka şehir sonucu gösterilmez.


## V26 — Doğrulanmış köklü katalog + yakın alternatifler
- Pide, köfte ve kebapta üst kartlar yalnız kaynakla doğrulanmış kuruluş yılı kataloğundan gelir.
- Şanlıurfa kebap, İzmir pide/köfte, Antalya, Manisa, İstanbul, Edirne ve farklı illerden yeni köklü işletmeler eklendi.
- Pide fırını adındaki gerçek pidecilerin yanlışlıkla elenmesi düzeltildi.
- Alternatif arama terimleri ve il/ilçe yarıçapları genişletildi.
- Zincir ve alakasız işletmeler öne çıkan kartlara alınmaz.
