# Deniz ve Gizem Rotam — V13

Bu sürümde rota duraklarına iki yeni araştırma katmanı eklendi: **Efsane İzleri** ve **Yörenin Meşhur Lezzeti**.

## V13 yenilikleri

- Yemek ekranında **Yörenin meşhur lezzetini bul** butonu bulunur.
- Gizem ekranında **Efsane, rivayet ve söylentileri araştır** butonu bulunur.
- Kendi rotandaki her durakta Deniz, Yemek, Gizem, Efsane, Yöresel ve Konak kısayolları birlikte çalışır.
- Hazır rotadaki her günlük durakta da Efsane İzleri ve Yöresel Lezzet kısayolları vardır.
- Efsane sonuçları bilinen tarih, yerel sözlü anlatı ve modern söylenti olarak ayrılır.
- Uygulamanın bildiği bölgesel anlatılar hemen gösterilir; ayrıca canlı kaynak araştırması açılır.
- Yöresel lezzet ekranı bölgenin imza yemeğini, köklü/meşhur işletme araştırmasını ve ekonomik aile/esnaf lokantalarını birlikte sunar.
- Yerleşik katalogda bulunmayan bölgeler için başka şehirden yemek veya efsane uydurulmaz; yalnız seçilen bölgeye kilitli canlı araştırma kartları açılır.
- Harita ve kaynak araştırması ayrı butonlardır.
- Mevcut V12 manuel rota, plaj profili, rüzgâr, dalga, sığlık ve metal dedektör uygunluğu özellikleri korunur.

Sürüm: `13.0-efsane-yoresel-lezzet`
