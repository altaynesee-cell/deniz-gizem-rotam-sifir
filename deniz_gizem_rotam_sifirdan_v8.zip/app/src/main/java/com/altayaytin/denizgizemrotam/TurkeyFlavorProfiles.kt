package com.altayaytin.denizgizemrotamsifir

import java.util.Locale

/**
 * 81 il için yöreyle yaygın biçimde ilişkilendirilen imza lezzetler.
 * Bu liste işletme için "en eski" iddiası taşımaz; o iddia yalnız
 * SpecialCatalog içindeki kaynakla doğrulanmış işletmelerde kullanılır.
 */
internal object TurkeyFlavorProfiles {
    internal data class Profile(val province: String, val dishes: String)
    private val tr = Locale("tr", "TR")

    private val profiles = listOf(
        Profile("Adana", "Adana kebabı ve şalgam"),
        Profile("Adıyaman", "çiğ köfte ve Besni tavası"),
        Profile("Afyonkarahisar", "Afyon sucuğu, kaymak ve keşkek"),
        Profile("Ağrı", "Abdigör köftesi"),
        Profile("Amasya", "bakla dolması ve Amasya çöreği"),
        Profile("Ankara", "Ankara tava ve Beypazarı güveci"),
        Profile("Antalya", "tahinli Antalya piyazı ve şiş köfte"),
        Profile("Artvin", "silor ve puçuko"),
        Profile("Aydın", "Aydın pidesi ve Çine köftesi"),
        Profile("Balıkesir", "höşmerim, Balıkesir kaymaklısı ve yerel köfte"),
        Profile("Bilecik", "Bilecik güveci"),
        Profile("Bingöl", "sorina pel"),
        Profile("Bitlis", "büryan kebabı"),
        Profile("Bolu", "Mengen pilavı ve aşçı yemekleri"),
        Profile("Burdur", "Burdur şiş"),
        Profile("Bursa", "İskender kebap, pideli köfte ve cantık"),
        Profile("Çanakkale", "peynir helvası ve sardalya"),
        Profile("Çankırı", "yaren güveci"),
        Profile("Çorum", "İskilip dolması ve leblebi"),
        Profile("Denizli", "Denizli kebabı"),
        Profile("Diyarbakır", "Diyarbakır ciğeri ve kaburga dolması"),
        Profile("Edirne", "Edirne tava ciğeri"),
        Profile("Elazığ", "Harput köftesi ve orcik"),
        Profile("Erzincan", "kesme çorba ve Erzincan tulumu"),
        Profile("Erzurum", "cağ kebabı ve kadayıf dolması"),
        Profile("Eskişehir", "çibörek ve balaban kebabı"),
        Profile("Gaziantep", "baklava, beyran ve kebaplar"),
        Profile("Giresun", "karalahana diblesi ve fasulye diblesi"),
        Profile("Gümüşhane", "pestil, köme ve siron"),
        Profile("Hakkâri", "keledoş"),
        Profile("Hatay", "tepsi kebabı, künefe ve oruk"),
        Profile("Isparta", "kabune pilavı"),
        Profile("Mersin", "tantuni, humus ve cezerye"),
        Profile("İstanbul", "Sultanahmet köftesi, balık ekmek ve saray mutfağı"),
        Profile("İzmir", "boyoz, kumru, söğüş ve Ege otları"),
        Profile("Kars", "kaz eti, hangel ve gravyer"),
        Profile("Kastamonu", "banduma, tirit ve etli ekmek"),
        Profile("Kayseri", "mantı, pastırma ve yağlama"),
        Profile("Kırklareli", "papara ve hardaliye"),
        Profile("Kırşehir", "çullama ve madımak"),
        Profile("Kocaeli", "İzmit pişmaniyesi ve Kandıra yoğurdu"),
        Profile("Konya", "etli ekmek, fırın kebabı ve bamya çorbası"),
        Profile("Kütahya", "cimcik ve Kütahya güveci"),
        Profile("Malatya", "analı kızlı ve kayısılı yemekler"),
        Profile("Manisa", "Manisa kebabı ve mesir macunu"),
        Profile("Kahramanmaraş", "Maraş dondurması ve eli böğründe"),
        Profile("Mardin", "kaburga dolması ve sembusek"),
        Profile("Muğla", "Çökertme kebabı ve Muğla köftesi"),
        Profile("Muş", "herse ve Muş köftesi"),
        Profile("Nevşehir", "testi kebabı ve düğü çorbası"),
        Profile("Niğde", "Niğde tava"),
        Profile("Ordu", "melocan kavurması ve pancar çorbası"),
        Profile("Rize", "muhlama ve Rize kavurması"),
        Profile("Sakarya", "ıslama köfte"),
        Profile("Samsun", "Bafra pidesi ve kaz tiridi"),
        Profile("Siirt", "perde pilavı ve büryan"),
        Profile("Sinop", "Sinop mantısı ve nokul"),
        Profile("Sivas", "Sivas köftesi ve madımak"),
        Profile("Tekirdağ", "Tekirdağ köftesi"),
        Profile("Tokat", "Tokat kebabı"),
        Profile("Trabzon", "Akçaabat köftesi ve kuymak"),
        Profile("Tunceli", "babuko ve zerfet"),
        Profile("Şanlıurfa", "çiğ köfte, Urfa kebabı ve lahmacun"),
        Profile("Uşak", "Uşak tarhanası ve döndürme"),
        Profile("Van", "Van kahvaltısı ve keledoş"),
        Profile("Yozgat", "arabaşı ve testi kebabı"),
        Profile("Zonguldak", "Ereğli pidesi ve malay"),
        Profile("Aksaray", "Aksaray tava ve soğanlama"),
        Profile("Bayburt", "lor dolması ve galacoş"),
        Profile("Karaman", "batırık ve calla"),
        Profile("Kırıkkale", "Keskin tava"),
        Profile("Batman", "şam böreği ve içli köfte"),
        Profile("Şırnak", "kutlık ve serbidev"),
        Profile("Bartın", "Amasra salatası ve pirinçli mantı"),
        Profile("Ardahan", "kaz eti ve hengel"),
        Profile("Iğdır", "bozbaş ve taş köfte"),
        Profile("Yalova", "Yalova sütlüsü ve yöresel köfte"),
        Profile("Karabük", "Safranbolu bükmesi ve kuyu kebabı"),
        Profile("Kilis", "Kilis tava ve oruk"),
        Profile("Osmaniye", "tirşik ve kömbe"),
        Profile("Düzce", "melengücceği tatlısı ve Düzce köftesi")
    )

    private val byKey = profiles.associateBy { key(it.province) }

    fun forCenter(center: GeoPoint): Profile? {
        val province = center.province?.takeIf { it.isNotBlank() }
            ?: TurkeyRegions.resolveProvince(center.name, center.latitude, center.longitude)
            ?: return null
        return byKey[key(province)]
    }

    private fun key(value: String): String = value.lowercase(tr)
        .replace('ı', 'i').replace('ğ', 'g').replace('ü', 'u')
        .replace('ş', 's').replace('ö', 'o').replace('ç', 'c')
        .replace(Regex("[^a-z0-9]+"), " ").trim()
}
