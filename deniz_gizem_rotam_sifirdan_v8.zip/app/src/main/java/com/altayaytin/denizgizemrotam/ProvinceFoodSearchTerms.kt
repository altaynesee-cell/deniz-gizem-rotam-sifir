package com.altayaytin.denizgizemrotamsifir

import java.util.Locale

/**
 * Türkiye genelinde kategoriye özel canlı işletme arama terimleri.
 *
 * Amaç, yalnız "restoran" aramak yerine seçilen ilin kendi yemek adlarını da
 * sorguya katmaktır. Bu katman kuruluş yılı iddiası üretmez; doğrulanmış köklü
 * işletmeler SpecialCatalog tarafından ayrı gösterilir.
 */
internal object ProvinceFoodSearchTerms {
    private val tr = Locale("tr", "TR")

    private val provinceOverrides: Map<String, Map<FoodKind, List<String>>> = mapOf(
        "sanliurfa" to mapOf(
            FoodKind.KEBAB to listOf("Urfa kebabı", "ciğer kebabı", "patlıcan kebabı", "kebapçı"),
            FoodKind.PIDE to listOf("Urfa lahmacunu", "lahmacun", "pide salonu")
        ),
        "izmir" to mapOf(
            FoodKind.PIDE to listOf("Ödemiş Töngül pide", "Ödemiş pidesi", "pide salonu", "lahmacun"),
            FoodKind.KOFTE to listOf("Selçuk köftesi", "köfteci"),
            FoodKind.KEBAB to listOf("çöp şiş", "kebapçı", "ocakbaşı")
        ),
        "bursa" to mapOf(
            FoodKind.PIDE to listOf("Bursa cantık", "cantık salonu", "pideci"),
            FoodKind.KOFTE to listOf("İnegöl köftesi", "pideli köfte", "köfteci"),
            FoodKind.KEBAB to listOf("Bursa kebabı", "İskender kebap", "kebapçı")
        ),
        "antalya" to mapOf(
            FoodKind.KOFTE to listOf("Antalya şiş köfte", "piyaz köfte", "köfteci"),
            FoodKind.KEBAB to listOf("Antalya kebap", "kebapçı", "ocakbaşı")
        ),
        "gaziantep" to mapOf(
            FoodKind.KEBAB to listOf("Gaziantep kebabı", "patlıcan kebabı", "küşleme", "kebapçı")
        ),
        "adana" to mapOf(
            FoodKind.KEBAB to listOf("Adana kebabı", "ciğer kebabı", "kebapçı", "ocakbaşı")
        ),
        "mersin" to mapOf(
            FoodKind.KEBAB to listOf("Tarsus kebabı", "tantuni", "kebapçı"),
            FoodKind.PIDE to listOf("lahmacun", "pide salonu")
        ),
        "konya" to mapOf(
            FoodKind.PIDE to listOf("etli ekmek", "bıçak arası", "pide salonu"),
            FoodKind.KEBAB to listOf("Konya fırın kebabı", "kebapçı")
        ),
        "samsun" to mapOf(
            FoodKind.PIDE to listOf("Bafra pidesi", "Çarşamba pidesi", "pideci")
        ),
        "zonguldak" to mapOf(
            FoodKind.PIDE to listOf("Karadeniz Ereğli pidesi", "Ereğli pidesi", "pideci")
        ),
        "aydin" to mapOf(
            FoodKind.PIDE to listOf("Aydın pidesi", "Nazilli pidesi", "pideci"),
            FoodKind.KOFTE to listOf("Çine köftesi", "köfteci")
        ),
        "tekirdag" to mapOf(
            FoodKind.KOFTE to listOf("Tekirdağ köftesi", "köfteci")
        ),
        "sakarya" to mapOf(
            FoodKind.KOFTE to listOf("ıslama köfte", "Adapazarı köftesi", "köfteci")
        ),
        "trabzon" to mapOf(
            FoodKind.KOFTE to listOf("Akçaabat köftesi", "köfteci"),
            FoodKind.PIDE to listOf("Trabzon pidesi", "Sürmene pidesi", "pideci")
        ),
        "sivas" to mapOf(
            FoodKind.KOFTE to listOf("Sivas köftesi", "köfteci")
        ),
        "manisa" to mapOf(
            FoodKind.KOFTE to listOf("Akhisar köftesi", "odun köfte", "köfteci"),
            FoodKind.KEBAB to listOf("Manisa kebabı", "kebapçı")
        ),
        "isparta" to mapOf(
            FoodKind.KEBAB to listOf("Isparta fırın kebabı", "kebapçı"),
            FoodKind.PIDE to listOf("pide salonu", "pideci")
        ),
        "denizli" to mapOf(
            FoodKind.KEBAB to listOf("Denizli kebabı", "kebapçı")
        ),
        "erzurum" to mapOf(
            FoodKind.KEBAB to listOf("cağ kebabı", "cağ kebap", "kebapçı")
        ),
        "hatay" to mapOf(
            FoodKind.KEBAB to listOf("tepsi kebabı", "kağıt kebabı", "kebapçı"),
            FoodKind.PIDE to listOf("lahmacun", "pide salonu")
        ),
        "diyarbakir" to mapOf(
            FoodKind.KEBAB to listOf("Diyarbakır ciğeri", "ciğer kebabı", "kebapçı")
        ),
        "bitlis" to mapOf(
            FoodKind.KEBAB to listOf("büryan kebabı", "büryancı")
        ),
        "siirt" to mapOf(
            FoodKind.KEBAB to listOf("Siirt büryanı", "büryancı")
        ),
        "tokat" to mapOf(
            FoodKind.KEBAB to listOf("Tokat kebabı", "kebapçı")
        ),
        "mugla" to mapOf(
            FoodKind.KEBAB to listOf("Çökertme kebabı", "kebapçı"),
            FoodKind.KOFTE to listOf("Muğla köftesi", "köfteci")
        )
    )

    fun forCenter(center: GeoPoint, kind: FoodKind): List<String> {
        val province = center.province?.takeIf { it.isNotBlank() }
            ?: TurkeyRegions.resolveProvince(center.name, center.latitude, center.longitude)
        val provinceKey = normalize(province.orEmpty())
        val base = when (kind) {
            FoodKind.PIDE -> listOf("pideci", "pide salonu", "lahmacun")
            FoodKind.KOFTE -> listOf("köfteci", "köfte salonu")
            FoodKind.ESNAF -> listOf("esnaf lokantası", "aile lokantası", "lokanta")
            FoodKind.KEBAB -> listOf("kebapçı", "ocakbaşı", "dönerci", "ciğerci")
            FoodKind.SULU -> listOf("ev yemekleri", "sulu yemek", "tabldot", "çorbacı")
            FoodKind.ALL -> listOf("esnaf lokantası", "ev yemekleri", "pideci", "köfteci", "kebapçı")
        }
        val overrideTerms = provinceOverrides[provinceKey]?.get(kind).orEmpty()
        val profileTerms = TurkeyFlavorProfiles.forCenter(center)
            ?.dishes
            ?.split(Regex("\\s+ve\\s+|,"))
            ?.map { it.trim() }
            ?.filter { dishMatchesKind(it, kind) }
            .orEmpty()

        return (overrideTerms + profileTerms + base)
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .distinctBy(::normalize)
            .take(6)
    }

    private fun dishMatchesKind(value: String, kind: FoodKind): Boolean {
        val text = normalize(value)
        return when (kind) {
            FoodKind.PIDE -> listOf("pide", "lahmacun", "etli ekmek", "cantik", "sembusek").any { it in text }
            FoodKind.KOFTE -> "kofte" in text
            FoodKind.KEBAB -> listOf("kebap", "kebab", "ciger", "buryan", "tandir", "tantuni", "cop sis").any { it in text }
            FoodKind.ESNAF, FoodKind.SULU, FoodKind.ALL -> false
        }
    }

    private fun normalize(value: String): String = value.lowercase(tr)
        .replace('ı', 'i').replace('ğ', 'g').replace('ü', 'u')
        .replace('ş', 's').replace('ö', 'o').replace('ç', 'c')
        .replace(Regex("[^a-z0-9]+"), " ").trim()
}
