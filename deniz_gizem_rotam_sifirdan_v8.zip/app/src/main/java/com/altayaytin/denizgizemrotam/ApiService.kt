package com.altayaytin.denizgizemrotamsifir

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.delay
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

internal object ApiService {
    private const val USER_AGENT = "DenizGizemRotam/17.0 Android"
    @Volatile private var geoapifyApiKey: String = ""

    fun configureGeoapifyApiKey(value: String) {
        geoapifyApiKey = value.trim()
    }

    private fun requireGeoapifyApiKey(): String = geoapifyApiKey
        .takeIf { it.isNotBlank() }
        ?: throw IllegalStateException("Geoapify API anahtarı kayıtlı değil.")
    private val trLocale = Locale("tr", "TR")
    private const val SEARCH_CACHE_MS = 15 * 60 * 1000L
    private data class CachedSearch(val savedAt: Long, val items: List<PlaceItem>)
    private val searchCache = ConcurrentHashMap<String, CachedSearch>()
    private val searchableCategories = listOf(
        PoiCategory.BEACH,
        PoiCategory.FOOD,
        PoiCategory.MYSTERY,
        PoiCategory.STAY
    )

    private val knownPlaces = listOf(
        GeoPoint("Bursa", 40.1950, 29.0600),
        GeoPoint("Gölyazı", 40.1700, 28.6900),
        GeoPoint("Kıyıkışlacık", 37.280799, 27.581603),
        GeoPoint("İznik", 40.4297, 29.7210),
        GeoPoint("Mudanya", 40.3764, 28.8833),
        GeoPoint("Trilye", 40.3912, 28.7958),
        GeoPoint("Gemlik", 40.4309, 29.1597),
        GeoPoint("Orhangazi", 40.4892, 29.3089),
        GeoPoint("Balıkesir", 39.6484, 27.8826),
        GeoPoint("Erdek", 40.3995, 27.7930),
        GeoPoint("Çanakkale", 40.1467, 26.4086),
        GeoPoint("Assos", 39.4897, 26.3367),
        GeoPoint("Ayvalık", 39.3193, 26.6953),
        GeoPoint("Dikili", 39.0737, 26.8887),
        GeoPoint("Foça", 38.6675, 26.7570),
        GeoPoint("İzmir", 38.4237, 27.1428),
        GeoPoint("Çeşme", 38.3244, 26.3028),
        GeoPoint("Alaçatı", 38.2822, 26.3741),
        GeoPoint("Sığacık", 38.1960, 26.7830),
        GeoPoint("Seferihisar", 38.1970, 26.8380),
        GeoPoint("Kuşadası", 37.8597, 27.2597),
        GeoPoint("Efes", 37.9390, 27.3410),
        GeoPoint("Aydın", 37.8450, 27.8396),
        GeoPoint("Didim", 37.3769, 27.2668),
        GeoPoint("Bodrum", 37.0344, 27.4305),
        GeoPoint("Datça", 36.7279, 27.6865),
        GeoPoint("Marmaris", 36.8550, 28.2742),
        GeoPoint("Muğla", 37.2153, 28.3636),
        GeoPoint("Akyaka", 37.0550, 28.3240),
        GeoPoint("Dalyan", 36.8345, 28.6450),
        GeoPoint("Fethiye", 36.6210, 29.1164),
        GeoPoint("Ölüdeniz", 36.5492, 29.1150),
        GeoPoint("Kalkan", 36.2651, 29.4142),
        GeoPoint("Kaş", 36.2021, 29.6377),
        GeoPoint("Antalya", 36.8969, 30.7133),
        GeoPoint("Side", 36.7662, 31.3892),
        GeoPoint("Alanya", 36.5444, 31.9954),
        GeoPoint("Mersin", 36.8121, 34.6415),
        GeoPoint("Tarsus", 36.9177, 34.8928),
        GeoPoint("Adana", 37.0000, 35.3213),
        GeoPoint("Eskişehir", 39.7767, 30.5206),
        GeoPoint("Ankara", 39.9334, 32.8597),
        GeoPoint("Konya", 37.8746, 32.4932),
        GeoPoint("Afyonkarahisar", 38.7507, 30.5567),
        GeoPoint("Denizli", 37.7765, 29.0864)
    )

    suspend fun geocode(query: String): GeoPoint = withTimeout(6_000) {
        withContext(Dispatchers.IO) {
            val cleaned = normalizeLocationInput(query)
            findKnownPlace(cleaned)?.let { return@withContext it }

            val candidates = geocodeCandidates(cleaned).take(3)
            var lastError: Throwable? = null
            for (candidate in candidates) {
                runCatching { geocodeGeoapify(candidate, cleaned) }
                    .recoverCatching { geocodeNominatim(candidate, cleaned) }
                    .recoverCatching { geocodeOpenMeteo(candidate, cleaned) }
                    .onSuccess { return@withContext it }
                    .onFailure { lastError = it }
            }
            throw IllegalStateException("Konum bulunamadı: ${cleanRegionName(cleaned)}", lastError)
        }
    }

    suspend fun createSmartRoute(
        startQuery: String,
        endQuery: String,
        days: Int,
        variant: Int = 0,
        viaQueries: List<String> = emptyList()
    ): RoutePlan = withTimeout(20_000) {
        withContext(Dispatchers.IO) {
            val requestedQueries = buildList {
                add(startQuery)
                addAll(viaQueries.take(10))
                add(endQuery)
            }
            val requestedPoints = requestedQueries.map { geocode(it) }
            val effectiveDays = maxOf(days, requestedPoints.size).coerceAtMost(14)

            // Yol çizimi isteğe bağlı harita uygulamasına bırakılır. Burada ağ
            // beklemeden yaklaşık mesafe ve süre hesaplanır; rota düğmesi takılmaz.
            val routeResult = approximateRoute(requestedPoints)

            val anchors = buildDailyAnchors(requestedPoints, effectiveDays, variant)
            val stops = buildStops(anchors, variant)

            RoutePlan(
                startName = cleanRegionName(requestedPoints.first().name),
                endName = cleanRegionName(requestedPoints.last().name),
                days = anchors.size,
                distanceKm = routeResult.distanceKm,
                durationHours = routeResult.durationHours,
                stops = stops,
                kind = RouteKind.CUSTOM,
                variant = variant
            )
        }
    }

    suspend fun createAegeanMediterraneanTour(
        days: Int = 10,
        variant: Int = 0
    ): RoutePlan = withTimeout(6_000) {
        withContext(Dispatchers.IO) {
            val primary = listOf(
                "Ayvalık", "Foça", "Çeşme", "Kuşadası", "Didim",
                "Bodrum", "Akyaka", "Fethiye", "Kaş", "Antalya"
            )
            val alternative = listOf(
                "Assos", "Dikili", "Sığacık", "Efes", "Datça",
                "Marmaris", "Dalyan", "Ölüdeniz", "Kalkan", "Side"
            )
            val names = sampleList(if (variant % 2 == 0) primary else alternative, days)
            val anchors = names.mapNotNull(::findKnownPlace)
            if (anchors.size < 2) throw IllegalStateException("Hazır rota durakları yüklenemedi.")

            val routeResult = approximateRoute(anchors)
            val stops = buildStops(anchors, variant)

            RoutePlan(
                startName = anchors.first().name,
                endName = anchors.last().name,
                days = anchors.size,
                distanceKm = routeResult.distanceKm,
                durationHours = routeResult.durationHours,
                stops = stops,
                kind = RouteKind.AEGEAN_MEDITERRANEAN,
                variant = variant
            )
        }
    }

    suspend fun enrichRoutePlan(plan: RoutePlan): RoutePlan = withTimeout(18_000) {
        withContext(Dispatchers.IO) {
            val anchors = plan.stops.map { GeoPoint(it.name, it.latitude, it.longitude) }
            val candidates = runCatching { fetchTourCandidatesFast(anchors) }
                .getOrDefault(emptyMap())
            if (candidates.values.all { it.isEmpty() }) return@withContext plan

            val enrichedStops = plan.stops.mapIndexed { index, stop ->
                val anchor = GeoPoint(stop.name, stop.latitude, stop.longitude)
                fun pick(category: PoiCategory, current: PlaceItem?, maxKm: Double): PlaceItem? {
                    if (current != null) return current
                    val candidate = chooseCandidate(
                        anchor = anchor,
                        items = candidates[category].orEmpty(),
                        seed = plan.variant + index,
                        maxDistanceKm = maxKm
                    ) ?: return null
                    val planLine = when (category) {
                        PoiCategory.BEACH -> "Saat 09:00–12:30 • Deniz / kıyı keşfi"
                        PoiCategory.FOOD -> "Saat 13:00 • Ekonomik öğle yemeği"
                        PoiCategory.MYSTERY -> "Saat 15:00–18:00 • Tarih / gizem keşfi"
                        PoiCategory.STAY -> "Saat 19:00 sonrası • Ekonomik konaklama"
                        PoiCategory.WAYPOINT -> "Günlük rota durağı"
                    }
                    return enrichPlaceForDisplay(anchor, candidate).copy(
                        details = listOf(planLine, "Rota durağı: ${cleanRegionName(anchor.name)}") +
                            enrichPlaceForDisplay(anchor, candidate).details.filterNot {
                                it.startsWith("Saat ") || it.startsWith("Rota durağı:")
                            }
                    )
                }
                stop.copy(
                    beach = pick(PoiCategory.BEACH, stop.beach, 14.0),
                    food = pick(PoiCategory.FOOD, stop.food, 5.0),
                    mystery = pick(PoiCategory.MYSTERY, stop.mystery, 12.0),
                    stay = pick(PoiCategory.STAY, stop.stay, 7.0)
                )
            }
            plan.copy(stops = enrichedStops)
        }
    }

    internal fun quickPlaces(center: GeoPoint, category: PoiCategory): List<PlaceItem> {
        if (category == PoiCategory.WAYPOINT) return emptyList()
        // V17: yalnız uygulama içinde gösterilebilen somut yerler döner.
        // Google/harita arama kartları artık sonuç listesine eklenmez.
        return LocalCatalog.results(center, category)
            .filterNot { it.isSearchCard }
            .map { if (category == PoiCategory.BEACH) ensureBeachProfile(it) else it }
            .distinctBy { (it.mapSearchQuery ?: it.name).lowercase(trLocale) }
    }

    suspend fun searchPlaces(center: GeoPoint, category: PoiCategory): List<PlaceItem> =
        withContext(Dispatchers.IO) {
            if (category == PoiCategory.WAYPOINT) return@withContext emptyList()

            val cacheKey = buildSearchCacheKey(center, category)
            searchCache[cacheKey]
                ?.takeIf { System.currentTimeMillis() - it.savedAt <= SEARCH_CACHE_MS }
                ?.let { return@withContext it.items }

            // Yerleşik doğrulanmış kayıtlar anında alınır. Geoapify canlı araması küçük bir
            // yarıçapla ve kısa süre sınırıyla denenir; başka şehirden sonuç asla doldurulmaz.
            val localPlaces = LocalCatalog.results(center, category)
                .filterNot { it.isSearchCard }

            val maxDistanceKm = when (category) {
                PoiCategory.BEACH -> 14.0
                PoiCategory.MYSTERY -> 12.0
                PoiCategory.FOOD -> 5.0
                PoiCategory.STAY -> 7.0
                PoiCategory.WAYPOINT -> 0.0
            }

            val remoteItems: List<PlaceItem> = runCatching {
                withTimeout(6_000) {
                    searchGeoapifyPlaces(center, category, limit = 30)
                }
            }.getOrDefault(emptyList())

            val mergedPlaces = (localPlaces + remoteItems)
                .distinctBy { (it.mapSearchQuery ?: it.name).lowercase(trLocale) }
                .filter { haversineKm(center, it.asGeoPoint()) <= maxDistanceKm }
                .sortedWith(
                    compareBy<PlaceItem> { haversineKm(center, it.asGeoPoint()) }
                        .thenBy { it.priority }
                        .thenBy { it.name }
                )
                .take(20)

            // Canlı servis cevap vermezse yalnız yerleşik somut sonuçlar kalır.
            // Başka şehirden yer doldurulmaz ve Google aramasına yönlendiren kart eklenmez.
            val result = mergedPlaces
                .map { if (category == PoiCategory.BEACH) ensureBeachProfile(it) else it }
                .distinctBy { (it.mapSearchQuery ?: it.name).lowercase(trLocale) }

            searchCache[cacheKey] = CachedSearch(System.currentTimeMillis(), result)
            result
        }

    suspend fun searchLegendArticles(center: GeoPoint): List<PlaceItem> =
        wikipediaResearch(
            center = center,
            category = PoiCategory.MYSTERY,
            searchText = "${center.name} efsane rivayet mitoloji halk anlatısı",
            subtitle = "Uygulama içi kaynak özeti"
        )

    suspend fun searchLocalFlavorArticles(center: GeoPoint): List<PlaceItem> =
        wikipediaResearch(
            center = center,
            category = PoiCategory.FOOD,
            searchText = "${center.name} mutfağı yöresel yemek yerel lezzet",
            subtitle = "Uygulama içi yöresel kaynak özeti"
        )

    private suspend fun wikipediaResearch(
        center: GeoPoint,
        category: PoiCategory,
        searchText: String,
        subtitle: String
    ): List<PlaceItem> = withTimeout(4_000) {
        withContext(Dispatchers.IO) {
            val url = "https://tr.wikipedia.org/w/api.php" +
                "?action=query&generator=search" +
                "&gsrsearch=${encode(searchText)}&gsrnamespace=0&gsrlimit=6" +
                "&prop=extracts&exintro=1&explaintext=1&exsentences=3" +
                "&format=json&formatversion=2"
            val pages = getJson(url)
                .optJSONObject("query")
                ?.optJSONArray("pages")
                ?: JSONArray()

            buildList {
                for (index in 0 until pages.length()) {
                    val page = pages.optJSONObject(index) ?: continue
                    val title = page.optString("title").trim()
                    val extract = page.optString("extract").trim()
                    if (title.isBlank() || extract.isBlank()) continue
                    val normalized = extract.replace(Regex("\\s+"), " ").trim()
                    val shortened = if (normalized.length > 420) {
                        normalized.take(417).trimEnd() + "…"
                    } else normalized
                    add(
                        PlaceItem(
                            name = title,
                            subtitle = subtitle,
                            latitude = center.latitude,
                            longitude = center.longitude,
                            category = category,
                            priority = 50 + index,
                            note = shortened,
                            details = listOf(
                                "Kaynak: Türkçe Wikipedia uygulama içi özeti",
                                "Arama bölgesi: ${center.name}",
                                "İçerik bilgi amaçlıdır; yerel rivayet ile tarihî bilgi ayrı değerlendirilmelidir"
                            ),
                            isSearchCard = true
                        )
                    )
                }
            }.distinctBy { it.name.lowercase(trLocale) }
        }
    }

    internal fun withSeaConditions(items: List<PlaceItem>, conditions: SeaConditions): List<PlaceItem> =
        items.map { item ->
            if (item.category != PoiCategory.BEACH || item.isSearchCard) return@map item
            val wind = conditions.windSpeed
            val wave = conditions.waveHeight
            val windText = wind?.let { String.format(trLocale, "%.1f km/sa (%s)", it, windLabel(it)) } ?: "Veri yok"
            val waveText = wave?.let { String.format(trLocale, "%.1f m (%s)", it, waveLabel(it)) } ?: "Veri yok"
            val seaText = conditions.seaTemperature?.let { String.format(trLocale, "%.1f °C", it) } ?: "Veri yok"
            val hobby = hobbySuitability(item, wind, wave)
            val cleaned = item.details.filterNot {
                it.startsWith("Güncel rüzgâr:") ||
                    it.startsWith("Güncel dalga:") ||
                    it.startsWith("Deniz suyu:") ||
                    it.startsWith("Bugünkü hobi uygunluğu:")
            }
            item.copy(
                details = cleaned + listOf(
                    "Güncel rüzgâr: $windText",
                    "Güncel dalga: $waveText",
                    "Deniz suyu: $seaText",
                    "Bugünkü hobi uygunluğu: $hobby"
                )
            )
        }

    private fun ensureBeachProfile(item: PlaceItem): PlaceItem {
        if (item.category != PoiCategory.BEACH || item.isSearchCard) return item
        val details = item.details.toMutableList()
        if (details.none { it.startsWith("Zemin:") }) {
            details += "Zemin: Açık veride doğrulanmamış"
        }
        if (details.none { it.startsWith("Sığlık:") }) {
            details += "Sığlık: Kesin açık veri yok; kıyıda sahada kontrol et"
        }
        if (details.none { it.startsWith("Metal dedektör hobisi:") }) {
            val sandy = details.any { it.contains("Kum", ignoreCase = true) }
            details += if (sandy) {
                "Metal dedektör hobisi: Kumlu alan adayı; yoğunluk ve yerel izinleri kontrol et"
            } else {
                "Metal dedektör hobisi: Zemin bilgisi yetersiz; yerinde kontrol et"
            }
        }
        if (details.none { it.startsWith("Güncel rüzgâr:") }) {
            details += "Güncel rüzgâr: Canlı veri arka planda yükleniyor"
        }
        if (details.none { it.startsWith("Güncel dalga:") }) {
            details += "Güncel dalga: Canlı veri arka planda yükleniyor"
        }
        if (details.none { it.startsWith("Bugünkü hobi uygunluğu:") }) {
            details += "Bugünkü hobi uygunluğu: Rüzgâr ve dalga verisi gelince hesaplanır"
        }
        if (details.none { it.startsWith("Kaynak:") }) {
            details.add(0, "Kaynak: Yerleşik bölge önerisi")
        }
        return item.copy(details = details)
    }

    private fun hobbySuitability(item: PlaceItem, wind: Double?, wave: Double?): String {
        val text = item.details.joinToString(" ").lowercase(trLocale)
        val sandy = "zemin: kum" in text || "kumlu" in text
        val badSea = (wind != null && wind >= 28.0) || (wave != null && wave >= 0.8)
        val moderateSea = (wind != null && wind >= 18.0) || (wave != null && wave >= 0.45)
        return when {
            badSea -> "Düşük — rüzgâr/dalga yüksek"
            sandy && !moderateSea -> "Yüksek aday — kumlu ve koşullar sakin"
            sandy -> "Orta — kumlu fakat rüzgâr/dalga artmış olabilir"
            !moderateSea -> "Orta — koşullar sakin, zemin bilgisi belirsiz"
            else -> "Düşük/orta — zemin belirsiz ve koşullar hareketli"
        }
    }

    private fun windLabel(speed: Double): String = when {
        speed < 12.0 -> "sakin"
        speed < 20.0 -> "hafif/orta"
        speed < 30.0 -> "kuvvetli"
        else -> "çok kuvvetli"
    }

    internal fun nearestKnownRegion(latitude: Double, longitude: Double): String {
        val point = GeoPoint("", latitude, longitude)
        return knownPlaces.minByOrNull { haversineKm(point, it) }?.name ?: "Yakınımdaki bölge"
    }

    suspend fun getSeaConditions(latitude: Double, longitude: Double): SeaConditions =
        withTimeout(7_000) {
            withContext(Dispatchers.IO) {
            val weather = getJson(
                "https://api.open-meteo.com/v1/forecast" +
                    "?latitude=$latitude&longitude=$longitude" +
                    "&current=temperature_2m,apparent_temperature,weather_code,wind_speed_10m,wind_gusts_10m" +
                    "&timezone=auto"
            ).optJSONObject("current") ?: JSONObject()

            val marine = runCatching {
                getJson(
                    "https://marine-api.open-meteo.com/v1/marine" +
                        "?latitude=$latitude&longitude=$longitude" +
                        "&current=wave_height,wave_direction,wave_period,sea_surface_temperature" +
                        "&cell_selection=sea&timezone=auto"
                ).optJSONObject("current") ?: JSONObject()
            }.getOrElse { JSONObject() }

            SeaConditions(
                weatherText = weatherCodeText(weather.optInt("weather_code", -1)),
                airTemperature = weather.optNullableDouble("temperature_2m"),
                apparentTemperature = weather.optNullableDouble("apparent_temperature"),
                windSpeed = weather.optNullableDouble("wind_speed_10m"),
                windGust = weather.optNullableDouble("wind_gusts_10m"),
                waveHeight = marine.optNullableDouble("wave_height"),
                waveDirection = marine.optNullableDouble("wave_direction"),
                wavePeriod = marine.optNullableDouble("wave_period"),
                seaTemperature = marine.optNullableDouble("sea_surface_temperature")
            )
            }
        }

    private val provinceOnlyNames = setOf(
        "adana", "adiyaman", "afyonkarahisar", "agri", "amasya", "ankara", "antalya",
        "artvin", "aydin", "balikesir", "bilecik", "bingol", "bitlis", "bolu", "burdur",
        "bursa", "canakkale", "cankiri", "corum", "denizli", "diyarbakir", "edirne",
        "elazig", "erzincan", "erzurum", "eskisehir", "gaziantep", "giresun", "gumushane",
        "hakkari", "hatay", "isparta", "mersin", "istanbul", "izmir", "kars", "kastamonu",
        "kayseri", "kirklareli", "kirsehir", "kocaeli", "konya", "kutahya", "malatya",
        "manisa", "kahramanmaras", "mardin", "mugla", "mus", "nevsehir", "nigde", "ordu",
        "rize", "sakarya", "samsun", "siirt", "sinop", "sivas", "tekirdag", "tokat",
        "trabzon", "tunceli", "sanliurfa", "usak", "van", "yozgat", "zonguldak", "aksaray",
        "bayburt", "karaman", "kirikkale", "batman", "sirnak", "bartin", "ardahan", "igdir",
        "yalova", "karabuk", "kilis", "osmaniye", "duzce"
    )

    private val locationAliases = mapOf(
        "iznik adasi" to "İznik",
        "iznik ada" to "İznik",
        "iznik ilcesi" to "İznik",
        "iznik golu" to "İznik",
        "bursa iznik" to "İznik",
        "bursa iznik adasi" to "İznik",
        "bursa iznik ilcesi" to "İznik",
        "fethiye mugla" to "Fethiye",
        "bodrum mugla" to "Bodrum",
        "marmaris mugla" to "Marmaris",
        "datca mugla" to "Datça",
        "kas antalya" to "Kaş",
        "side antalya" to "Side",
        "alanya antalya" to "Alanya",
        "tarsus mersin" to "Tarsus",
        "erdek balikesir" to "Erdek",
        "kiyikislacik" to "Kıyıkışlacık",
        "kiyi kislacik" to "Kıyıkışlacık",
        "kiyi kislacik milas" to "Kıyıkışlacık",
        "kiyikislacik milas" to "Kıyıkışlacık",
        "kiyikislacik mugla" to "Kıyıkışlacık",
        "kiyi kislacik mugla" to "Kıyıkışlacık",
        "iasos" to "Kıyıkışlacık",
        "iassos" to "Kıyıkışlacık"
    )

    private fun normalizeLocationInput(raw: String): String {
        val special = when (raw.trim().lowercase(trLocale)) {
            "ege", "ege bölgesi" -> "İzmir"
            "akdeniz", "akdeniz bölgesi" -> "Antalya"
            else -> raw.trim()
        }
        val parts = locationParts(special)
        return parts.joinToString(", ").ifBlank { special }
    }

    private fun locationParts(raw: String): List<String> {
        val rawParts = raw
            .replace('\\', '/')
            .replace('>', '/')
            .split('/', ',', ';')
            .map { part ->
                stripAdministrativeSuffix(part)
                    .replace(Regex("\\s+"), " ")
                    .trim(' ', '-', '–')
            }
            .filter { it.isNotBlank() }

        val unique = mutableListOf<String>()
        val seen = mutableSetOf<String>()
        for (part in rawParts) {
            val alias = locationAliases[searchKey(part)] ?: part
            val key = searchKey(alias)
            if (key.isNotBlank() && seen.add(key)) unique += alias
        }
        return unique
    }

    private fun geocodeCandidates(cleaned: String): List<String> {
        val parts = locationParts(cleaned)
        val specific = mostSpecificPart(parts)
        val context = parts.filterNot { searchKey(it) == searchKey(specific) }
        return buildList {
            if (specific.isNotBlank() && context.isNotEmpty()) {
                add((listOf(specific) + context).joinToString(", ") + ", Türkiye")
            }
            if (specific.isNotBlank()) add("$specific, Türkiye")
            if (parts.isNotEmpty()) add(parts.joinToString(", ") + ", Türkiye")
            add(cleaned)
        }.distinctBy { it.lowercase(trLocale) }
    }

    private fun mostSpecificPart(parts: List<String>): String {
        if (parts.isEmpty()) return ""
        return parts.lastOrNull { searchKey(it) !in provinceOnlyNames }
            ?: parts.last()
    }

    private fun cleanRegionName(raw: String): String {
        findKnownPlace(raw)?.let { return it.name }
        val parts = locationParts(raw)
        return mostSpecificPart(parts).ifBlank { raw.trim() }
    }

    private fun stripAdministrativeSuffix(raw: String): String {
        val value = raw.trim()
        val lowered = value.lowercase(trLocale)
        val suffixes = listOf(
            " merkez ilçesi", " merkez ilcesi", " ilçesi", " ilcesi", " ili"
        )
        val suffix = suffixes.firstOrNull { lowered.endsWith(it) } ?: return value
        return value.dropLast(suffix.length).trim()
    }

    private fun findKnownPlace(query: String): GeoPoint? {
        val parts = locationParts(query)
        if (parts.isEmpty()) return null

        val fullKey = searchKey(parts.joinToString(" "))
        locationAliases[fullKey]?.let { aliasName ->
            knownPlaces.firstOrNull { searchKey(it.name) == searchKey(aliasName) }?.let { return it }
        }

        data class Scored(val point: GeoPoint, val score: Int)
        val scored = mutableListOf<Scored>()
        parts.forEachIndexed { index, part ->
            val partKey = searchKey(part)
            locationAliases[partKey]?.let { aliasName ->
                knownPlaces.firstOrNull { searchKey(it.name) == searchKey(aliasName) }?.let {
                    scored += Scored(it, 1_000 + index * 20)
                }
            }
            knownPlaces.forEach { place ->
                val placeKey = searchKey(place.name)
                val exact = partKey == placeKey
                val contained = partKey.startsWith("$placeKey ") || placeKey.startsWith("$partKey ")
                if (exact || contained) {
                    val provincePenalty = if (placeKey in provinceOnlyNames) 100 else 0
                    val score = (if (exact) 700 else 500) + index * 20 + placeKey.length - provincePenalty
                    scored += Scored(place, score)
                }
            }
        }
        return scored.maxByOrNull { it.score }?.point
    }

    private fun searchKey(value: String): String =
        value.lowercase(trLocale)
            .replace('ı', 'i')
            .replace('ğ', 'g')
            .replace('ü', 'u')
            .replace('ş', 's')
            .replace('ö', 'o')
            .replace('ç', 'c')
            .replace(Regex("[^a-z0-9]+"), " ")
            .trim()

    private fun buildDailyAnchors(
        requested: List<GeoPoint>,
        targetDays: Int,
        variant: Int
    ): List<GeoPoint> {
        if (requested.size < 2) return requested
        val days = maxOf(targetDays, requested.size).coerceAtMost(14)
        if (days == requested.size) return requested

        val segmentDistances = requested.zipWithNext { a, b -> haversineKm(a, b) }
        val total = segmentDistances.sum().takeIf { it > 0.0 } ?: 1.0
        val extraCount = days - requested.size
        val allocations = IntArray(segmentDistances.size)
        var assigned = 0

        segmentDistances.forEachIndexed { index, distance ->
            val share = (extraCount * distance / total).toInt()
            allocations[index] = share
            assigned += share
        }
        var cursor = Math.floorMod(variant, maxOf(1, allocations.size))
        while (assigned < extraCount) {
            allocations[cursor % allocations.size] += 1
            assigned += 1
            cursor += 1
        }

        val result = mutableListOf<GeoPoint>()
        val usedNames = requested.map { searchKey(it.name) }.toMutableSet()
        result += requested.first()

        for (segmentIndex in 0 until requested.lastIndex) {
            val a = requested[segmentIndex]
            val b = requested[segmentIndex + 1]
            val extras = allocations[segmentIndex]
            for (step in 1..extras) {
                val ratio = step.toDouble() / (extras + 1).toDouble()
                val raw = GeoPoint(
                    name = "",
                    latitude = a.latitude + (b.latitude - a.latitude) * ratio,
                    longitude = a.longitude + (b.longitude - a.longitude) * ratio
                )
                val candidate = knownPlaces
                    .asSequence()
                    .filter { searchKey(it.name) !in usedNames }
                    .map { it to haversineKm(raw, it) }
                    .filter { it.second <= 55.0 }
                    .sortedBy { it.second }
                    .drop(Math.floorMod(variant + step + segmentIndex, 2))
                    .firstOrNull()
                    ?.first

                val fallbackName = if (a.name == b.name) {
                    "${cleanRegionName(a.name)} çevresi"
                } else {
                    "${cleanRegionName(a.name)} – ${cleanRegionName(b.name)} güzergâhı"
                }
                val named = candidate ?: raw.copy(name = fallbackName)
                usedNames += searchKey(named.name)
                result += named
            }
            result += b
        }
        return result.take(days)
    }

    private fun approximateRoute(points: List<GeoPoint>): RouteResult {
        val directKm = points.zipWithNext { a, b -> haversineKm(a, b) }.sum()
        val roadKm = (directKm * 1.22).roundToInt().coerceAtLeast(1)
        val hours = (roadKm / 65.0).roundToInt().coerceAtLeast(1)
        return RouteResult(
            distanceKm = roadKm,
            durationHours = hours,
            geometry = points
        )
    }

    private fun geocodeGeoapify(query: String, preferredName: String): GeoPoint {
        val apiKey = requireGeoapifyApiKey()
        val url = "https://api.geoapify.com/v1/geocode/search" +
            "?text=${encode("$query, Türkiye")}" +
            "&type=locality&filter=countrycode:tr&lang=tr&limit=5&format=json" +
            "&apiKey=${encode(apiKey)}"
        val results = getJson(url).optJSONArray("results") ?: JSONArray()
        if (results.length() == 0) throw IllegalStateException("Geoapify konum sonucu vermedi.")

        val requested = searchKey(preferredName)
        val ranked = buildList {
            for (index in 0 until results.length()) {
                val item = results.optJSONObject(index) ?: continue
                val lat = item.optDouble("lat", Double.NaN)
                val lon = item.optDouble("lon", Double.NaN)
                if (lat.isNaN() || lon.isNaN()) continue
                val fields = listOf(
                    item.optString("name"), item.optString("suburb"), item.optString("district"),
                    item.optString("city"), item.optString("county"), item.optString("state"),
                    item.optString("formatted")
                ).filter { it.isNotBlank() }
                val score = fields.maxOfOrNull { field ->
                    val key = searchKey(field)
                    when {
                        key == requested -> 100
                        requested.contains(key) || key.contains(requested) -> 75
                        requested.split(' ').any { it.length > 2 && it in key } -> 45
                        else -> 0
                    }
                } ?: 0
                add(Triple(score - index, item, fields))
            }
        }.sortedByDescending { it.first }

        val best = ranked.firstOrNull()?.second ?: throw IllegalStateException("Geoapify konum sonucu okunamadı.")
        val display = listOf(
            best.optString("name"), best.optString("suburb"), best.optString("district"),
            best.optString("city"), best.optString("county")
        ).firstOrNull { it.isNotBlank() } ?: preferredName
        return GeoPoint(cleanRegionName(display), best.getDouble("lat"), best.getDouble("lon"))
    }

    private fun geoapifyCategories(category: PoiCategory): String = when (category) {
        PoiCategory.WAYPOINT -> ""
        PoiCategory.BEACH -> "beach"
        PoiCategory.FOOD -> listOf(
            "catering.restaurant",
            "catering.fast_food.kebab",
            "catering.fast_food.pita",
            "catering.fast_food.soup",
            "catering.restaurant.kebab",
            "catering.restaurant.pita",
            "catering.restaurant.soup",
            "catering.restaurant.turkish",
            "catering.restaurant.regional"
        ).joinToString(",")
        PoiCategory.MYSTERY -> listOf(
            "tourism.sights.archaeological_site",
            "tourism.sights.ruines",
            "tourism.sights.castle",
            "tourism.sights.fort",
            "tourism.sights.city_gate",
            "tourism.sights.necropolis",
            "tourism.sights.memorial.tumulus",
            "tourism.sights.monastery",
            "tourism.sights.place_of_worship",
            "tourism.attraction",
            "entertainment.museum"
        ).joinToString(",")
        PoiCategory.STAY -> listOf(
            "accommodation.guest_house",
            "accommodation.hostel",
            "accommodation.apartment",
            "accommodation.motel",
            "camping.camp_site",
            "camping.caravan_site",
            "accommodation.hotel"
        ).joinToString(",")
    }

    private fun geoapifyRadiusMeters(category: PoiCategory): Int = when (category) {
        PoiCategory.BEACH -> 18_000
        PoiCategory.MYSTERY -> 15_000
        PoiCategory.FOOD -> 6_000
        PoiCategory.STAY -> 9_000
        PoiCategory.WAYPOINT -> 0
    }

    private fun searchGeoapifyPlaces(
        center: GeoPoint,
        category: PoiCategory,
        limit: Int
    ): List<PlaceItem> {
        if (category == PoiCategory.WAYPOINT) return emptyList()
        val apiKey = requireGeoapifyApiKey()
        val categories = geoapifyCategories(category)
        val radius = geoapifyRadiusMeters(category)
        val url = "https://api.geoapify.com/v2/places" +
            "?categories=${encode(categories)}" +
            "&filter=${encode("circle:${center.longitude},${center.latitude},$radius")}" +
            "&bias=${encode("proximity:${center.longitude},${center.latitude}")}" +
            "&lang=tr&limit=${limit.coerceIn(1, 60)}" +
            "&apiKey=${encode(apiKey)}"
        val features = getJson(url).optJSONArray("features") ?: JSONArray()
        val items = mutableListOf<PlaceItem>()
        val seen = mutableSetOf<String>()
        for (index in 0 until features.length()) {
            val feature = features.optJSONObject(index) ?: continue
            val place = parseGeoapifyFeature(center, feature, category) ?: continue
            val key = "${searchKey(place.name)}:${(place.latitude * 10000).roundToInt()}:${(place.longitude * 10000).roundToInt()}"
            if (seen.add(key)) items += enrichPlaceForDisplay(center, place)
        }
        return items
    }

    private fun searchGeoapifyTourBundle(center: GeoPoint): Map<PoiCategory, List<PlaceItem>> {
        val apiKey = requireGeoapifyApiKey()
        val allCategories = searchableCategories.joinToString(",") { geoapifyCategories(it) }
        val radius = 18_000
        val url = "https://api.geoapify.com/v2/places" +
            "?categories=${encode(allCategories)}" +
            "&filter=${encode("circle:${center.longitude},${center.latitude},$radius")}" +
            "&bias=${encode("proximity:${center.longitude},${center.latitude}")}" +
            "&lang=tr&limit=60&apiKey=${encode(apiKey)}"
        val features = getJson(url).optJSONArray("features") ?: JSONArray()
        val result = searchableCategories.associateWith { mutableListOf<PlaceItem>() }
        for (index in 0 until features.length()) {
            val feature = features.optJSONObject(index) ?: continue
            searchableCategories.forEach { category ->
                parseGeoapifyFeature(center, feature, category)?.let { place ->
                    val maxKm = geoapifyRadiusMeters(category) / 1000.0
                    if (haversineKm(center, place.asGeoPoint()) <= maxKm) {
                        result.getValue(category).add(enrichPlaceForDisplay(center, place))
                    }
                }
            }
        }
        return result
    }

    private fun parseGeoapifyFeature(
        center: GeoPoint,
        feature: JSONObject,
        category: PoiCategory
    ): PlaceItem? {
        val properties = feature.optJSONObject("properties") ?: return null
        val geometry = feature.optJSONObject("geometry")
        val coordinates = geometry?.optJSONArray("coordinates")
        val lon = properties.optDouble("lon", coordinates?.optDouble(0) ?: Double.NaN)
        val lat = properties.optDouble("lat", coordinates?.optDouble(1) ?: Double.NaN)
        if (lat.isNaN() || lon.isNaN()) return null

        val name = listOf(
            properties.optString("name"),
            properties.optString("address_line1")
        ).firstOrNull { it.isNotBlank() } ?: return null
        val categoriesArray = properties.optJSONArray("categories") ?: JSONArray()
        val categories = buildList {
            for (index in 0 until categoriesArray.length()) {
                categoriesArray.optString(index).takeIf { it.isNotBlank() }?.let(::add)
            }
        }
        if (!featureMatchesCategory(categories, category)) return null

        val raw = properties.optJSONObject("datasource")
            ?.optJSONObject("raw")
            ?.let { JSONObject(it.toString()) }
            ?: JSONObject()
        when (category) {
            PoiCategory.WAYPOINT -> return null
            PoiCategory.BEACH -> {
                raw.put("natural", "beach")
                if (categories.any { it == "beach.beach_resort" }) raw.put("access", "customers")
            }
            PoiCategory.FOOD -> {
                raw.put("amenity", if (categories.any { it.startsWith("catering.fast_food") }) "fast_food" else "restaurant")
                if (raw.optString("cuisine").isBlank()) {
                    raw.put("cuisine", categories
                        .filter { it.startsWith("catering.") }
                        .joinToString(";") { it.substringAfterLast('.') })
                }
            }
            PoiCategory.MYSTERY -> {
                when {
                    categories.any { it.endsWith("archaeological_site") } -> raw.put("site_type", "archaeological_site")
                    categories.any { it.endsWith("ruines") } -> raw.put("historic", "ruins")
                    categories.any { it.endsWith("castle") } -> raw.put("historic", "castle")
                    categories.any { it.endsWith("fort") } -> raw.put("historic", "fort")
                    categories.any { it.endsWith("city_gate") } -> raw.put("historic", "city_gate")
                    categories.any { it.contains("necropolis") } -> raw.put("historic", "necropolis")
                    categories.any { it.contains("tumulus") } -> raw.put("historic", "tumulus")
                    categories.any { it == "entertainment.museum" } -> raw.put("tourism", "museum")
                    else -> raw.put("tourism", "attraction")
                }
            }
            PoiCategory.STAY -> {
                val tourism = when {
                    categories.any { it == "camping.camp_site" } -> "camp_site"
                    categories.any { it == "camping.caravan_site" } -> "caravan_site"
                    categories.any { it == "accommodation.guest_house" } -> "guest_house"
                    categories.any { it == "accommodation.hostel" } -> "hostel"
                    categories.any { it == "accommodation.apartment" } -> "apartment"
                    categories.any { it == "accommodation.motel" } -> "motel"
                    categories.any { it == "accommodation.hotel" } -> "hotel"
                    else -> ""
                }
                if (tourism.isBlank()) return null
                raw.put("tourism", tourism)
            }
        }

        val parsed = parsePlace(name, GeoPoint(name, lat, lon), raw, category) ?: return null
        val formatted = properties.optString("formatted").takeIf { it.isNotBlank() }
        val addressDetail = formatted?.let { "Adres: $it" }
        return parsed.copy(
            details = parsed.details + listOfNotNull(addressDetail),
            mapSearchQuery = formatted ?: "$name, ${center.name}"
        )
    }

    private fun featureMatchesCategory(categories: List<String>, category: PoiCategory): Boolean = when (category) {
        PoiCategory.WAYPOINT -> false
        PoiCategory.BEACH -> categories.any { it == "beach" } && categories.none { it == "beach.beach_resort" }
        PoiCategory.FOOD -> categories.any { it.startsWith("catering.restaurant") || it.startsWith("catering.fast_food") || it == "catering.food_court" }
        PoiCategory.MYSTERY -> categories.any { it.startsWith("tourism.sights") || it == "tourism.attraction" || it == "entertainment.museum" }
        PoiCategory.STAY -> categories.any { it.startsWith("accommodation.") || it.startsWith("camping.") }
    }

    private fun geocodeOpenMeteo(query: String, preferredName: String): GeoPoint {
        val json = getJson(
            "https://geocoding-api.open-meteo.com/v1/search" +
                "?name=${encode(query)}&count=10&language=tr&format=json&countryCode=TR"
        )
        val results = json.optJSONArray("results")
            ?: throw IllegalStateException("Konum bulunamadı")
        if (results.length() == 0) throw IllegalStateException("Konum bulunamadı")

        val requested = locationParts(preferredName).map(::searchKey).filter { it.isNotBlank() }
        val ranked = (0 until results.length()).map { index ->
            val item = results.getJSONObject(index)
            val fields = listOf(
                item.optString("name"), item.optString("admin1"), item.optString("admin2"),
                item.optString("admin3"), item.optString("admin4")
            ).filter { it.isNotBlank() }
            item to geocodeScore(requested, fields, index)
        }
        val best = ranked.maxByOrNull { it.second }
            ?: throw IllegalStateException("Konum bulunamadı")
        if (best.second < 300) throw IllegalStateException("Yazılan bölgeyle eşleşen konum bulunamadı")
        val item = best.first
        val resultName = cleanRegionName(preferredName).ifBlank { item.optString("name") }
        return GeoPoint(
            name = cleanRegionName(resultName),
            latitude = item.getDouble("latitude"),
            longitude = item.getDouble("longitude")
        )
    }

    private fun geocodeNominatim(query: String, preferredName: String): GeoPoint {
        val json = getJsonArray(
            "https://nominatim.openstreetmap.org/search" +
                "?q=${encode(query)}&format=jsonv2&limit=8&countrycodes=tr&accept-language=tr&addressdetails=1"
        )
        if (json.length() == 0) throw IllegalStateException("Konum bulunamadı")
        val requested = locationParts(preferredName).map(::searchKey).filter { it.isNotBlank() }
        val ranked = (0 until json.length()).map { index ->
            val item = json.getJSONObject(index)
            val address = item.optJSONObject("address")
            val fields = buildList {
                add(item.optString("name"))
                add(item.optString("display_name"))
                if (address != null) {
                    listOf("city", "town", "village", "municipality", "county", "state", "province")
                        .forEach { key -> add(address.optString(key)) }
                }
            }.filter { it.isNotBlank() }
            item to geocodeScore(requested, fields, index)
        }
        val best = ranked.maxByOrNull { it.second }
            ?: throw IllegalStateException("Konum bulunamadı")
        if (best.second < 300) throw IllegalStateException("Yazılan bölgeyle eşleşen konum bulunamadı")
        val item = best.first
        val resultName = cleanRegionName(preferredName)
            .ifBlank { item.optString("name") }
            .ifBlank { item.optString("display_name").substringBefore(',') }
        return GeoPoint(
            name = cleanRegionName(resultName),
            latitude = item.getString("lat").toDouble(),
            longitude = item.getString("lon").toDouble()
        )
    }

    private fun geocodeScore(requested: List<String>, resultFields: List<String>, index: Int): Int {
        if (requested.isEmpty()) return -index
        val resultKeys = resultFields.map(::searchKey).filter { it.isNotBlank() }
        val whole = resultKeys.joinToString(" ")
        var score = -index
        requested.forEachIndexed { reqIndex, req ->
            val exact = resultKeys.any { it == req }
            val contained = whole.contains(req) || req.contains(whole)
            score += when {
                exact -> 500 + reqIndex * 40
                contained -> 180 + reqIndex * 20
                else -> -120
            }
        }
        val specific = requested.lastOrNull { it !in provinceOnlyNames } ?: requested.last()
        if (resultKeys.firstOrNull() == specific) score += 650
        else if (resultKeys.any { it == specific }) score += 350
        return score
    }

    private data class RouteResult(
        val distanceKm: Int,
        val durationHours: Int,
        val geometry: List<GeoPoint>
    )

    private fun requestRoute(points: List<GeoPoint>, includeGeometry: Boolean): RouteResult {
        if (points.size < 2) throw IllegalArgumentException("En az iki rota noktası gerekli.")
        val coordinates = points.joinToString(";") { "${it.longitude},${it.latitude}" }
        val overview = if (includeGeometry) "full" else "false"
        val json = getJson(
            "https://router.project-osrm.org/route/v1/driving/$coordinates" +
                "?overview=$overview&geometries=geojson&steps=false"
        )
        if (json.optString("code") != "Ok") {
            throw IllegalStateException("Bu noktalar arasında araç rotası oluşturulamadı.")
        }
        val route = json.getJSONArray("routes").getJSONObject(0)
        val geometry = if (includeGeometry) {
            val coordinatesJson = route.getJSONObject("geometry").getJSONArray("coordinates")
            buildList {
                for (index in 0 until coordinatesJson.length()) {
                    val pair = coordinatesJson.getJSONArray(index)
                    add(GeoPoint("", pair.getDouble(1), pair.getDouble(0)))
                }
            }
        } else {
            points
        }
        return RouteResult(
            distanceKm = (route.optDouble("distance") / 1000.0).roundToInt(),
            durationHours = (route.optDouble("duration") / 3600.0).roundToInt(),
            geometry = geometry
        )
    }

    /**
     * Günlük rota önce yerleşik somut kayıtlarla anında hazırlanır. Sonuç yoksa
     * Google/harita arama kartı üretilmez; ilgili satır boş kalır ve kullanıcı aynı
     * bölgeyi uygulamanın Deniz/Yemek/Gizem/Konak ekranında canlı arayabilir.
     */
    private fun buildStops(
        anchors: List<GeoPoint>,
        variant: Int
    ): List<RouteStop> = anchors.mapIndexed { index, anchor ->
        val daySeed = variant + index
        RouteStop(
            day = index + 1,
            name = cleanRegionName(anchor.name),
            latitude = anchor.latitude,
            longitude = anchor.longitude,
            beach = routeSuggestionForDay(anchor, PoiCategory.BEACH, daySeed),
            food = routeSuggestionForDay(anchor, PoiCategory.FOOD, daySeed),
            mystery = routeSuggestionForDay(anchor, PoiCategory.MYSTERY, daySeed),
            stay = routeSuggestionForDay(anchor, PoiCategory.STAY, daySeed)
        )
    }

    private fun routeSuggestionForDay(
        anchor: GeoPoint,
        category: PoiCategory,
        seed: Int
    ): PlaceItem? {
        val pool = quickPlaces(anchor, category).filterNot { it.isSearchCard }
        if (pool.isEmpty()) return null
        val picked = pool[Math.floorMod(seed, pool.size)]
        val planLine = when (category) {
            PoiCategory.BEACH -> "Saat 09:00–12:30 • Deniz / kıyı keşfi"
            PoiCategory.FOOD -> "Saat 13:00 • Ekonomik öğle yemeği"
            PoiCategory.MYSTERY -> "Saat 15:00–18:00 • Tarih / gizem keşfi"
            PoiCategory.STAY -> "Saat 19:00 sonrası • Ekonomik konaklama"
            PoiCategory.WAYPOINT -> "Günlük rota durağı"
        }
        return picked.copy(
            details = listOf(planLine, "Rota durağı: ${cleanRegionName(anchor.name)}") +
                picked.details.filterNot {
                    it.startsWith("Saat ") || it.startsWith("Günlük plan:") || it.startsWith("Rota durağı:")
                }
        )
    }

    private fun chooseCandidate(
        anchor: GeoPoint,
        items: List<PlaceItem>,
        seed: Int,
        maxDistanceKm: Double
    ): PlaceItem? {
        val ranked = items
            .asSequence()
            .map { it to haversineKm(anchor, it.asGeoPoint()) }
            .filter { it.second <= maxDistanceKm }
            .sortedWith(compareBy<Pair<PlaceItem, Double>> { it.first.priority }.thenBy { it.second })
            .take(8)
            .toList()
        if (ranked.isEmpty()) return null
        val topPriority = ranked.first().first.priority
        val closeTop = ranked.filter { it.first.priority <= topPriority + 1 }.ifEmpty { ranked }
        return closeTop[Math.floorMod(seed, closeTop.size)].first
    }

    private suspend fun fetchTourCandidatesFast(
        anchors: List<GeoPoint>
    ): Map<PoiCategory, List<PlaceItem>> = coroutineScope {
        val unique = anchors
            .distinctBy { "${(it.latitude * 100).roundToInt()}:${(it.longitude * 100).roundToInt()}" }
            .take(14)

        val combined = searchableCategories.associateWith { mutableListOf<PlaceItem>() }
        unique.chunked(4).forEachIndexed { batchIndex, batch ->
            val results = batch.map { anchor ->
                async(Dispatchers.IO) {
                    runCatching { searchGeoapifyTourBundle(anchor) }.getOrDefault(emptyMap())
                }
            }.awaitAll()
            results.forEach { map ->
                searchableCategories.forEach { category ->
                    combined.getValue(category).addAll(map[category].orEmpty())
                }
            }
            if (batchIndex < unique.chunked(4).lastIndex) delay(300)
        }
        combined.mapValues { (_, items) ->
            items.distinctBy {
                "${searchKey(it.name)}:${(it.latitude * 10000).roundToInt()}:${(it.longitude * 10000).roundToInt()}"
            }
        }
    }

    private fun fetchTourCandidates(anchors: List<GeoPoint>): Map<PoiCategory, List<PlaceItem>> {
        val query = buildString {
            append("[out:json][timeout:55];(")
            anchors.forEach { point ->
                val lat = point.latitude
                val lon = point.longitude
                append("nwr(around:32000,$lat,$lon)[\"natural\"=\"beach\"][\"name\"];")
                append("nwr(around:32000,$lat,$lon)[\"natural\"=\"bay\"][\"name\"];")
                append("nwr(around:9000,$lat,$lon)[\"amenity\"~\"restaurant|fast_food|food_court\"][\"name\"];")
                append("nwr(around:32000,$lat,$lon)[\"historic\"][\"name\"];")
                append("nwr(around:32000,$lat,$lon)[\"site_type\"=\"archaeological_site\"][\"name\"];")
                append("nwr(around:32000,$lat,$lon)[\"tourism\"~\"museum|attraction\"][\"name\"];")
                append("nwr(around:32000,$lat,$lon)[\"natural\"=\"cave_entrance\"][\"name\"];")
                append("nwr(around:14000,$lat,$lon)[\"tourism\"~\"hotel|motel|guest_house|hostel|camp_site|caravan_site|apartment|chalet\"][\"name\"];")
            }
            append(");out tags center 1000;")
        }
        val json = postOverpass(query)
        val elements = json.optJSONArray("elements") ?: JSONArray()
        val result = searchableCategories.associateWith { mutableListOf<PlaceItem>() }
        val seen = searchableCategories.associateWith { mutableSetOf<String>() }

        for (index in 0 until elements.length()) {
            val element = elements.getJSONObject(index)
            val tags = element.optJSONObject("tags") ?: continue
            val name = readName(tags)
            if (name.isBlank()) continue
            val point = elementPoint(element) ?: continue
            searchableCategories.forEach { category ->
                val place = parsePlace(name, point, tags, category) ?: return@forEach
                val key = name.lowercase(trLocale)
                if (seen.getValue(category).add(key)) result.getValue(category).add(place)
            }
        }
        return result
    }

    private fun overpassQuery(center: GeoPoint, category: PoiCategory): String {
        val lat = center.latitude
        val lon = center.longitude
        return when (category) {
            PoiCategory.WAYPOINT -> "[out:json];node(0,0,0,0);out;"
            PoiCategory.BEACH -> """
                [out:json][timeout:6];
                (
                  nwr(around:14000,$lat,$lon)["natural"="beach"]["name"];
                  nwr(around:14000,$lat,$lon)["natural"="bay"]["name"];
                  nwr(around:14000,$lat,$lon)["leisure"="swimming_area"]["name"];
                );
                out tags center 180;
            """.trimIndent()

            PoiCategory.FOOD -> """
                [out:json][timeout:5];
                (
                  nwr(around:5000,$lat,$lon)["amenity"~"restaurant|fast_food|food_court"]["name"];
                );
                out tags center 160;
            """.trimIndent()

            PoiCategory.MYSTERY -> """
                [out:json][timeout:6];
                (
                  nwr(around:16000,$lat,$lon)["historic"]["name"];
                  nwr(around:16000,$lat,$lon)["site_type"="archaeological_site"]["name"];
                  nwr(around:16000,$lat,$lon)["tourism"~"museum|attraction"]["name"];
                  nwr(around:16000,$lat,$lon)["natural"="cave_entrance"]["name"];
                );
                out tags center 180;
            """.trimIndent()

            PoiCategory.STAY -> """
                [out:json][timeout:5];
                (
                  nwr(around:7000,$lat,$lon)["tourism"~"hotel|motel|guest_house|hostel|camp_site|caravan_site|apartment|chalet"]["name"];
                );
                out tags center 160;
            """.trimIndent()
        }
    }

    private fun parsePlace(
        name: String,
        point: GeoPoint,
        tags: JSONObject,
        category: PoiCategory
    ): PlaceItem? {
        fun tag(key: String): String = tags.optString(key).lowercase(Locale.ROOT)
        val normalizedName = name.lowercase(trLocale)
        val amenity = tag("amenity")
        val tourism = tag("tourism")
        val historic = tag("historic")
        val siteType = tag("site_type")
        val natural = tag("natural")
        val leisure = tag("leisure")
        val cuisine = tag("cuisine")
        val surface = listOf(tag("beach:surface"), tag("surface"), tag("material"))
            .firstOrNull { it.isNotBlank() }.orEmpty()
        val fee = tag("fee")
        val access = tag("access")

        var details: List<String> = emptyList()
        val meta: Triple<String, Int, String?> = when (category) {
            PoiCategory.WAYPOINT -> return null

            PoiCategory.BEACH -> {
                val excludedNames = listOf(
                    "beach club", "beachclub", "beach park", "aqua park", "aquapark",
                    "otel plaj", "özel plaj", "private beach", "resort", "club"
                )
                if (excludedNames.any { it in normalizedName }) return null
                if (fee in setOf("yes", "required") || access in setOf("private", "customers", "no")) return null

                val surfaceLabel = when {
                    listOf("sand", "fine_sand", "sandy").any { it in surface } -> "Kum"
                    listOf("pebble", "pebbles", "gravel", "shingle").any { it in surface } -> "Çakıl"
                    listOf("rock", "rocky", "stone").any { it in surface } -> "Kayalık"
                    else -> "Açık veride belirtilmemiş"
                }
                val accessLabel = when {
                    fee == "no" && access !in setOf("private", "customers", "no") -> "Ücretsiz / halka açık etiketi var"
                    access in setOf("yes", "public", "permissive", "") -> "Özel veya ücretli etiketi yok; sahada doğrula"
                    else -> "Erişim bilgisi açık değil"
                }
                val hobbyLabel = when {
                    surfaceLabel == "Kum" && fee == "no" -> "Yüksek aday: kumlu ve ücretsiz etiketi var"
                    surfaceLabel == "Kum" -> "İyi aday: kumlu; ücret ve yerel izin durumunu kontrol et"
                    surfaceLabel == "Çakıl" || surfaceLabel == "Kayalık" -> "Düşük aday: zemin kum değil"
                    else -> "Belirsiz: zemin bilgisi yok"
                }
                val facilityBits = buildList {
                    if (tag("toilets") == "yes") add("tuvalet")
                    if (tag("shower") == "yes" || tag("showers") == "yes") add("duş")
                    if (tag("parking") == "yes") add("otopark")
                    if (tag("lifeguard") == "yes" || tag("supervised") == "yes") add("cankurtaran")
                }
                details = listOf(
                    "Zemin: $surfaceLabel",
                    "Erişim/ücret: $accessLabel",
                    "Sığlık: Açık harita verisinde doğrulanmamış",
                    "Metal dedektör hobisi: $hobbyLabel",
                    "Tesisler: ${facilityBits.takeIf { it.isNotEmpty() }?.joinToString(", ") ?: "Bilgi yok"}"
                )
                when {
                    natural == "beach" && surfaceLabel == "Kum" && fee == "no" -> Triple("Kumlu halk plajı adayı", 0, "Özel beach club sonuçları elendi. Yerel izin ve yasakları sahada kontrol et.")
                    natural == "beach" && surfaceLabel == "Kum" -> Triple("Kumlu plaj adayı", 1, "Ücret bilgisi kesin değil; gitmeden doğrula.")
                    natural == "beach" -> Triple("Doğal plaj", 2, "Zemin ve sığlık bilgisi eksik olabilir.")
                    natural == "bay" -> Triple("Doğal koy", 3, "Koyun yüzmeye uygun giriş noktası ayrıca kontrol edilmeli.")
                    leisure == "swimming_area" -> Triple("Yüzme alanı", 3, null)
                    else -> return null
                }
            }

            PoiCategory.FOOD -> {
                if (amenity !in setOf("restaurant", "fast_food", "food_court")) return null
                val excluded = listOf(
                    "pastane", "patisserie", "cafe", "café", "kafe", "coffee", "kahve",
                    "tatlı", "tatlici", "tatlıcı", "dondurma", "waffle", "bakery", "fırın",
                    "firin", "unlu mamul", "unlu mamül", "ünlü mamul", "ünlü mamül", "mamulleri", "mamülleri", "mamul", "mamül", "börek",
                    "borek", "simit", "kurabiye", "çikolata", "cikolata", "dessert", "ice cream",
                    "çay bahçesi", "cay bahcesi", "pub", "bar", "pizza", "burger", "sushi",
                    "fine dining", "luxury", "premium", "gourmet", "steak house", "steakhouse"
                )
                val cuisineText = cuisine.replace('_', ' ')
                val combined = "$normalizedName $cuisineText"
                if (excluded.any { it in combined }) return null
                val allowed = listOf(
                    "esnaf", "lokanta", "ev yemek", "sulu yemek", "tabldot", "çorba", "corba",
                    "pide", "lahmacun", "kebap", "kebab", "döner", "doner", "köfte", "kofte",
                    "ocakbaşı", "ocakbasi", "tandır", "tandir", "ızgara", "izgara", "ciğer", "ciger",
                    "mantı", "manti", "gözleme", "gozleme", "ev mutfa", "yemekleri", "yemek salonu", "soup",
                    "turkish", "regional", "barbecue"
                )
                if (allowed.none { it in combined }) return null

                val detail = cuisine
                    .split(';', ',')
                    .filter { it.isNotBlank() }
                    .joinToString(", ") { it.replace('_', ' ').replaceFirstChar(Char::uppercase) }
                    .takeIf { it.isNotBlank() }
                details = listOf(
                    "Seçim nedeni: Pastane/kafe değil; ekonomik yemek türüyle eşleşiyor"
                )
                when {
                    listOf("esnaf", "ev yemek", "sulu yemek", "tabldot", "çorba", "corba").any { it in combined } ->
                        Triple("Ekonomik aday • Esnaf lokantası / ev yemekleri", 0, detail)
                    listOf("pide", "lahmacun").any { it in combined } ->
                        Triple("Ekonomik aday • Pide / lahmacun", 1, detail)
                    listOf("kebap", "kebab", "döner", "doner", "köfte", "kofte", "ocakbaşı", "ocakbasi", "ciğer", "ciger").any { it in combined } ->
                        Triple("Ekonomik aday • Kebap / döner / köfte", 1, detail)
                    listOf("mantı", "manti", "gözleme", "gozleme", "tandır", "tandir", "ızgara", "izgara").any { it in combined } ->
                        Triple("Ekonomik aday • Yerel sıcak yemek", 2, detail)
                    else -> Triple("Yerel Türk mutfağı adayı", 3, detail)
                }
            }

            PoiCategory.MYSTERY -> when {
                siteType == "archaeological_site" || historic == "archaeological_site" -> Triple("Arkeolojik alan", 0, null)
                historic == "ruins" -> Triple("Ören yeri / kalıntı", 1, null)
                historic == "castle" || historic == "fort" -> Triple("Kale / savunma yapısı", 1, null)
                natural == "cave_entrance" -> Triple("Mağara", 1, null)
                historic.isNotBlank() -> Triple("Tarihî nokta", 2, historic.replace('_', ' '))
                tourism == "museum" -> Triple("Müze", 3, null)
                tourism == "attraction" -> Triple("Kültürel / turistik nokta", 4, null)
                else -> return null
            }

            PoiCategory.STAY -> {
                val stars = tag("stars").toIntOrNull() ?: 0
                val luxuryWords = listOf("resort", "spa", "luxury", "deluxe", "palace", "premium", "golf", "şato", "sato")
                if (stars >= 4 || luxuryWords.any { it in normalizedName }) return null
                details = listOf(
                    "Seçim nedeni: Ekonomik konaklama türlerine öncelik verildi"
                )
                when (tourism) {
                    "camp_site" -> Triple("Ekonomik aday • Kamp alanı", 0, "Araç veya çadır uygunluğunu işletmeden kontrol et.")
                    "caravan_site" -> Triple("Ekonomik aday • Karavan alanı", 0, null)
                    "hostel" -> Triple("Ekonomik aday • Hostel", 1, null)
                    "guest_house" -> Triple("Ekonomik aday • Pansiyon / konukevi", 1, null)
                    "apartment" -> Triple("Ekonomik aday • Apart", 2, null)
                    "motel" -> Triple("Ekonomik aday • Motel", 2, null)
                    "chalet" -> Triple("Bungalov / dağ evi", 3, null)
                    "hotel" -> {
                        val economicHotelWords = listOf("aile oteli", "butik otel", "küçük otel", "ucuz otel", "ekonomik otel", "motel")
                        if (economicHotelWords.none { it in normalizedName }) return null
                        Triple("Ekonomik küçük otel adayı", 4, "Fiyatı ve yıldız sınıfını rezervasyondan önce doğrula.")
                    }
                    else -> return null
                }
            }
        }

        return PlaceItem(
            name = name,
            subtitle = meta.first,
            latitude = point.latitude,
            longitude = point.longitude,
            category = category,
            priority = meta.second,
            note = meta.third,
            details = details
        )
    }

    private fun buildSearchCacheKey(center: GeoPoint, category: PoiCategory): String {
        val lat = (center.latitude * 100).roundToInt()
        val lon = (center.longitude * 100).roundToInt()
        return "$category:$lat:$lon"
    }

    private fun enrichPlaceForDisplay(center: GeoPoint, item: PlaceItem): PlaceItem {
        val distance = haversineKm(center, item.asGeoPoint())
        val distanceText = if (distance < 1.0) {
            "Mesafe: ${(distance * 1000).roundToInt()} m"
        } else {
            "Mesafe: ${String.format(trLocale, "%.1f", distance)} km"
        }
        val priceText = when (item.category) {
            PoiCategory.FOOD -> estimateFoodPrice(center, item)
            PoiCategory.STAY -> estimateStayPrice(center, item)
            else -> null
        }
        val newDetails = buildList {
            add(distanceText)
            add("Kaynak: Geoapify / OpenStreetMap canlı sonucu")
            priceText?.let { add(it) }
            addAll(item.details.filterNot {
                it.startsWith("Mesafe:") || it.startsWith("Yaklaşık fiyat") || it.startsWith("Kaynak:")
            })
        }
        return item.copy(details = newDetails)
    }

    private fun estimateFoodPrice(center: GeoPoint, item: PlaceItem): String {
        val base = when {
            "Esnaf" in item.subtitle || "ev yemekleri" in item.subtitle -> 220 to 380
            "Pide" in item.subtitle || "lahmacun" in item.subtitle -> 240 to 420
            "Kebap" in item.subtitle || "döner" in item.subtitle || "köfte" in item.subtitle -> 300 to 550
            else -> 260 to 480
        }
        val multiplier = regionalPriceMultiplier(center.name)
        val min = roundPrice(base.first * multiplier)
        val max = roundPrice(base.second * multiplier)
        return "Yaklaşık fiyat (2026 tahmini): kişi başı ${formatTl(min)}–${formatTl(max)} TL"
    }

    private fun estimateStayPrice(center: GeoPoint, item: PlaceItem): String {
        val base = when {
            "Kamp" in item.subtitle -> 600 to 1_300
            "Karavan" in item.subtitle -> 800 to 1_600
            "Hostel" in item.subtitle -> 1_000 to 1_900
            "Pansiyon" in item.subtitle -> 1_400 to 2_700
            "Apart" in item.subtitle -> 1_700 to 3_200
            "Motel" in item.subtitle -> 1_500 to 2_900
            "Bungalov" in item.subtitle -> 1_900 to 3_600
            else -> 2_000 to 3_900
        }
        val multiplier = regionalPriceMultiplier(center.name)
        val min = roundPrice(base.first * multiplier)
        val max = roundPrice(base.second * multiplier)
        return "Yaklaşık fiyat (2026 tahmini): gecelik ${formatTl(min)}–${formatTl(max)} TL"
    }

    private fun regionalPriceMultiplier(region: String): Double {
        val text = region.lowercase(trLocale)
        return when {
            listOf("bodrum", "çeşme", "alaçatı", "kaş", "kalkan").any { it in text } -> 1.25
            listOf("fethiye", "marmaris", "datça", "antalya", "kuşadası", "ayvalık").any { it in text } -> 1.12
            else -> 1.0
        }
    }

    private fun roundPrice(value: Double): Int = ((value / 50.0).roundToInt() * 50).coerceAtLeast(50)

    private fun formatTl(value: Int): String = String.format(Locale("tr", "TR"), "%,d", value)
        .replace(',', '.')

    private fun fallbackMysteryPlaces(center: GeoPoint): List<PlaceItem> {
        val key = nearestKnownRegion(center.latitude, center.longitude)
        val places = when (key) {
            "İzmir" -> listOf(
                Triple("İzmir Agora Ören Yeri", 38.4193, 27.1388),
                Triple("Kadifekale", 38.4148, 27.1468),
                Triple("İzmir Arkeoloji Müzesi", 38.4117, 27.1281),
                Triple("Tarihî Asansör", 38.4067, 27.1172)
            )
            "Bodrum" -> listOf(
                Triple("Bodrum Kalesi", 37.0318, 27.4293),
                Triple("Halikarnas Mozolesi", 37.0380, 27.4241),
                Triple("Myndos Kapısı", 37.0388, 27.4104),
                Triple("Pedasa Antik Kenti", 37.0845, 27.4146)
            )
            "Fethiye" -> listOf(
                Triple("Amyntas Kaya Mezarları", 36.6202, 29.1156),
                Triple("Telmessos Antik Tiyatrosu", 36.6228, 29.1110),
                Triple("Kayaköy", 36.5768, 29.0907)
            )
            "Antalya" -> listOf(
                Triple("Hadrian Kapısı", 36.8852, 30.7083),
                Triple("Antalya Müzesi", 36.8847, 30.6804),
                Triple("Perge Antik Kenti", 36.9587, 30.8524),
                Triple("Kaleiçi", 36.8841, 30.7041)
            )
            "Mersin" -> listOf(
                Triple("Soli Pompeiopolis Antik Kenti", 36.7434, 34.5400),
                Triple("Mersin Arkeoloji Müzesi", 36.7807, 34.6030),
                Triple("Kızkalesi", 36.4600, 34.1485)
            )
            "Tarsus" -> listOf(
                Triple("Tarsus Şelalesi ve Roma Mezarları", 36.9304, 34.8996),
                Triple("Kleopatra Kapısı", 36.9164, 34.8959),
                Triple("St. Paul Kuyusu", 36.9190, 34.8976)
            )
            "Efes" -> listOf(
                Triple("Efes Antik Kenti", 37.9390, 27.3410),
                Triple("Artemis Tapınağı", 37.9497, 27.3639),
                Triple("Yedi Uyurlar Mağarası", 37.9490, 27.3572)
            )
            "Didim" -> listOf(
                Triple("Didyma Apollon Tapınağı", 37.3849, 27.2568),
                Triple("Milet Antik Kenti", 37.5307, 27.2760),
                Triple("Priene Antik Kenti", 37.6590, 27.2970)
            )
            else -> emptyList()
        }
        return places.mapIndexedNotNull { index, (name, lat, lon) ->
            val distance = haversineKm(center, GeoPoint(name, lat, lon))
            if (distance > 60.0) null else PlaceItem(
                name = name,
                subtitle = "Hızlı yedek • Tarihî / arkeolojik nokta",
                latitude = lat,
                longitude = lon,
                category = PoiCategory.MYSTERY,
                priority = 6 + index,
                note = "Canlı harita servisi yavaşladığında uygulamanın yerleşik listesinden gösterilir."
            )
        }
    }

    private fun fetchNearbyTowns(points: List<GeoPoint>): List<GeoPoint> {
        val body = buildString {
            append("[out:json][timeout:35];(")
            points.forEach { point ->
                append("node(around:80000,${point.latitude},${point.longitude})")
                append("[\"place\"~\"city|town\"][\"name\"];")
            }
            append(");out body 350;")
        }
        return runCatching {
            val json = postOverpass(body)
            val elements = json.optJSONArray("elements") ?: JSONArray()
            buildList {
                val seen = mutableSetOf<String>()
                for (index in 0 until elements.length()) {
                    val element = elements.getJSONObject(index)
                    val tags = element.optJSONObject("tags") ?: continue
                    val name = cleanRegionName(readName(tags))
                    if (name.isBlank() || !seen.add(name.lowercase(trLocale))) continue
                    add(GeoPoint(name, element.optDouble("lat"), element.optDouble("lon")))
                }
            }
        }.getOrDefault(emptyList())
    }

    private fun sampleRoute(points: List<GeoPoint>, count: Int): List<GeoPoint> {
        if (count <= 2) return listOf(points.first(), points.last())
        val cumulative = DoubleArray(points.size)
        for (index in 1 until points.size) {
            cumulative[index] = cumulative[index - 1] + haversineKm(points[index - 1], points[index])
        }
        val total = cumulative.last()
        if (total <= 0.0) return List(count) { if (it == count - 1) points.last() else points.first() }

        return (0 until count).map { sampleIndex ->
            val target = total * sampleIndex / (count - 1).toDouble()
            val upper = cumulative.indexOfFirst { it >= target }
            when {
                upper <= 0 -> points.first()
                upper == -1 -> points.last()
                else -> {
                    val lower = upper - 1
                    val segment = cumulative[upper] - cumulative[lower]
                    val ratio = if (segment == 0.0) 0.0 else (target - cumulative[lower]) / segment
                    val a = points[lower]
                    val b = points[upper]
                    GeoPoint(
                        "",
                        a.latitude + (b.latitude - a.latitude) * ratio,
                        a.longitude + (b.longitude - a.longitude) * ratio
                    )
                }
            }
        }
    }

    private fun <T> sampleList(items: List<T>, count: Int): List<T> {
        if (count >= items.size) return items
        if (count <= 1) return listOf(items.first())
        return (0 until count).map { index ->
            val raw = index * (items.lastIndex.toDouble() / (count - 1).toDouble())
            items[raw.roundToInt().coerceIn(0, items.lastIndex)]
        }.distinct().let { sampled ->
            if (sampled.size == count) sampled else items.take(count)
        }
    }

    private fun readName(tags: JSONObject): String =
        tags.optString("name:tr").ifBlank { tags.optString("name") }.trim()

    private fun elementPoint(element: JSONObject): GeoPoint? {
        val center = element.optJSONObject("center")
        val lat = when {
            element.has("lat") -> element.optDouble("lat", Double.NaN)
            center != null -> center.optDouble("lat", Double.NaN)
            else -> Double.NaN
        }
        val lon = when {
            element.has("lon") -> element.optDouble("lon", Double.NaN)
            center != null -> center.optDouble("lon", Double.NaN)
            else -> Double.NaN
        }
        return if (lat.isNaN() || lon.isNaN()) null else GeoPoint("", lat, lon)
    }

    private fun getJson(url: String): JSONObject = JSONObject(getText(url))

    private fun getJsonArray(url: String): JSONArray = JSONArray(getText(url))

    private fun getText(url: String): String {
        val connection = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 2_000
            readTimeout = 3_500
            setRequestProperty("User-Agent", USER_AGENT)
            setRequestProperty("Accept", "application/json")
        }
        return connection.useTextResponse()
    }

    private suspend fun postOverpassFast(query: String): JSONObject = withTimeout(5_200) {
        coroutineScope {
            val endpoints = listOf(
                "https://overpass.private.coffee/api/interpreter",
                "https://overpass-api.de/api/interpreter",
                "https://maps.mail.ru/osm/tools/overpass/api/interpreter"
            )
            val responses = Channel<Result<JSONObject>>(endpoints.size)
            endpoints.forEach { endpoint ->
                launch(Dispatchers.IO) {
                    responses.send(runCatching { executeOverpass(endpoint, query, 2_200, 4_500) })
                }
            }
            var lastError: Throwable? = null
            repeat(endpoints.size) {
                val result = responses.receive()
                if (result.isSuccess) return@coroutineScope result.getOrThrow()
                lastError = result.exceptionOrNull()
            }
            throw lastError ?: IllegalStateException("Açık harita servisine ulaşılamadı.")
        }
    }

    private fun executeOverpass(
        endpoint: String,
        query: String,
        connectTimeoutMs: Int,
        readTimeoutMs: Int
    ): JSONObject {
        val body = "data=" + encode(query)
        val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            doOutput = true
            connectTimeout = connectTimeoutMs
            readTimeout = readTimeoutMs
            setRequestProperty("User-Agent", USER_AGENT)
            setRequestProperty("Accept", "application/json")
            setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
        }
        connection.outputStream.use { output ->
            output.write(body.toByteArray(StandardCharsets.UTF_8))
        }
        return JSONObject(connection.useTextResponse())
    }

    private fun postOverpass(query: String): JSONObject {
        val endpoints = listOf(
            "https://overpass.private.coffee/api/interpreter",
            "https://overpass-api.de/api/interpreter",
            "https://maps.mail.ru/osm/tools/overpass/api/interpreter"
        )
        var lastError: Throwable? = null
        endpoints.forEach { endpoint ->
            try {
                return executeOverpass(endpoint, query, 6_000, 11_000)
            } catch (throwable: Throwable) {
                lastError = throwable
            }
        }
        throw lastError ?: IllegalStateException("Açık harita servisine ulaşılamadı.")
    }

    private fun HttpURLConnection.useTextResponse(): String = try {
        val code = responseCode
        val stream = if (code in 200..299) inputStream else errorStream
        val text = stream?.use { input ->
            BufferedReader(InputStreamReader(input, StandardCharsets.UTF_8)).readText()
        }.orEmpty()
        if (code !in 200..299) throw IllegalStateException("Servis yanıt vermedi (HTTP $code).")
        text
    } finally {
        disconnect()
    }

    private fun encode(value: String): String =
        URLEncoder.encode(value, StandardCharsets.UTF_8.toString())
}

internal fun Throwable.userMessage(): String {
    val raw = message.orEmpty()
    return when {
        raw.contains("Unable to resolve host", ignoreCase = true) ->
            "İnternet bağlantısı kurulamadı. Bağlantını kontrol edip tekrar dene."
        raw.contains("timed out", ignoreCase = true) || raw.contains("timeout", ignoreCase = true) ->
            "Yer adı birkaç saniyede bulunamadı. İlçe veya şehir adını daha sade yaz."
        raw.contains("HTTP 429", ignoreCase = true) ->
            "Harita servisi geçici olarak yoğun. Biraz sonra tekrar dene."
        raw.isNotBlank() -> raw
        else -> "İşlem tamamlanamadı. Tekrar dene."
    }
}

internal fun JSONObject.optNullableDouble(key: String): Double? {
    if (!has(key) || isNull(key)) return null
    val value = optDouble(key, Double.NaN)
    return value.takeUnless { it.isNaN() }
}

internal fun Double?.format(suffix: String): String =
    this?.let { String.format(Locale("tr", "TR"), "%.1f%s", it, suffix) } ?: "Veri yok"

internal fun waveLabel(height: Double?): String = when {
    height == null -> "veri yok"
    height <= 0.30 -> "çok sakin"
    height <= 0.70 -> "hafif dalgalı"
    height <= 1.20 -> "dalgalı"
    else -> "yüksek dalga"
}

internal fun weatherCodeText(code: Int): String = when (code) {
    0 -> "Açık"
    1 -> "Çoğunlukla açık"
    2 -> "Parçalı bulutlu"
    3 -> "Kapalı"
    45, 48 -> "Sisli"
    in 51..57 -> "Çisenti"
    in 61..67 -> "Yağmurlu"
    in 71..77 -> "Karlı"
    in 80..82 -> "Sağanak"
    85, 86 -> "Kar sağanağı"
    95 -> "Gök gürültülü fırtına"
    96, 99 -> "Dolu ihtimalli fırtına"
    else -> "Güncel hava"
}

internal fun haversineKm(a: GeoPoint, b: GeoPoint): Double {
    val earthRadiusKm = 6371.0
    val dLat = Math.toRadians(b.latitude - a.latitude)
    val dLon = Math.toRadians(b.longitude - a.longitude)
    val lat1 = Math.toRadians(a.latitude)
    val lat2 = Math.toRadians(b.latitude)
    val value = sin(dLat / 2) * sin(dLat / 2) +
        cos(lat1) * cos(lat2) * sin(dLon / 2) * sin(dLon / 2)
    return 2 * earthRadiusKm * asin(sqrt(value))
}

private fun PlaceItem.asGeoPoint(): GeoPoint = GeoPoint(name, latitude, longitude)
