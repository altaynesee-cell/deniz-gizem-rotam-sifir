package com.altayaytin.denizgizemrotamsifir

import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * V16 yerleşik katalog.
 *
 * Ana kural: Kullanıcının seçtiği bölgenin dışından sonuç gösterilmez. Bir bölgede
 * doğrulanmış kayıt yoksa uzaktaki başka bir şehirden öneri doldurmak yerine boş
 * sonuç döner. Yemek ve konaklamada yalnız ekonomik aramalar açılır.
 */
internal object LocalCatalog {
    private val tr = Locale("tr", "TR")

    private data class CatalogPlace(
        val name: String,
        val subtitle: String,
        val lat: Double,
        val lon: Double,
        val category: PoiCategory,
        val priority: Int,
        val regionKey: String? = null,
        val note: String? = null,
        val details: List<String> = emptyList(),
        val mapSearchQuery: String? = null,
        val isSearchCard: Boolean = false
    )

    private val places = listOf(
        // İZNİK — göl plajları. Erdek ve Marmara kıyıları bu gruba asla karışmaz.
        CatalogPlace(
            "İznik İnciraltı Halk Plajı", "İznik Gölü halk plajı", 40.4286, 29.7010,
            PoiCategory.BEACH, 0, "iznik",
            note = "İznik bölgesine ait doğrulanmış halk plajı.",
            details = listOf(
                "Zemin: Kum ve çakıl",
                "Erişim: Halk plajı",
                "Ücret: Giriş ücretini gitmeden güncel kaynaktan doğrula",
                "Sığlık: Bölüme ve göl seviyesine göre değişebilir",
                "Metal dedektör hobisi: Kumlu kesimler aday; yerel izinleri kontrol et"
            ),
            mapSearchQuery = "İznik İnciraltı Halk Plajı"
        ),
        CatalogPlace(
            "Göllüce Halk Plajı", "İznik Gölü halk plajı", 40.3970, 29.5750,
            PoiCategory.BEACH, 1, "iznik",
            note = "İznik ilçesi sınırındaki göl kıyısı seçeneği.",
            details = listOf(
                "Zemin: Kum ve çakıl karışımı",
                "Erişim: Halk plajı",
                "Ücret: Gitmeden güncel durumu doğrula",
                "Sığlık: Açık kaynaklarda kesin ölçüm yok",
                "Metal dedektör hobisi: Kumlu bölümler aday; yerel izinleri kontrol et"
            ),
            mapSearchQuery = "Göllüce Halk Plajı İznik"
        ),

        // KIYIKIŞLACIK / İASOS — bölge merkezine kilitli doğrulanmış yakın kayıtlar.
        CatalogPlace(
            "Zeytinlikuyu Plajı", "Kıyıkışlacık halk plajı", 37.25622, 27.52398,
            PoiCategory.BEACH, 0, "kiyikislacik",
            note = "Kıyıkışlacık sınırındaki yakın plaj; Didim ve uzak koylar bu sonuç grubuna karıştırılmaz.",
            details = listOf(
                "Zemin: Kum ağırlıklı olarak işaretlenmiş; sahada doğrula",
                "Erişim: Halk plajı kaydı",
                "Sığlık: Açık kaynaklarda tutarlı ölçüm yok; ani derinleşmeye karşı kıyıda kontrol et",
                "Metal dedektör hobisi: Kumlu alan adayı; yerel izinleri ve kullanım yoğunluğunu kontrol et"
            ),
            mapSearchQuery = "Zeytinlikuyu Plajı Kıyıkışlacık"
        ),

        // MARMARA / EGE / AKDENİZ — özel beach club kayıtları bilerek yoktur.
        CatalogPlace("Ocaklar Halk Plajı", "Erdek halk plajı", 40.3656, 27.8783, PoiCategory.BEACH, 1, "erdek",
            details = listOf("Zemin: Genellikle kum", "Erişim: Halk plajı", "Sığlık: Yerinde kontrol et", "Metal dedektör hobisi: Kumlu bölümler uygun aday")),
        CatalogPlace("Çuğra Plajı", "Erdek halk plajı", 40.3896, 27.7818, PoiCategory.BEACH, 2, "erdek",
            details = listOf("Zemin: Kum ve yer yer çakıl", "Erişim: Halka açık bölümler", "Sığlık: Yerinde kontrol et")),
        CatalogPlace("Sarımsaklı Plajı", "Ayvalık halk plajı", 39.2739, 26.6587, PoiCategory.BEACH, 1, "ayvalik",
            details = listOf("Zemin: Kum", "Erişim: Ücretsiz halk bölümleri bulunur", "Sığlık: Genellikle yavaş derinleşen kesimler", "Metal dedektör hobisi: İyi aday; yerel kuralları kontrol et")),
        CatalogPlace("Badavut Plajı", "Ayvalık doğal plajı", 39.2425, 26.6298, PoiCategory.BEACH, 2, "ayvalik",
            details = listOf("Zemin: Kum ağırlıklı", "Erişim: Doğal plaj", "Sığlık ve dalga: Rüzgâra göre değişir")),
        CatalogPlace("Ilıca Halk Plajı", "Çeşme halk plajı", 38.3069, 26.3667, PoiCategory.BEACH, 1, "cesme",
            details = listOf("Zemin: Kum", "Erişim: Halk plajı", "Sığlık: Geniş sığ alanlarıyla bilinir", "Metal dedektör hobisi: İyi aday; yoğunluk ve yerel kuralları kontrol et")),
        CatalogPlace("Altınkum Halk Plajı", "Çeşme halk plajı", 38.2597, 26.2764, PoiCategory.BEACH, 2, "cesme",
            details = listOf("Zemin: Kum", "Erişim: Halk bölümleri", "Dalga: Rüzgâra göre değişebilir")),
        CatalogPlace("Kadınlar Plajı", "Kuşadası halk plajı", 37.8420, 27.2496, PoiCategory.BEACH, 2, "kusadasi",
            details = listOf("Zemin: Kum", "Erişim: Halk plajı", "Sığlık: Bölüme göre değişir")),
        CatalogPlace("Sevgi Plajı", "Kuşadası halk plajı", 37.7342, 27.2204, PoiCategory.BEACH, 1, "kusadasi",
            details = listOf("Zemin: Kum", "Erişim: Halk plajı", "Metal dedektör hobisi: Kumlu ve geniş alan; yerel kuralları kontrol et")),
        CatalogPlace("Altınkum Plajı Didim", "Didim halk plajı", 37.3567, 27.2779, PoiCategory.BEACH, 2, "didim",
            details = listOf("Zemin: Kum", "Erişim: Halk plajı", "Sığlık: Bölüme ve mevsime göre değişir")),
        CatalogPlace("Akbük Sahili", "Didim halk sahili", 37.3918, 27.4308, PoiCategory.BEACH, 1, "didim",
            details = listOf("Zemin: Kum ve çakıl karışık bölümler", "Erişim: Halka açık sahil", "Dalga: Koy yapısı nedeniyle çoğu gün daha sakindir")),
        CatalogPlace("Bitez Plajı", "Bodrum halk plajı", 37.0258, 27.3857, PoiCategory.BEACH, 2, "bodrum",
            details = listOf("Zemin: Kum ve yer yer çakıl", "Erişim: Halk bölümleri", "Sığlık: Bazı kesimlerde yavaş derinleşir")),
        CatalogPlace("Ortakent Yahşi Halk Plajı", "Bodrum halk plajı", 37.0126, 27.3491, PoiCategory.BEACH, 2, "bodrum",
            details = listOf("Zemin: Kum ve çakıl", "Erişim: Halk bölümleri", "Dalga: Rüzgâra göre değişir")),
        CatalogPlace("Karaincir Halk Plajı", "Bodrum koy içi halk plajı", 36.9726, 27.2964, PoiCategory.BEACH, 1, "bodrum",
            details = listOf("Zemin: Kum", "Erişim: Halka açık bölüm", "Sığlık: Genellikle yavaş derinleşen kesimler")),
        CatalogPlace("Kumluk Plajı", "Datça merkez halk plajı", 36.7250, 27.6873, PoiCategory.BEACH, 2, "datca",
            details = listOf("Zemin: Kum/ince çakıl", "Erişim: Merkezde halka açık", "Sığlık: Yerinde kontrol et")),
        CatalogPlace("Palamutbükü Sahili", "Datça doğal sahili", 36.6721, 27.5054, PoiCategory.BEACH, 2, "datca",
            details = listOf("Zemin: Çakıl ve kum karışık", "Erişim: Halka açık sahil", "Sığlık: Kısa mesafede derinleşen bölümler olabilir")),
        CatalogPlace("İçmeler Halk Plajı", "Marmaris halk plajı", 36.8010, 28.2318, PoiCategory.BEACH, 2, "marmaris",
            details = listOf("Zemin: Kum/ince çakıl", "Erişim: Halka açık bölümler", "Sığlık: Bölüme göre değişir")),
        CatalogPlace("Turunç Halk Plajı", "Marmaris koy içi halk plajı", 36.7730, 28.2488, PoiCategory.BEACH, 2, "marmaris",
            details = listOf("Zemin: Kum ve çakıl", "Erişim: Halka açık", "Dalga: Koy içinde çoğu gün daha sakindir")),
        CatalogPlace("Çalış Plajı", "Fethiye halk sahili", 36.6592, 29.1053, PoiCategory.BEACH, 2, "fethiye",
            details = listOf("Zemin: Çakıl/kum karışık", "Erişim: Halk sahili", "Dalga: Rüzgâra açık günlerde artabilir")),
        CatalogPlace("Ölüdeniz Belcekız Plajı", "Fethiye halk plajı", 36.5488, 29.1231, PoiCategory.BEACH, 2, "fethiye",
            details = listOf("Zemin: Kum ve çakıl", "Erişim: Halk bölümü", "Yoğunluk: Yazın yüksek olabilir")),
        CatalogPlace("Büyük Çakıl Plajı", "Kaş doğal halk plajı", 36.1947, 29.6574, PoiCategory.BEACH, 2, "kas",
            details = listOf("Zemin: Çakıl", "Erişim: Halka açık", "Metal dedektör hobisi: Kumlu plajlara göre düşük aday")),
        CatalogPlace("Kaputaş Plajı", "Kaş doğal plajı", 36.2289, 29.4508, PoiCategory.BEACH, 2, "kas",
            details = listOf("Zemin: Kum ve küçük çakıl", "Erişim: Halka açık", "Sığlık: Dalga ve kıyı eğimi değişebilir")),
        CatalogPlace("Konyaaltı Halk Plajı", "Antalya halk plajı", 36.8647, 30.6377, PoiCategory.BEACH, 2, "antalya",
            details = listOf("Zemin: Çakıl", "Erişim: Halka açık", "Metal dedektör hobisi: Kumlu plajlara göre düşük aday")),
        CatalogPlace("Lara Halk Plajı", "Antalya halk plajı", 36.8485, 30.8013, PoiCategory.BEACH, 1, "antalya",
            details = listOf("Zemin: Kum", "Erişim: Halk bölümleri", "Metal dedektör hobisi: İyi aday; yerel kuralları kontrol et")),
        CatalogPlace("Kızkalesi Halk Plajı", "Mersin halk plajı", 36.4596, 34.1455, PoiCategory.BEACH, 1, "mersin",
            details = listOf("Zemin: Kum", "Erişim: Halk plajı", "Sığlık: Kıyı bölümüne göre değişir")),
        CatalogPlace("Yapraklı Koy", "Mersin doğal koyu", 36.4837, 34.1733, PoiCategory.BEACH, 2, "mersin",
            details = listOf("Zemin: Kaya/kum karışık", "Erişim: Doğal koy", "Sığlık: Giriş noktasına göre değişir")),

        // TARİH / GİZEM — yalnız seçilen merkezin yakınındaki kayıtlar gösterilir.
        CatalogPlace(
            "İasos Antik Kenti", "Antik liman kenti ve arkeolojik alan",
            37.27944, 27.58417, PoiCategory.MYSTERY, 0, "kiyikislacik",
            note = "Kıyıkışlacık yarımadasındaki yerel keşif noktası.",
            details = listOf("Bölge: Kıyıkışlacık / Milas", "Tür: Antik kent ve ören yeri"),
            mapSearchQuery = "İasos Antik Kenti Kıyıkışlacık"
        ),
        CatalogPlace("Bursa Ulu Cami", "Tarihî yapı", 40.1839, 29.0619, PoiCategory.MYSTERY, 3, "bursa"),
        CatalogPlace("Muradiye Külliyesi", "Tarihî külliye", 40.1907, 29.0434, PoiCategory.MYSTERY, 2, "bursa"),
        CatalogPlace("Gölyazı ve Apollonia ad Rhyndacum", "Tarihî yerleşim", 40.1712, 28.6828, PoiCategory.MYSTERY, 1, "golyazi"),
        CatalogPlace("İznik Ayasofya Orhan Camii", "Tarihî yapı", 40.4292, 29.7200, PoiCategory.MYSTERY, 1, "iznik"),
        CatalogPlace("İznik Surları", "Tarihî savunma yapısı", 40.4288, 29.7208, PoiCategory.MYSTERY, 1, "iznik"),
        CatalogPlace("İznik Müzesi", "Arkeoloji ve tarih müzesi", 40.4258, 29.7270, PoiCategory.MYSTERY, 1, "iznik",
            mapSearchQuery = "İznik Müzesi"),
        CatalogPlace("Lefke Kapı", "Roma ve Bizans dönemi şehir kapısı", 40.4297, 29.7390, PoiCategory.MYSTERY, 1, "iznik",
            mapSearchQuery = "Lefke Kapı İznik"),
        CatalogPlace("İstanbul Kapı", "Tarihî şehir kapısı", 40.4380, 29.7200, PoiCategory.MYSTERY, 1, "iznik",
            mapSearchQuery = "İstanbul Kapı İznik"),
        CatalogPlace("İznik Roma Tiyatrosu", "Arkeolojik alan", 40.4325, 29.7110, PoiCategory.MYSTERY, 1, "iznik",
            mapSearchQuery = "İznik Roma Tiyatrosu"),
        CatalogPlace("İznik Gölü Batık Bazilikası", "Sualtı arkeolojik alanı", 40.4290, 29.6970, PoiCategory.MYSTERY, 1, "iznik",
            note = "Kıyıdan görülebilen/sualtı arkeolojisi niteliğindeki alan; erişim durumunu güncel olarak kontrol et.",
            mapSearchQuery = "İznik Batık Bazilika"),
        CatalogPlace(
            "Şeytan Sofrası", "Efsaneli seyir noktası ve doğal oluşum",
            39.2639, 26.6406, PoiCategory.MYSTERY, 0, "ayvalik",
            note = "Ayvalık merkezinin güneyindeki tepede, halk arasında Şeytan'ın ayak izi olduğuna inanılan oluşum ve buna bağlı dilek/rivayet anlatıları bulunur.",
            details = listOf(
                "Bölge: Ayvalık / Balıkesir",
                "Tür: Yerel efsane ve doğal seyir noktası",
                "Anlatı durumu: Rivayet; tarihî gerçek olarak sunulmaz",
                "Ülke kilidi: Yalnız Türkiye sonuçları gösterilir"
            ),
            mapSearchQuery = "Şeytan Sofrası Ayvalık"
        ),
        CatalogPlace("Kyzikos Antik Kenti", "Arkeolojik alan", 40.3565, 27.8872, PoiCategory.MYSTERY, 1, "erdek"),
        CatalogPlace("Adatepe Zeus Altarı", "Mitolojik/tarihî nokta", 39.5468, 26.6277, PoiCategory.MYSTERY, 2, "ayvalik"),
        CatalogPlace("Assos Antik Kenti", "Arkeolojik alan", 39.4897, 26.3367, PoiCategory.MYSTERY, 1, "assos"),
        CatalogPlace("Bergama Akropolü", "Arkeolojik alan", 39.1326, 27.1841, PoiCategory.MYSTERY, 1, "bergama"),
        CatalogPlace("İzmir Agora Ören Yeri", "Arkeolojik alan", 38.4193, 27.1388, PoiCategory.MYSTERY, 1, "izmir"),
        CatalogPlace("Kadifekale", "Tarihî kale", 38.4148, 27.1468, PoiCategory.MYSTERY, 2, "izmir"),
        CatalogPlace("Efes Antik Kenti", "Arkeolojik alan", 37.9390, 27.3410, PoiCategory.MYSTERY, 1, "efes"),
        CatalogPlace("Artemis Tapınağı", "Antik kutsal alan", 37.9497, 27.3639, PoiCategory.MYSTERY, 1, "efes"),
        CatalogPlace("Didyma Apollon Tapınağı", "Antik kutsal alan", 37.3849, 27.2568, PoiCategory.MYSTERY, 1, "didim"),
        CatalogPlace("Milet Antik Kenti", "Arkeolojik alan", 37.5307, 27.2760, PoiCategory.MYSTERY, 1, "didim"),
        CatalogPlace("Bodrum Kalesi", "Tarihî kale", 37.0318, 27.4293, PoiCategory.MYSTERY, 1, "bodrum"),
        CatalogPlace("Halikarnas Mozolesi", "Antik anıt", 37.0380, 27.4241, PoiCategory.MYSTERY, 1, "bodrum"),
        CatalogPlace("Knidos Antik Kenti", "Arkeolojik alan", 36.6851, 27.3746, PoiCategory.MYSTERY, 1, "datca"),
        CatalogPlace("Kaunos Antik Kenti", "Arkeolojik alan", 36.8260, 28.6258, PoiCategory.MYSTERY, 1, "dalyan"),
        CatalogPlace("Kayaköy", "Terk edilmiş tarihî yerleşim", 36.5768, 29.0907, PoiCategory.MYSTERY, 1, "fethiye"),
        CatalogPlace("Amyntas Kaya Mezarları", "Antik kaya mezarları", 36.6202, 29.1156, PoiCategory.MYSTERY, 1, "fethiye"),
        CatalogPlace("Patara Antik Kenti", "Arkeolojik alan", 36.2623, 29.3150, PoiCategory.MYSTERY, 1, "kalkan"),
        CatalogPlace("Antiphellos Antik Tiyatrosu", "Antik tiyatro", 36.1997, 29.6345, PoiCategory.MYSTERY, 2, "kas"),
        CatalogPlace("Perge Antik Kenti", "Arkeolojik alan", 36.9587, 30.8524, PoiCategory.MYSTERY, 1, "antalya"),
        CatalogPlace("Termessos Antik Kenti", "Dağlık arkeolojik alan", 36.9830, 30.4655, PoiCategory.MYSTERY, 1, "antalya"),
        CatalogPlace("Soli Pompeiopolis Antik Kenti", "Arkeolojik alan", 36.7434, 34.5400, PoiCategory.MYSTERY, 1, "mersin"),
        CatalogPlace("Kızkalesi", "Tarihî deniz kalesi", 36.4576, 34.1480, PoiCategory.MYSTERY, 1, "mersin"),
        CatalogPlace("Kleopatra Kapısı", "Tarihî kapı", 36.9164, 34.8959, PoiCategory.MYSTERY, 1, "tarsus"),
        CatalogPlace("St. Paul Kuyusu", "Tarihî/inanç noktası", 36.9190, 34.8976, PoiCategory.MYSTERY, 2, "tarsus"),

        // İZNİK — ekonomik yemek işletmeleri. Kafe/pastane/unlu mamul yoktur.
        CatalogPlace("Hanımeli Ev Yemekleri", "Ev yemekleri • ekonomik aday", 40.4297, 29.7210, PoiCategory.FOOD, 0, "iznik",
            details = listOf("Tür: Ev yemekleri", "Fiyat: 2026 tahmini kişi başı 250–450 TL", "Güncel menü ve fiyatı haritada doğrula"),
            mapSearchQuery = "Hanımeli Ev Yemekleri İznik"),
        CatalogPlace("Kenan Çorba ve Izgara Salonu", "Esnaf lokantası • çorba ve ızgara", 40.4297, 29.7210, PoiCategory.FOOD, 0, "iznik",
            details = listOf("Tür: Esnaf lokantası", "Fiyat: 2026 tahmini kişi başı 250–500 TL", "Güncel menü ve fiyatı haritada doğrula"),
            mapSearchQuery = "Kenan Çorba ve Izgara Salonu İznik"),
        CatalogPlace("Baco Pide & Kebap Salonu", "Pide ve kebap • ekonomik aday", 40.4297, 29.7210, PoiCategory.FOOD, 1, "iznik",
            details = listOf("Tür: Pide ve kebap", "Fiyat: 2026 tahmini kişi başı 300–550 TL", "Güncel menü ve fiyatı haritada doğrula"),
            mapSearchQuery = "Baco Pide Kebap Salonu İznik"),
        CatalogPlace("Kaptan Çorba Islama Köfte", "Esnaf lokantası • köfte ve çorba", 40.4297, 29.7210, PoiCategory.FOOD, 1, "iznik",
            details = listOf("Tür: Köfte ve çorba", "Fiyat: 2026 tahmini kişi başı 300–550 TL", "Güncel menü ve fiyatı haritada doğrula"),
            mapSearchQuery = "Kaptan Çorba Islama Köfte İznik"),
        CatalogPlace("Merkez Lokantası", "Aile/esnaf lokantası • ekonomik aday", 40.4297, 29.7210, PoiCategory.FOOD, 2, "iznik",
            details = listOf("Tür: Lokanta", "Fiyat: 2026 tahmini kişi başı 250–500 TL", "Güncel menü ve fiyatı haritada doğrula"),
            mapSearchQuery = "Merkez Lokantası İznik"),

        // KIYIKIŞLACIK — ekonomik yemek adayları. Konum ve güncel fiyat haritada doğrulanır.
        CatalogPlace("Dayı'nın Yeri", "Aile/esnaf lokantası • çorba ve köfte",
            37.280799, 27.581603, PoiCategory.FOOD, 0, "kiyikislacik",
            details = listOf("Tür: Ev tipi Türk yemekleri, çorba ve ızgara köfte", "Fiyat: 2026 tahmini kişi başı 300–600 TL", "Güncel menü ve fiyatı haritada doğrula"),
            mapSearchQuery = "Dayı'nın Yeri Kıyıkışlacık"),
        CatalogPlace("Pidecim Kıyıkışlacık", "Pide salonu • ekonomik aday",
            37.280799, 27.581603, PoiCategory.FOOD, 1, "kiyikislacik",
            details = listOf("Tür: Pide", "Fiyat: 2026 tahmini kişi başı 300–650 TL", "Güncel yorum, menü ve fiyatı haritada doğrula"),
            mapSearchQuery = "Pidecim Kıyıkışlacık Milas"),

        // KIYIKIŞLACIK — pansiyon ve hostel türleri; lüks/resort listesi değildir.
        CatalogPlace("Ersan Pansiyon", "Pansiyon • aile konaklaması adayı",
            37.280799, 27.581603, PoiCategory.STAY, 0, "kiyikislacik",
            details = listOf("Tür: Pansiyon", "Fiyat: 2026 tahmini gecelik 2.000–4.500 TL", "Tarih ve kişi sayısına göre güncel fiyatı doğrula"),
            mapSearchQuery = "Ersan Pansiyon Kıyıkışlacık"),
        CatalogPlace("Hostel Memedim Zeynep's", "Hostel/pansiyon • ekonomik aday",
            37.280799, 27.581603, PoiCategory.STAY, 1, "kiyikislacik",
            details = listOf("Tür: Hostel / pansiyon", "Fiyat: 2026 tahmini gecelik 1.800–4.000 TL", "Müsaitlik ve güncel fiyatı doğrula"),
            mapSearchQuery = "Hostel Memedim Zeynep's Kıyıkışlacık"),
        CatalogPlace("İasos Saklıkent Pansiyon", "Pansiyon • aile işletmesi adayı",
            37.280799, 27.581603, PoiCategory.STAY, 1, "kiyikislacik",
            details = listOf("Tür: Pansiyon", "Fiyat: 2026 tahmini gecelik 2.000–4.500 TL", "Müsaitlik ve güncel fiyatı doğrula"),
            mapSearchQuery = "İasos Saklıkent Pansiyon Kıyıkışlacık"),

        // İZNİK — pansiyon/apart/aile oteli. Resort, spa ve lüks tesis yoktur.
        CatalogPlace("İznik Karpi Apart Pansiyon", "Apart pansiyon • ekonomik aday", 40.4297, 29.7210, PoiCategory.STAY, 0, "iznik",
            details = listOf("Tür: Apart pansiyon", "Fiyat: 2026 tahmini gecelik 1.500–3.000 TL", "Tarih ve kişi sayısına göre güncel fiyatı doğrula"),
            mapSearchQuery = "İznik Karpi Apart Pansiyon"),
        CatalogPlace("Aşiyan Pansiyon", "Pansiyon • aile konaklaması", 40.4297, 29.7210, PoiCategory.STAY, 0, "iznik",
            details = listOf("Tür: Pansiyon", "Fiyat: 2026 tahmini gecelik 1.600–3.200 TL", "Tarih ve kişi sayısına göre güncel fiyatı doğrula"),
            mapSearchQuery = "Aşiyan Pansiyon İznik"),
        CatalogPlace("Ekinoks Hotel", "Apart otel konsepti • ekonomik aday", 40.4297, 29.7210, PoiCategory.STAY, 1, "iznik",
            details = listOf("Tür: Apart otel", "Fiyat: 2026 tahmini gecelik 1.800–3.500 TL", "Tarih ve kişi sayısına göre güncel fiyatı doğrula"),
            mapSearchQuery = "Ekinoks Hotel İznik"),
        CatalogPlace("İstanbul Otel İznik", "Sade küçük otel • ekonomik aday", 40.4297, 29.7210, PoiCategory.STAY, 2, "iznik",
            details = listOf("Tür: Küçük otel", "Fiyat: 2026 tahmini gecelik 1.800–3.600 TL", "Tarih ve kişi sayısına göre güncel fiyatı doğrula"),
            mapSearchQuery = "İstanbul Otel İznik"),
        CatalogPlace("İznik Otel", "Aile oteli • ekonomik fiyat iddiası", 40.4297, 29.7210, PoiCategory.STAY, 2, "iznik",
            details = listOf("Tür: Aile oteli", "Fiyat: Rezervasyon tarihine göre değişir", "Güncel fiyatı işletmenin sayfasından doğrula"),
            mapSearchQuery = "İznik Otel İznik")
    )

    fun results(center: GeoPoint, category: PoiCategory): List<PlaceItem> {
        val local = when (category) {
            PoiCategory.BEACH -> localPlaces(center, category, 14.0, 10)
            PoiCategory.MYSTERY -> localPlaces(center, category, 25.0, 20)
            PoiCategory.FOOD -> localPlaces(center, category, 5.0, 10)
            PoiCategory.STAY -> localPlaces(center, category, 7.0, 10)
            PoiCategory.WAYPOINT -> emptyList()
        }

        // V16: Google/harita arama kartları kaldırıldı. Bu katman yalnız uygulamanın
        // içinde gösterilecek somut, bölge kilitli kayıtları döndürür. Canlı sonuçlar
        // ApiService tarafından OpenStreetMap verisinden uygulama içine eklenir.
        return local.distinctBy { (it.mapSearchQuery ?: it.name).lowercase(tr) }
    }

    fun routeSuggestion(center: GeoPoint, category: PoiCategory): PlaceItem? =
        localPlaces(
            center,
            category,
            when (category) {
                PoiCategory.BEACH -> 14.0
                PoiCategory.MYSTERY -> 12.0
                PoiCategory.FOOD -> 5.0
                PoiCategory.STAY -> 7.0
                PoiCategory.WAYPOINT -> 0.0
            },
            1
        ).firstOrNull()

    private fun localPlaces(center: GeoPoint, category: PoiCategory, maxKm: Double, limit: Int): List<PlaceItem> {
        val centerKey = key(center.name)
        val categoryPlaces = places.filter { it.category == category }

        // İlçe + il biçimindeki adlarda (ör. “Marmaris Muğla”, “İznik Bursa”)
        // yalnız en özgül eşleşme kullanılır. Böylece İznik yazıldığında Bursa geneli,
        // Kıyıkışlacık yazıldığında Milas/Didim gibi daha geniş bölgeler karışmaz.
        val matchingKeys = categoryPlaces
            .mapNotNull { it.regionKey?.let(::key) }
            .filter { regionMatches(centerKey, it) }
        val mostSpecificLength = matchingKeys.maxOfOrNull { it.length }

        return categoryPlaces.asSequence()
            .filter { entry ->
                val required = entry.regionKey?.let(::key)
                required == null || (
                    mostSpecificLength != null &&
                        required.length == mostSpecificLength &&
                        regionMatches(centerKey, required)
                    )
            }
            .map { it to haversineKm(center, GeoPoint(it.name, it.lat, it.lon)) }
            .filter { it.second <= maxKm }
            // En yakın önce gelir; düşük öncelik yalnız eşit mesafede etkili olur.
            .sortedWith(compareBy<Pair<CatalogPlace, Double>> { it.second }.thenBy { it.first.priority })
            .take(limit)
            .map { (entry, distance) ->
                val usesRegionCenter = entry.mapSearchQuery != null &&
                    abs(entry.lat - center.latitude) < 0.00001 &&
                    abs(entry.lon - center.longitude) < 0.00001
                val distanceLine = if (usesRegionCenter) {
                    "Mesafe: İşletmenin canlı harita konumunda doğrulanır"
                } else {
                    distanceText(distance)
                }
                PlaceItem(
                    name = entry.name,
                    subtitle = entry.subtitle,
                    latitude = entry.lat,
                    longitude = entry.lon,
                    category = entry.category,
                    priority = entry.priority,
                    note = entry.note,
                    details = listOf("Kaynak: Yerleşik bölge önerisi", distanceLine, "Bölge kilidi: ${center.name}") + entry.details,
                    mapSearchQuery = entry.mapSearchQuery,
                    isSearchCard = entry.isSearchCard
                )
            }
            .toList()
    }

    private fun distanceText(distance: Double): String = if (distance < 1.0) {
        "Mesafe: ${(distance * 1000).roundToInt()} m"
    } else {
        "Mesafe: ${String.format(tr, "%.1f", distance)} km"
    }

    private fun price(min: Int, max: Int, multiplier: Double): String {
        val a = round50(min * multiplier)
        val b = round50(max * multiplier)
        return "${formatTl(a)}–${formatTl(b)} TL"
    }

    private fun priceMultiplier(region: String): Double {
        val text = region.lowercase(tr)
        return when {
            listOf("bodrum", "çeşme", "alaçatı", "kaş", "kalkan").any { it in text } -> 1.25
            listOf("fethiye", "marmaris", "datça", "antalya", "kuşadası", "ayvalık").any { it in text } -> 1.12
            else -> 1.0
        }
    }


    private fun regionMatches(centerKey: String, regionKey: String): Boolean {
        if (centerKey == regionKey) return true
        val centerTokens = centerKey.split(' ').filter { it.isNotBlank() }.toSet()
        val regionTokens = regionKey.split(' ').filter { it.isNotBlank() }
        return regionTokens.isNotEmpty() && regionTokens.all { it in centerTokens }
    }

    private fun key(value: String): String = value.lowercase(tr)
        .replace('ı', 'i')
        .replace('ğ', 'g')
        .replace('ü', 'u')
        .replace('ş', 's')
        .replace('ö', 'o')
        .replace('ç', 'c')
        .replace(Regex("[^a-z0-9]+"), " ")
        .trim()

    private fun round50(value: Double): Int = ((value / 50.0).roundToInt() * 50).coerceAtLeast(50)
    private fun formatTl(value: Int): String = String.format(tr, "%,d", value).replace(',', '.')
}
