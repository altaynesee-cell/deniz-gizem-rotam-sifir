package com.altayaytin.denizgizemrotamsifir

import java.util.Locale
import kotlin.math.roundToInt

/**
 * Uygulamanın hızlı ve kararlı çalışan yerleşik kataloğu.
 * Canlı işletme aramaları Google Maps'e aktarılır; böylece açık harita sunucusunun
 * yoğunluğu uygulamayı kilitlemez.
 */
internal object LocalCatalog {
    private val tr = Locale("tr", "TR")

    private data class CatalogPlace(
        val name: String,
        val subtitle: String,
        val lat: Double,
        val lon: Double,
        val category: PoiCategory,
        val priority: Int,
        val note: String? = null,
        val details: List<String> = emptyList()
    )

    private val places = listOf(
        // Plajlar ve koylar — özel beach club sonuçları bilerek yoktur.
        CatalogPlace("Ocaklar Halk Plajı", "Halk plajı", 40.3656, 27.8783, PoiCategory.BEACH, 1,
            details = listOf("Zemin: Genellikle kum", "Erişim: Halk plajı", "Sığlık: Yerinde kontrol et", "Metal dedektör hobisi: Kumlu bölümler uygun aday")),
        CatalogPlace("Çuğra Plajı", "Halk plajı", 40.3896, 27.7818, PoiCategory.BEACH, 2,
            details = listOf("Zemin: Kum ve yer yer çakıl", "Erişim: Halka açık bölümler", "Sığlık: Yerinde kontrol et")),
        CatalogPlace("Sarımsaklı Plajı", "Uzun halk plajı", 39.2739, 26.6587, PoiCategory.BEACH, 1,
            details = listOf("Zemin: Kum", "Erişim: Ücretsiz halk bölümleri bulunur", "Sığlık: Genellikle yavaş derinleşen kesimler", "Metal dedektör hobisi: İyi aday; yerel kuralları kontrol et")),
        CatalogPlace("Badavut Plajı", "Doğal plaj", 39.2425, 26.6298, PoiCategory.BEACH, 2,
            details = listOf("Zemin: Kum ağırlıklı", "Erişim: Doğal plaj", "Sığlık ve dalga: Rüzgâra göre değişir")),
        CatalogPlace("Ilıca Halk Plajı", "Halk plajı", 38.3069, 26.3667, PoiCategory.BEACH, 1,
            details = listOf("Zemin: Kum", "Erişim: Halk plajı", "Sığlık: Geniş sığ alanlarıyla bilinir", "Metal dedektör hobisi: İyi aday; yoğunluk ve yerel kuralları kontrol et")),
        CatalogPlace("Altınkum Halk Plajı", "Halk plajı", 38.2597, 26.2764, PoiCategory.BEACH, 2,
            details = listOf("Zemin: Kum", "Erişim: Halk bölümleri", "Dalga: Rüzgâra göre değişebilir")),
        CatalogPlace("Kadınlar Plajı", "Halk plajı", 37.8420, 27.2496, PoiCategory.BEACH, 2,
            details = listOf("Zemin: Kum", "Erişim: Halk plajı", "Sığlık: Bölüme göre değişir")),
        CatalogPlace("Sevgi Plajı", "Uzun halk plajı", 37.7342, 27.2204, PoiCategory.BEACH, 1,
            details = listOf("Zemin: Kum", "Erişim: Halk plajı", "Metal dedektör hobisi: Kumlu ve geniş alan; yerel kuralları kontrol et")),
        CatalogPlace("Altınkum Plajı Didim", "Halk plajı", 37.3567, 27.2779, PoiCategory.BEACH, 2,
            details = listOf("Zemin: Kum", "Erişim: Halk plajı", "Sığlık: Bölüme ve mevsime göre değişir")),
        CatalogPlace("Akbük Sahili", "Halk sahili", 37.3918, 27.4308, PoiCategory.BEACH, 1,
            details = listOf("Zemin: Kum ve çakıl karışık bölümler", "Erişim: Halka açık sahil", "Dalga: Koy yapısı nedeniyle çoğu gün daha sakindir")),
        CatalogPlace("Bitez Plajı", "Halk plajı", 37.0258, 27.3857, PoiCategory.BEACH, 2,
            details = listOf("Zemin: Kum ve yer yer çakıl", "Erişim: Halk bölümleri", "Sığlık: Bazı kesimlerde yavaş derinleşir")),
        CatalogPlace("Ortakent Yahşi Halk Plajı", "Halk plajı", 37.0126, 27.3491, PoiCategory.BEACH, 2,
            details = listOf("Zemin: Kum ve çakıl", "Erişim: Halk bölümleri", "Dalga: Rüzgâra göre değişir")),
        CatalogPlace("Karaincir Halk Plajı", "Koy içi halk plajı", 36.9726, 27.2964, PoiCategory.BEACH, 1,
            details = listOf("Zemin: Kum", "Erişim: Halka açık bölüm", "Sığlık: Genellikle yavaş derinleşen kesimler")),
        CatalogPlace("Kumluk Plajı", "Merkez halk plajı", 36.7250, 27.6873, PoiCategory.BEACH, 2,
            details = listOf("Zemin: Kum/ince çakıl", "Erişim: Merkezde halka açık", "Sığlık: Yerinde kontrol et")),
        CatalogPlace("Palamutbükü Sahili", "Doğal sahil", 36.6721, 27.5054, PoiCategory.BEACH, 2,
            details = listOf("Zemin: Çakıl ve kum karışık", "Erişim: Halka açık sahil", "Sığlık: Kısa mesafede derinleşen bölümler olabilir")),
        CatalogPlace("İçmeler Halk Plajı", "Halk plajı", 36.8010, 28.2318, PoiCategory.BEACH, 2,
            details = listOf("Zemin: Kum/ince çakıl", "Erişim: Halka açık bölümler", "Sığlık: Bölüme göre değişir")),
        CatalogPlace("Turunç Halk Plajı", "Koy içi halk plajı", 36.7730, 28.2488, PoiCategory.BEACH, 2,
            details = listOf("Zemin: Kum ve çakıl", "Erişim: Halka açık", "Dalga: Koy içinde çoğu gün daha sakindir")),
        CatalogPlace("Çalış Plajı", "Uzun halk sahili", 36.6592, 29.1053, PoiCategory.BEACH, 2,
            details = listOf("Zemin: Çakıl/kum karışık", "Erişim: Halk sahili", "Dalga: Rüzgâra açık günlerde artabilir")),
        CatalogPlace("Ölüdeniz Belcekız Plajı", "Halk plajı", 36.5488, 29.1231, PoiCategory.BEACH, 2,
            details = listOf("Zemin: Kum ve çakıl", "Erişim: Halk bölümü", "Yoğunluk: Yazın yüksek olabilir")),
        CatalogPlace("Büyük Çakıl Plajı", "Doğal halk plajı", 36.1947, 29.6574, PoiCategory.BEACH, 2,
            details = listOf("Zemin: Çakıl", "Erişim: Halka açık", "Metal dedektör hobisi: Kumlu plajlara göre düşük aday")),
        CatalogPlace("Kaputaş Plajı", "Doğal plaj", 36.2289, 29.4508, PoiCategory.BEACH, 2,
            details = listOf("Zemin: Kum ve küçük çakıl", "Erişim: Halka açık", "Sığlık: Dalga ve kıyı eğimi değişebilir")),
        CatalogPlace("Konyaaltı Halk Plajı", "Uzun halk plajı", 36.8647, 30.6377, PoiCategory.BEACH, 2,
            details = listOf("Zemin: Çakıl", "Erişim: Halka açık", "Metal dedektör hobisi: Kumlu plajlara göre düşük aday")),
        CatalogPlace("Lara Halk Plajı", "Halk plajı", 36.8485, 30.8013, PoiCategory.BEACH, 1,
            details = listOf("Zemin: Kum", "Erişim: Halk bölümleri", "Metal dedektör hobisi: İyi aday; yerel kuralları kontrol et")),
        CatalogPlace("Kızkalesi Halk Plajı", "Halk plajı", 36.4596, 34.1455, PoiCategory.BEACH, 1,
            details = listOf("Zemin: Kum", "Erişim: Halk plajı", "Sığlık: Kıyı bölümüne göre değişir")),
        CatalogPlace("Yapraklı Koy", "Doğal koy", 36.4837, 34.1733, PoiCategory.BEACH, 2,
            details = listOf("Zemin: Kaya/kum karışık", "Erişim: Doğal koy", "Sığlık: Giriş noktasına göre değişir")),

        // Tarih ve gizem — kalıcı, işletme olmayan noktalar.
        CatalogPlace("Bursa Ulu Cami", "Tarihî yapı", 40.1839, 29.0619, PoiCategory.MYSTERY, 3),
        CatalogPlace("Muradiye Külliyesi", "Tarihî külliye", 40.1907, 29.0434, PoiCategory.MYSTERY, 2),
        CatalogPlace("Gölyazı ve Apollonia ad Rhyndacum", "Tarihî yerleşim", 40.1712, 28.6828, PoiCategory.MYSTERY, 1),
        CatalogPlace("İznik Ayasofya Orhan Camii", "Tarihî yapı", 40.4292, 29.7200, PoiCategory.MYSTERY, 1),
        CatalogPlace("İznik Surları", "Tarihî savunma yapısı", 40.4288, 29.7208, PoiCategory.MYSTERY, 1),
        CatalogPlace("Kyzikos Antik Kenti", "Arkeolojik alan", 40.3565, 27.8872, PoiCategory.MYSTERY, 1),
        CatalogPlace("Adatepe Zeus Altarı", "Mitolojik/tarihî nokta", 39.5468, 26.6277, PoiCategory.MYSTERY, 2),
        CatalogPlace("Assos Antik Kenti", "Arkeolojik alan", 39.4897, 26.3367, PoiCategory.MYSTERY, 1),
        CatalogPlace("Bergama Akropolü", "Arkeolojik alan", 39.1326, 27.1841, PoiCategory.MYSTERY, 1),
        CatalogPlace("İzmir Agora Ören Yeri", "Arkeolojik alan", 38.4193, 27.1388, PoiCategory.MYSTERY, 1),
        CatalogPlace("Kadifekale", "Tarihî kale", 38.4148, 27.1468, PoiCategory.MYSTERY, 2),
        CatalogPlace("Efes Antik Kenti", "Arkeolojik alan", 37.9390, 27.3410, PoiCategory.MYSTERY, 1),
        CatalogPlace("Artemis Tapınağı", "Antik kutsal alan", 37.9497, 27.3639, PoiCategory.MYSTERY, 1),
        CatalogPlace("Didyma Apollon Tapınağı", "Antik kutsal alan", 37.3849, 27.2568, PoiCategory.MYSTERY, 1),
        CatalogPlace("Milet Antik Kenti", "Arkeolojik alan", 37.5307, 27.2760, PoiCategory.MYSTERY, 1),
        CatalogPlace("Bodrum Kalesi", "Tarihî kale", 37.0318, 27.4293, PoiCategory.MYSTERY, 1),
        CatalogPlace("Halikarnas Mozolesi", "Antik anıt", 37.0380, 27.4241, PoiCategory.MYSTERY, 1),
        CatalogPlace("Knidos Antik Kenti", "Arkeolojik alan", 36.6851, 27.3746, PoiCategory.MYSTERY, 1),
        CatalogPlace("Kaunos Antik Kenti", "Arkeolojik alan", 36.8260, 28.6258, PoiCategory.MYSTERY, 1),
        CatalogPlace("Kayaköy", "Terk edilmiş tarihî yerleşim", 36.5768, 29.0907, PoiCategory.MYSTERY, 1),
        CatalogPlace("Amyntas Kaya Mezarları", "Antik kaya mezarları", 36.6202, 29.1156, PoiCategory.MYSTERY, 1),
        CatalogPlace("Patara Antik Kenti", "Arkeolojik alan", 36.2623, 29.3150, PoiCategory.MYSTERY, 1),
        CatalogPlace("Antiphellos Antik Tiyatrosu", "Antik tiyatro", 36.1997, 29.6345, PoiCategory.MYSTERY, 2),
        CatalogPlace("Perge Antik Kenti", "Arkeolojik alan", 36.9587, 30.8524, PoiCategory.MYSTERY, 1),
        CatalogPlace("Termessos Antik Kenti", "Dağlık arkeolojik alan", 36.9830, 30.4655, PoiCategory.MYSTERY, 1),
        CatalogPlace("Soli Pompeiopolis Antik Kenti", "Arkeolojik alan", 36.7434, 34.5400, PoiCategory.MYSTERY, 1),
        CatalogPlace("Kızkalesi", "Tarihî deniz kalesi", 36.4576, 34.1480, PoiCategory.MYSTERY, 1),
        CatalogPlace("Kleopatra Kapısı", "Tarihî kapı", 36.9164, 34.8959, PoiCategory.MYSTERY, 1),
        CatalogPlace("St. Paul Kuyusu", "Tarihî/inanç noktası", 36.9190, 34.8976, PoiCategory.MYSTERY, 2)
    )

    fun results(center: GeoPoint, category: PoiCategory): List<PlaceItem> {
        return when (category) {
            PoiCategory.FOOD -> foodSearchCards(center)
            PoiCategory.STAY -> staySearchCards(center)
            PoiCategory.BEACH -> localPlaces(center, category, 130.0, 12) + beachSearchCards(center)
            PoiCategory.MYSTERY -> localPlaces(center, category, 140.0, 16) + mysterySearchCards(center)
            PoiCategory.WAYPOINT -> emptyList()
        }.distinctBy { (it.mapSearchQuery ?: it.name).lowercase(tr) }
    }

    fun routeSuggestion(center: GeoPoint, category: PoiCategory): PlaceItem? =
        localPlaces(center, category, when (category) {
            PoiCategory.BEACH -> 80.0
            PoiCategory.MYSTERY -> 90.0
            else -> 0.0
        }, 1).firstOrNull()

    private fun localPlaces(center: GeoPoint, category: PoiCategory, maxKm: Double, limit: Int): List<PlaceItem> =
        places.asSequence()
            .filter { it.category == category }
            .map { it to haversineKm(center, GeoPoint(it.name, it.lat, it.lon)) }
            .filter { it.second <= maxKm }
            .sortedWith(compareBy<Pair<CatalogPlace, Double>> { it.first.priority }.thenBy { it.second })
            .take(limit)
            .map { (entry, distance) ->
                PlaceItem(
                    name = entry.name,
                    subtitle = entry.subtitle,
                    latitude = entry.lat,
                    longitude = entry.lon,
                    category = entry.category,
                    priority = entry.priority,
                    note = entry.note,
                    details = listOf(distanceText(distance)) + entry.details
                )
            }
            .toList()

    private fun foodSearchCards(center: GeoPoint): List<PlaceItem> {
        val multiplier = priceMultiplier(center.name)
        return listOf(
            searchCard(center, PoiCategory.FOOD, "Ev yemekleri ve esnaf lokantaları", "Canlı yakın arama", "ev yemekleri esnaf lokantası", 0,
                listOf("Tahmini uygun fiyat: kişi başı ${price(220, 400, multiplier)}", "Pastane, kafe ve tatlıcı aramasına girmez")),
            searchCard(center, PoiCategory.FOOD, "Pide ve lahmacun", "Canlı yakın arama", "pide lahmacun", 1,
                listOf("Tahmini uygun fiyat: kişi başı ${price(240, 450, multiplier)}")),
            searchCard(center, PoiCategory.FOOD, "Kebap, döner ve köfte", "Canlı yakın arama", "kebap döner köfte", 2,
                listOf("Tahmini uygun fiyat: kişi başı ${price(300, 600, multiplier)}"))
        )
    }

    private fun staySearchCards(center: GeoPoint): List<PlaceItem> {
        val multiplier = priceMultiplier(center.name)
        return listOf(
            searchCard(center, PoiCategory.STAY, "Pansiyon ve apart", "Canlı yakın arama", "pansiyon apart", 0,
                listOf("Tahmini ekonomik fiyat: gecelik ${price(1_500, 3_200, multiplier)}")),
            searchCard(center, PoiCategory.STAY, "Ekonomik küçük oteller", "Canlı yakın arama", "ekonomik otel", 1,
                listOf("Tahmini ekonomik fiyat: gecelik ${price(2_000, 4_200, multiplier)}")),
            searchCard(center, PoiCategory.STAY, "Kamp ve karavan alanları", "Canlı yakın arama", "kamp alanı karavan", 2,
                listOf("Tahmini fiyat: gecelik ${price(700, 1_800, multiplier)}", "Araçla konaklama iznini işletmeden veya yerel yönetimden doğrula"))
        )
    }

    private fun beachSearchCards(center: GeoPoint): List<PlaceItem> = listOf(
        searchCard(center, PoiCategory.BEACH, "Yakındaki halk plajlarını canlı ara", "Google Maps canlı araması", "halk plajı", 90,
            listOf("Özel beach club yerine halk plajı sorgusu açılır", "Kum, sığlık ve ücret bilgisini yer sayfasından kontrol et")),
        searchCard(center, PoiCategory.BEACH, "Yakındaki doğal koyları canlı ara", "Google Maps canlı araması", "doğal koy yüzme", 91,
            listOf("En yakın koylar arama merkezine göre gösterilir"))
    )

    private fun mysterySearchCards(center: GeoPoint): List<PlaceItem> = listOf(
        searchCard(center, PoiCategory.MYSTERY, "Yakındaki antik kent ve ören yerleri", "Google Maps canlı araması", "antik kent ören yeri", 90),
        searchCard(center, PoiCategory.MYSTERY, "Yakındaki kale, mağara ve müzeler", "Google Maps canlı araması", "kale mağara müze", 91)
    )

    private fun searchCard(
        center: GeoPoint,
        category: PoiCategory,
        name: String,
        subtitle: String,
        query: String,
        priority: Int,
        details: List<String> = emptyList()
    ) = PlaceItem(
        name = name,
        subtitle = subtitle,
        latitude = center.latitude,
        longitude = center.longitude,
        category = category,
        priority = priority,
        note = "${center.name} merkezine göre en yakın canlı sonuçları haritada açar.",
        details = details,
        mapSearchQuery = query
    )

    private fun distanceText(distance: Double): String = if (distance < 1.0) {
        "Mesafe: ${(distance * 1000).roundToInt()} m"
    } else {
        "Mesafe: ${String.format(tr, "%.1f", distance)} km"
    }

    private fun price(min: Int, max: Int, multiplier: Double): String {
        val a = round50(min * multiplier)
        val b = round50(max * multiplier)
        return "${formatTl(a)}–${formatTl(b)} TL"
    }

    private fun priceMultiplier(region: String): Double {
        val text = region.lowercase(tr)
        return when {
            listOf("bodrum", "çeşme", "alaçatı", "kaş", "kalkan").any { it in text } -> 1.25
            listOf("fethiye", "marmaris", "datça", "antalya", "kuşadası", "ayvalık").any { it in text } -> 1.12
            else -> 1.0
        }
    }

    private fun round50(value: Double): Int = ((value / 50.0).roundToInt() * 50).coerceAtLeast(50)
    private fun formatTl(value: Int): String = String.format(tr, "%,d", value).replace(',', '.')
}
