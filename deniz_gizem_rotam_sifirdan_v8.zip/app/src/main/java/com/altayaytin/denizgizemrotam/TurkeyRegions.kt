package com.altayaytin.denizgizemrotamsifir

import java.util.Locale
import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/** Türkiye geneli il kilidi. */
internal object TurkeyRegions {
    private val tr = Locale("tr", "TR")

    internal data class Province(
        val name: String,
        val latitude: Double,
        val longitude: Double,
        val aliases: Set<String> = emptySet()
    )

    val provinces: List<Province> = listOf(
        Province("Adana", 37.0000, 35.3213), Province("Adıyaman", 37.7648, 38.2786),
        Province("Afyonkarahisar", 38.7507, 30.5567, setOf("Afyon")), Province("Ağrı", 39.7191, 43.0503),
        Province("Amasya", 40.6499, 35.8353), Province("Ankara", 39.9334, 32.8597),
        Province("Antalya", 36.8969, 30.7133), Province("Artvin", 41.1828, 41.8183),
        Province("Aydın", 37.8450, 27.8396), Province("Balıkesir", 39.6484, 27.8826),
        Province("Bilecik", 40.1501, 29.9831), Province("Bingöl", 38.8853, 40.4983),
        Province("Bitlis", 38.4006, 42.1095), Province("Bolu", 40.7395, 31.6116),
        Province("Burdur", 37.7203, 30.2908), Province("Bursa", 40.1950, 29.0600),
        Province("Çanakkale", 40.1467, 26.4086), Province("Çankırı", 40.6013, 33.6134),
        Province("Çorum", 40.5506, 34.9556), Province("Denizli", 37.7765, 29.0864),
        Province("Diyarbakır", 37.9144, 40.2306), Province("Edirne", 41.6771, 26.5557),
        Province("Elazığ", 38.6743, 39.2232), Province("Erzincan", 39.7500, 39.5000),
        Province("Erzurum", 39.9043, 41.2679), Province("Eskişehir", 39.7767, 30.5206),
        Province("Gaziantep", 37.0662, 37.3833, setOf("Antep")), Province("Giresun", 40.9128, 38.3895),
        Province("Gümüşhane", 40.4386, 39.5086), Province("Hakkâri", 37.5744, 43.7408, setOf("Hakkari")),
        Province("Hatay", 36.2021, 36.1600, setOf("Antakya")), Province("Isparta", 37.7648, 30.5566),
        Province("Mersin", 36.8121, 34.6415, setOf("İçel", "Icel")), Province("İstanbul", 41.0082, 28.9784),
        Province("İzmir", 38.4237, 27.1428), Province("Kars", 40.6013, 43.0975),
        Province("Kastamonu", 41.3887, 33.7827), Province("Kayseri", 38.7225, 35.4875),
        Province("Kırklareli", 41.7351, 27.2252), Province("Kırşehir", 39.1425, 34.1709),
        Province("Kocaeli", 40.8533, 29.8815, setOf("İzmit", "Izmit")), Province("Konya", 37.8746, 32.4932),
        Province("Kütahya", 39.4192, 29.9857), Province("Malatya", 38.3552, 38.3095),
        Province("Manisa", 38.6140, 27.4296), Province("Kahramanmaraş", 37.5753, 36.9228, setOf("Maraş", "Maras")),
        Province("Mardin", 37.3122, 40.7350), Province("Muğla", 37.2153, 28.3636),
        Province("Muş", 38.7432, 41.5064), Province("Nevşehir", 38.6244, 34.7239),
        Province("Niğde", 37.9698, 34.6766), Province("Ordu", 40.9839, 37.8764),
        Province("Rize", 41.0201, 40.5234), Province("Sakarya", 40.7569, 30.3781, setOf("Adapazarı", "Adapazari")),
        Province("Samsun", 41.2867, 36.3300), Province("Siirt", 37.9333, 41.9500),
        Province("Sinop", 42.0231, 35.1531), Province("Sivas", 39.7477, 37.0179),
        Province("Tekirdağ", 40.9780, 27.5110), Province("Tokat", 40.3167, 36.5500),
        Province("Trabzon", 41.0027, 39.7168), Province("Tunceli", 39.1079, 39.5401),
        Province("Şanlıurfa", 37.1674, 38.7955, setOf("Urfa")), Province("Uşak", 38.6823, 29.4082),
        Province("Van", 38.4891, 43.4089), Province("Yozgat", 39.8181, 34.8147),
        Province("Zonguldak", 41.4564, 31.7987), Province("Aksaray", 38.3687, 34.0370),
        Province("Bayburt", 40.2552, 40.2249), Province("Karaman", 37.1810, 33.2150),
        Province("Kırıkkale", 39.8468, 33.5153), Province("Batman", 37.8812, 41.1351),
        Province("Şırnak", 37.4187, 42.4918), Province("Bartın", 41.6344, 32.3375),
        Province("Ardahan", 41.1105, 42.7022), Province("Iğdır", 39.9167, 44.0333),
        Province("Yalova", 40.6500, 29.2667), Province("Karabük", 41.2061, 32.6204),
        Province("Kilis", 36.7184, 37.1212), Province("Osmaniye", 37.0742, 36.2478),
        Province("Düzce", 40.8438, 31.1565)
    )

    private val localityProvince = mapOf(
        "golyazi" to "Bursa", "iznik" to "Bursa", "mudanya" to "Bursa", "trilye" to "Bursa",
        "gemlik" to "Bursa", "orhangazi" to "Bursa", "inegol" to "Bursa",
        "erdek" to "Balıkesir", "ayvalik" to "Balıkesir", "assos" to "Çanakkale",
        "dikili" to "İzmir", "foca" to "İzmir", "cesme" to "İzmir", "alacati" to "İzmir",
        "sigacik" to "İzmir", "seferihisar" to "İzmir", "efes" to "İzmir", "selcuk" to "İzmir",
        "kusadasi" to "Aydın", "didim" to "Aydın", "bodrum" to "Muğla", "datca" to "Muğla",
        "marmaris" to "Muğla", "akyaka" to "Muğla", "dalyan" to "Muğla", "fethiye" to "Muğla",
        "oludeniz" to "Muğla", "koycegiz" to "Muğla", "ortaca" to "Muğla", "milas" to "Muğla",
        "kiyikislacik" to "Muğla", "iasos" to "Muğla", "kalkan" to "Antalya", "kas" to "Antalya",
        "demre" to "Antalya", "side" to "Antalya", "alanya" to "Antalya", "manavgat" to "Antalya",
        "tarsus" to "Mersin", "erdemli" to "Mersin", "kizkalesi" to "Mersin",
        "safranbolu" to "Karabük", "beypazari" to "Ankara", "akcaabat" to "Trabzon",
        "bafra" to "Samsun", "amasra" to "Bartın"
    )

    private val byKey: Map<String, Province> = buildMap {
        provinces.forEach { province ->
            put(key(province.name), province)
            province.aliases.forEach { put(key(it), province) }
        }
    }

    fun resolveProvince(name: String?, latitude: Double, longitude: Double): String? {
        val text = key(name.orEmpty())
        if (text.isNotBlank()) {
            byKey[text]?.let { return it.name }
            localityProvince.entries.sortedByDescending { it.key.length }
                .firstOrNull { tokenContains(text, it.key) }?.value?.let { return it }
            byKey.entries.sortedByDescending { it.key.length }
                .firstOrNull { tokenContains(text, it.key) }?.value?.let { return it.name }
        }
        if (!latitude.isFinite() || !longitude.isFinite()) return null
        return provinces.minByOrNull { distanceKm(latitude, longitude, it.latitude, it.longitude) }?.name
    }

    fun sameProvince(center: GeoPoint, resultProvinceText: String?, resultLatitude: Double, resultLongitude: Double): Boolean {
        val target = center.province?.takeIf { it.isNotBlank() }
            ?: resolveProvince(center.name, center.latitude, center.longitude)
            ?: return true
        val result = resolveProvince(resultProvinceText, resultLatitude, resultLongitude) ?: return true
        return key(target) == key(result)
    }

    fun isProvinceCenter(center: GeoPoint): Boolean {
        val province = center.province?.takeIf { it.isNotBlank() }
            ?: resolveProvince(center.name, center.latitude, center.longitude)
            ?: return false
        return key(center.name) == key(province)
    }

    private fun tokenContains(text: String, token: String): Boolean =
        text == token || text.startsWith("$token ") || text.endsWith(" $token") || " $token " in " $text "

    private fun key(value: String): String = value.lowercase(tr)
        .replace('ı', 'i').replace('ğ', 'g').replace('ü', 'u')
        .replace('ş', 's').replace('ö', 'o').replace('ç', 'c')
        .replace(Regex("[^a-z0-9]+"), " ").trim()

    private fun distanceKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val earth = 6371.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2) * sin(dLat / 2) + cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) * sin(dLon / 2) * sin(dLon / 2)
        return 2 * earth * asin(sqrt(a.coerceIn(0.0, 1.0)))
    }
}
