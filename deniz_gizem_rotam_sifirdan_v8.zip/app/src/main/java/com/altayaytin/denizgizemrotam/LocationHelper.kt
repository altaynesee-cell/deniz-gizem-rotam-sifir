package com.altayaytin.denizgizemrotamsifir

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.CancellationSignal
import android.os.Looper
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

internal object LocationHelper {
    fun hasPermission(context: Context): Boolean =
        context.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    suspend fun currentPoint(context: Context): GeoPoint {
        if (!hasPermission(context)) {
            throw SecurityException("Konum izni verilmedi.")
        }
        val location = withTimeoutOrNull(4_000) { getBestLocation(context) }
            ?: throw IllegalStateException("Telefon konumu alınamadı. Konum servisini açıp tekrar dene.")
        val region = runCatching {
            ApiService.reverseGeocode(location.latitude, location.longitude)
        }.getOrElse {
            ApiService.nearestKnownRegion(location.latitude, location.longitude)
        }
        return GeoPoint(region, location.latitude, location.longitude)
    }

    @SuppressLint("MissingPermission")
    private suspend fun getBestLocation(context: Context): Location {
        val manager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val providers = listOf(LocationManager.NETWORK_PROVIDER, LocationManager.GPS_PROVIDER)
            .filter { provider -> runCatching { manager.isProviderEnabled(provider) }.getOrDefault(false) }

        if (providers.isEmpty()) {
            throw IllegalStateException("Telefonun konum servisi kapalı.")
        }

        val lastKnown = providers.mapNotNull { provider ->
            runCatching { manager.getLastKnownLocation(provider) }.getOrNull()
        }.maxWithOrNull(compareBy<Location> { it.time }.thenByDescending { -it.accuracy })

        // Kullanıcıyı GPS sabitlemesi için bekletme. Telefonda bulunan son konum
        // yemek ve konaklama sıralaması için yeterlidir; yoksa tek güncel konum istenir.
        if (lastKnown != null) return lastKnown

        var lastError: Throwable? = null
        for (provider in providers) {
            val result = runCatching { requestOneLocation(context, manager, provider) }
            if (result.isSuccess) return result.getOrThrow()
            lastError = result.exceptionOrNull()
        }
        return lastKnown ?: throw (lastError ?: IllegalStateException("Konum alınamadı."))
    }

    @SuppressLint("MissingPermission")
    private suspend fun requestOneLocation(
        context: Context,
        manager: LocationManager,
        provider: String
    ): Location = suspendCancellableCoroutine { continuation ->
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val cancellationSignal = CancellationSignal()
            manager.getCurrentLocation(provider, cancellationSignal, context.mainExecutor) { location ->
                if (!continuation.isActive) return@getCurrentLocation
                if (location != null) continuation.resume(location)
                else continuation.resumeWithException(IllegalStateException("Konum alınamadı."))
            }
            continuation.invokeOnCancellation { cancellationSignal.cancel() }
        } else {
            val listener = object : LocationListener {
                override fun onLocationChanged(location: Location) {
                    manager.removeUpdates(this)
                    if (continuation.isActive) continuation.resume(location)
                }

                @Deprecated("Deprecated in Android")
                override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) = Unit
                override fun onProviderEnabled(provider: String) = Unit
                override fun onProviderDisabled(provider: String) {
                    manager.removeUpdates(this)
                    if (continuation.isActive) {
                        continuation.resumeWithException(IllegalStateException("Konum sağlayıcısı kapalı."))
                    }
                }
            }
            manager.requestSingleUpdate(provider, listener, Looper.getMainLooper())
            continuation.invokeOnCancellation { manager.removeUpdates(listener) }
        }
    }
}
