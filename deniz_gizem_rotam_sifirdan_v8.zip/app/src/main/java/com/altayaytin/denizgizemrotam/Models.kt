package com.altayaytin.denizgizemrotamsifir

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AltRoute
import androidx.compose.material.icons.filled.BeachAccess
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Hotel
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.ui.graphics.vector.ImageVector

internal enum class AppTab(val label: String, val icon: ImageVector) {
    SEA("Deniz", Icons.Default.BeachAccess),
    ROUTE("Rotam", Icons.Default.AltRoute),
    FOOD("Yemek", Icons.Default.Restaurant),
    MYSTERY("Gizem", Icons.Default.Explore),
    STAY("Konak", Icons.Default.Hotel)
}

internal enum class PoiCategory {
    WAYPOINT,
    BEACH,
    FOOD,
    MYSTERY,
    STAY
}

internal enum class RouteKind {
    CUSTOM,
    AEGEAN_MEDITERRANEAN
}

internal data class GeoPoint(
    val name: String,
    val latitude: Double,
    val longitude: Double
)

internal data class PlaceItem(
    val name: String,
    val subtitle: String,
    val latitude: Double,
    val longitude: Double,
    val category: PoiCategory,
    val priority: Int = 99,
    val note: String? = null,
    val details: List<String> = emptyList(),
    val mapSearchQuery: String? = null,
    val isSearchCard: Boolean = false
)

internal data class RouteStop(
    val day: Int,
    val name: String,
    val latitude: Double,
    val longitude: Double,
    val beach: PlaceItem? = null,
    val food: PlaceItem? = null,
    val mystery: PlaceItem? = null,
    val stay: PlaceItem? = null
)

internal data class RoutePlan(
    val startName: String,
    val endName: String,
    val days: Int,
    val distanceKm: Int,
    val durationHours: Int,
    val stops: List<RouteStop>,
    val kind: RouteKind = RouteKind.CUSTOM,
    val variant: Int = 0
)

internal data class SeaConditions(
    val weatherText: String,
    val airTemperature: Double?,
    val apparentTemperature: Double?,
    val windSpeed: Double?,
    val windGust: Double?,
    val waveHeight: Double?,
    val waveDirection: Double?,
    val wavePeriod: Double?,
    val seaTemperature: Double?
)
