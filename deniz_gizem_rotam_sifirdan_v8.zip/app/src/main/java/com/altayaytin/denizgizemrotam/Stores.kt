package com.altayaytin.denizgizemrotamsifir

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

internal object RouteStore {
    private const val PREFS = "deniz_gizem_route"
    private const val KEY_PLAN = "route_plan"

    fun save(context: Context, plan: RoutePlan) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_PLAN, plan.toJson().toString())
            .apply()
    }

    fun load(context: Context): RoutePlan? = runCatching {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_PLAN, null) ?: return null
        JSONObject(raw).toRoutePlan()
    }.getOrNull()
}

internal object ManualRouteStore {
    private const val PREFS = "deniz_gizem_manual_route"
    private const val KEY_ITEMS = "manual_items"

    fun save(context: Context, items: List<PlaceItem>) {
        val json = JSONArray()
        items.forEach { json.put(it.toJson()) }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_ITEMS, json.toString())
            .apply()
    }

    fun load(context: Context): List<PlaceItem> = runCatching {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_ITEMS, null) ?: return emptyList()
        val array = JSONArray(raw)
        buildList {
            for (index in 0 until array.length()) {
                add(array.getJSONObject(index).toPlaceItem())
            }
        }
    }.getOrDefault(emptyList())
}

private fun RoutePlan.toJson(): JSONObject {
    val stopsJson = JSONArray()
    stops.forEach { stop ->
        stopsJson.put(
            JSONObject()
                .put("day", stop.day)
                .put("name", stop.name)
                .put("lat", stop.latitude)
                .put("lon", stop.longitude)
                .putNullable("beach", stop.beach?.toJson())
                .putNullable("food", stop.food?.toJson())
                .putNullable("mystery", stop.mystery?.toJson())
                .putNullable("stay", stop.stay?.toJson())
        )
    }
    return JSONObject()
        .put("start", startName)
        .put("end", endName)
        .put("days", days)
        .put("distanceKm", distanceKm)
        .put("durationHours", durationHours)
        .put("kind", kind.name)
        .put("variant", variant)
        .put("stops", stopsJson)
}

private fun JSONObject.toRoutePlan(): RoutePlan {
    val stopsArray = getJSONArray("stops")
    val stops = buildList {
        for (index in 0 until stopsArray.length()) {
            val item = stopsArray.getJSONObject(index)
            add(
                RouteStop(
                    day = item.getInt("day"),
                    name = item.getString("name"),
                    latitude = item.getDouble("lat"),
                    longitude = item.getDouble("lon"),
                    beach = item.optJSONObject("beach")?.toPlaceItem(),
                    food = item.optJSONObject("food")?.toPlaceItem(),
                    mystery = item.optJSONObject("mystery")?.toPlaceItem(),
                    stay = item.optJSONObject("stay")?.toPlaceItem()
                )
            )
        }
    }
    return RoutePlan(
        startName = getString("start"),
        endName = getString("end"),
        days = getInt("days"),
        distanceKm = optInt("distanceKm"),
        durationHours = optInt("durationHours"),
        stops = stops,
        kind = runCatching { RouteKind.valueOf(optString("kind", RouteKind.CUSTOM.name)) }
            .getOrDefault(RouteKind.CUSTOM),
        variant = optInt("variant", 0)
    )
}

private fun PlaceItem.toJson(): JSONObject = JSONObject()
    .put("name", name)
    .put("subtitle", subtitle)
    .put("lat", latitude)
    .put("lon", longitude)
    .put("category", category.name)
    .put("priority", priority)
    .putNullable("note", note)
    .put("details", JSONArray().also { array -> details.forEach { detail -> array.put(detail) } })
    .putNullable("mapSearchQuery", mapSearchQuery)

private fun JSONObject.toPlaceItem(): PlaceItem = PlaceItem(
    name = getString("name"),
    subtitle = optString("subtitle"),
    latitude = getDouble("lat"),
    longitude = getDouble("lon"),
    category = runCatching { PoiCategory.valueOf(optString("category")) }
        .getOrDefault(PoiCategory.MYSTERY),
    priority = optInt("priority", 99),
    note = optString("note").takeIf { it.isNotBlank() },
    details = optJSONArray("details")?.let { array ->
        buildList { for (index in 0 until array.length()) add(array.optString(index)) }
    }.orEmpty(),
    mapSearchQuery = if (isNull("mapSearchQuery")) null
        else optString("mapSearchQuery").takeIf { it.isNotBlank() && it != "null" }
)

private fun JSONObject.putNullable(key: String, value: Any?): JSONObject {
    if (value == null) put(key, JSONObject.NULL) else put(key, value)
    return this
}
