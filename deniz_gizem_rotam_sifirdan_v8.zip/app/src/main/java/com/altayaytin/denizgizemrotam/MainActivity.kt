package com.altayaytin.denizgizemrotamsifir

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddRoad
import androidx.compose.material.icons.filled.AltRoute
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.BeachAccess
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Directions
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Hotel
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.Route
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            DenizGizemTheme {
                DenizGizemApp()
            }
        }
    }
}

private val AppColors: ColorScheme = darkColorScheme(
    primary = Color(0xFF8ED6F1),
    onPrimary = Color(0xFF06202A),
    secondary = Color(0xFFE7C97D),
    background = Color(0xFF15171B),
    surface = Color(0xFF20252A),
    surfaceVariant = Color(0xFF293138),
    onBackground = Color(0xFFF1F2F4),
    onSurface = Color(0xFFF1F2F4),
    onSurfaceVariant = Color(0xFFD6DCE1),
    error = Color(0xFFFFB4AB)
)

@Composable
private fun DenizGizemTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = AppColors, content = content)
}

private enum class SpecialResearchMode {
    LEGEND,
    LOCAL_FLAVOR
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ApiKeySetupScreen(onSaved: (String) -> Unit) {
    var key by rememberSaveable { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                ScreenHeader(
                    title = "Canlı Türkiye verisini bağla",
                    subtitle = "Geoapify anahtarını bir kez yapıştır. Anahtar GitHub'a veya başka bir sunucuya gönderilmeden yalnız bu telefonda saklanır."
                )
            }
            item {
                ElevatedCard {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            "Geoapify API anahtarı",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "Geoapify'de oluşturduğun yeni anahtarı buraya yapıştır. Ekran görüntüsünde veya mesajda paylaşma.",
                            fontSize = 14.sp
                        )
                        OutlinedTextField(
                            value = key,
                            onValueChange = {
                                key = it.trim()
                                error = null
                            },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("API anahtarını yapıştır") },
                            singleLine = true,
                            visualTransformation = PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Password,
                                imeAction = ImeAction.Done
                            )
                        )
                        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                        Button(
                            onClick = {
                                val cleaned = key.trim()
                                if (cleaned.length < 20 || cleaned.any { it.isWhitespace() }) {
                                    error = "Anahtar eksik görünüyor. Geoapify'den kopyaladığın anahtarın tamamını yapıştır."
                                } else {
                                    onSaved(cleaned)
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("KAYDET VE UYGULAMAYI AÇ")
                        }
                        Text(
                            "Bu yöntem Supabase gerektirmez. Kişisel kullanım için pratiktir; anahtarı yalnız kendi telefonunda kullan.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DenizGizemApp() {
    val context = LocalContext.current
    var apiKey by rememberSaveable { mutableStateOf(ApiKeyStore.load(context)) }
    if (apiKey.isBlank()) {
        ApiKeySetupScreen { savedKey ->
            ApiKeyStore.save(context, savedKey)
            ApiService.configureGeoapifyApiKey(savedKey)
            apiKey = savedKey
        }
        return
    }
    ApiService.configureGeoapifyApiKey(apiKey)

    var selectedTab by rememberSaveable { mutableStateOf(AppTab.ROUTE) }
    var routePlan by remember { mutableStateOf(RouteStore.load(context)) }
    var manualItems by remember { mutableStateOf(ManualRouteStore.load(context)) }
    var activeRegion by rememberSaveable {
        mutableStateOf(
            routePlan?.stops?.lastOrNull()?.name
                ?: manualItems.lastOrNull { it.category == PoiCategory.WAYPOINT }?.name
                ?: ""
        )
    }

    fun setManualItems(items: List<PlaceItem>) {
        manualItems = items
        ManualRouteStore.save(context, items)
    }

    fun toggleManual(place: PlaceItem) {
        val exists = manualItems.any { it.samePlace(place) }
        setManualItems(
            if (exists) manualItems.filterNot { it.samePlace(place) }
            else manualItems + place
        )
    }

    val mainTabs = listOf(
        AppTab.SEA,
        AppTab.ROUTE,
        AppTab.FOOD,
        AppTab.MYSTERY,
        AppTab.STAY
    )

    Scaffold(
        bottomBar = {
            NavigationBar {
                mainTabs.forEach { tab ->
                    NavigationBarItem(
                        selected = selectedTab == tab,
                        onClick = { selectedTab = tab },
                        icon = { Icon(tab.icon, contentDescription = tab.label) },
                        label = {
                            Text(
                                text = tab.label,
                                fontSize = 11.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Clip
                            )
                        },
                        alwaysShowLabel = true
                    )
                }
            }
        }
    ) { innerPadding ->
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            color = MaterialTheme.colorScheme.background
        ) {
            when (selectedTab) {
                AppTab.ROUTE -> RouteScreen(
                    currentPlan = routePlan,
                    manualItems = manualItems,
                    onManualItemsChanged = ::setManualItems,
                    onToggleManual = ::toggleManual,
                    onResetApiKey = {
                        ApiKeyStore.clear(context)
                        ApiService.configureGeoapifyApiKey("")
                        apiKey = ""
                    },
                    onPlanCreated = { plan ->
                        routePlan = plan
                        activeRegion = plan.stops.lastOrNull()?.name.orEmpty()
                        RouteStore.save(context, plan)
                    },
                    onOpenSection = { tab, region ->
                        activeRegion = region
                        selectedTab = tab
                    }
                )

                AppTab.SEA -> SeaScreen(
                    routePlan = routePlan,
                    activeRegion = activeRegion,
                    manualItems = manualItems,
                    onRegionChanged = { activeRegion = it },
                    onToggleManual = ::toggleManual
                )

                AppTab.FOOD -> FoodScreen(
                    routePlan = routePlan,
                    activeRegion = activeRegion,
                    manualItems = manualItems,
                    onRegionChanged = { activeRegion = it },
                    onToggleManual = ::toggleManual,
                    onOpenLocalFlavor = { selectedTab = AppTab.LOCAL_FLAVOR }
                )

                AppTab.MYSTERY -> DiscoveryScreen(
                    routePlan = routePlan,
                    activeRegion = activeRegion,
                    manualItems = manualItems,
                    onRegionChanged = { activeRegion = it },
                    onToggleManual = ::toggleManual,
                    onOpenLegend = { selectedTab = AppTab.LEGEND }
                )

                AppTab.STAY -> PlacesScreen(
                    title = "Konaklama",
                    description = "Yalnız seçtiğin bölgedeki pansiyon, apart, kamp, karavan ve ekonomik aile konaklamalarını gösterir. Resort, spa, lüks ve yüksek yıldızlı oteller önerilmez.",
                    category = PoiCategory.STAY,
                    routePlan = routePlan,
                    activeRegion = activeRegion,
                    manualItems = manualItems,
                    onRegionChanged = { activeRegion = it },
                    onToggleManual = ::toggleManual
                )

                AppTab.LEGEND -> SpecialResearchScreen(
                    title = "Efsane İzleri",
                    description = "Gideceğin bölgede anlatılan yerel efsane, rivayet, antik anlatı ve modern söylentileri birbirinden ayırarak araştırır.",
                    routePlan = routePlan,
                    activeRegion = activeRegion,
                    manualItems = manualItems,
                    onRegionChanged = { activeRegion = it },
                    onToggleManual = ::toggleManual,
                    mode = SpecialResearchMode.LEGEND,
                    onBack = { selectedTab = AppTab.MYSTERY }
                )

                AppTab.LOCAL_FLAVOR -> SpecialResearchScreen(
                    title = "Yörenin Meşhur Lezzeti",
                    description = "Bölgenin imza yemeğini, köklü ve meşhur işletme adaylarını ve en yakın ekonomik aile/esnaf lokantalarını araştırır.",
                    routePlan = routePlan,
                    activeRegion = activeRegion,
                    manualItems = manualItems,
                    onRegionChanged = { activeRegion = it },
                    onToggleManual = ::toggleManual,
                    mode = SpecialResearchMode.LOCAL_FLAVOR,
                    onBack = { selectedTab = AppTab.FOOD }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RouteScreen(
    currentPlan: RoutePlan?,
    manualItems: List<PlaceItem>,
    onManualItemsChanged: (List<PlaceItem>) -> Unit,
    onToggleManual: (PlaceItem) -> Unit,
    onResetApiKey: () -> Unit,
    onPlanCreated: (RoutePlan) -> Unit,
    onOpenSection: (AppTab, String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var manualMode by rememberSaveable { mutableStateOf(false) }
    var start by rememberSaveable { mutableStateOf(currentPlan?.startName.orEmpty()) }
    var end by rememberSaveable { mutableStateOf(currentPlan?.endName.orEmpty()) }
    var viaText by rememberSaveable { mutableStateOf("") }
    var daysText by rememberSaveable { mutableStateOf(currentPlan?.days?.toString() ?: "10") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var plan by remember { mutableStateOf(currentPlan) }
    var manualQuery by rememberSaveable { mutableStateOf("") }
    var manualLoading by remember { mutableStateOf(false) }
    var manualError by remember { mutableStateOf<String?>(null) }

    fun addManualWaypoint() {
        if (manualQuery.isBlank()) {
            manualError = "Rotaya eklemek istediğin şehir, ilçe, plaj veya gezilecek yeri yaz."
            return
        }
        manualLoading = true
        manualError = null
        scope.launch {
            runCatching { ApiService.geocode(manualQuery.trim()) }
                .onSuccess { point ->
                    val item = PlaceItem(
                        name = point.name,
                        subtitle = "Elle eklenen rota durağı",
                        latitude = point.latitude,
                        longitude = point.longitude,
                        category = PoiCategory.WAYPOINT,
                        priority = 0,
                        note = "İlk seçilen yer başlangıç, son seçilen yer bitiş kabul edilir."
                    )
                    if (manualItems.none { it.samePlace(item) }) {
                        onManualItemsChanged(manualItems + item)
                    }
                    manualQuery = ""
                }
                .onFailure { manualError = it.userMessage() }
            manualLoading = false
        }
    }

    fun createCustom(variant: Int = 0) {
        val days = daysText.toIntOrNull()?.coerceIn(2, 14)
        if (start.isBlank() || end.isBlank() || days == null) {
            error = "Başlangıç, bitiş ve 2–14 arasında gün sayısı gir."
            return
        }
        val viaStops = viaText
            .split(',', ';', '\n', '>', '→')
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .distinct()
            .take(10)

        loading = true
        error = null
        scope.launch {
            runCatching {
                ApiService.createSmartRoute(
                    startQuery = start.trim(),
                    endQuery = end.trim(),
                    days = days,
                    variant = variant,
                    viaQueries = viaStops
                )
            }
                .onSuccess { initial ->
                    plan = initial
                    onPlanCreated(initial)
                    // İlk plan beklemeden görünür; canlı OpenStreetMap sonuçları
                    // uygulamanın içinde arka planda günlük kartlara eklenir.
                    scope.launch {
                        runCatching { ApiService.enrichRoutePlan(initial) }
                            .onSuccess { enriched ->
                                plan = enriched
                                onPlanCreated(enriched)
                            }
                    }
                }
                .onFailure { error = it.userMessage() }
            loading = false
        }
    }

    fun createCoastal(variant: Int = 0) {
        loading = true
        error = null
        daysText = "10"
        scope.launch {
            runCatching { ApiService.createAegeanMediterraneanTour(10, variant) }
                .onSuccess { initial ->
                    plan = initial
                    start = initial.startName
                    end = initial.endName
                    onPlanCreated(initial)
                    scope.launch {
                        runCatching { ApiService.enrichRoutePlan(initial) }
                            .onSuccess { enriched ->
                                plan = enriched
                                onPlanCreated(enriched)
                            }
                    }
                }
                .onFailure { error = it.userMessage() }
            loading = false
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            ScreenHeader(
                title = "Rotam",
                subtitle = "Hazır gezi planı oluşturabilir veya bulduğun yerleri seçip kendi rotanı kurabilirsin."
            )
            TextButton(onClick = onResetApiKey) {
                Text("Geoapify anahtarını değiştir")
            }
        }

        item {
            ElevatedCard(
                colors = CardDefaults.elevatedCardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("Rota türünü seç", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    if (!manualMode) {
                        Button(onClick = { manualMode = false }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.AltRoute, null)
                            Spacer(Modifier.width(8.dp))
                            Text("BANA ROTA HAZIRLA (AÇIK)")
                        }
                        OutlinedButton(onClick = { manualMode = true }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.AddRoad, null)
                            Spacer(Modifier.width(8.dp))
                            Text("KENDİ ROTAMI OLUŞTUR (${manualItems.size})")
                        }
                    } else {
                        OutlinedButton(onClick = { manualMode = false }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.AltRoute, null)
                            Spacer(Modifier.width(8.dp))
                            Text("BANA ROTA HAZIRLA")
                        }
                        Button(onClick = { manualMode = true }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.AddRoad, null)
                            Spacer(Modifier.width(8.dp))
                            Text("KENDİ ROTAMI OLUŞTUR (${manualItems.size})")
                        }
                    }
                }
            }
        }

        if (manualMode) {
            item {
                ManualRouteIntro()
            }
            item {
                ElevatedCard {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text("İstediğin durağı kendin ekle", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text(
                            "Başlangıcı önce, bitişi en son ekle. Araya istediğin kadar şehir, koy, plaj veya gezilecek yer koyabilirsin.",
                            fontSize = 13.sp
                        )
                        OutlinedTextField(
                            value = manualQuery,
                            onValueChange = { manualQuery = it },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("Örnek: Bursa, Efes, Didim, Kaş") },
                            singleLine = true
                        )
                        Button(
                            onClick = { addManualWaypoint() },
                            enabled = !manualLoading,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            if (manualLoading) {
                                CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                                Spacer(Modifier.width(8.dp))
                                Text("Yer bulunuyor…")
                            } else {
                                Icon(Icons.Default.AddRoad, null)
                                Spacer(Modifier.width(8.dp))
                                Text("Rotanın sonuna ekle")
                            }
                        }
                    }
                }
            }
            manualError?.let { item { ErrorCard(it) } }
            if (manualItems.isEmpty()) {
                item {
                    InfoCard("Yukarıdaki kutudan durak ekle veya Deniz, Yemek, Gizem ve Konaklama bölümlerindeki “Rotama ekle” düğmesini kullan.")
                }
            } else {
                item {
                    ElevatedCard(
                        colors = CardDefaults.elevatedCardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant
                        )
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text("Seçtiğin rota", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                            Text(
                                "Yerler aşağıdaki sırayla haritaya aktarılır. En fazla ilk 10 durak açılır.",
                                fontSize = 13.sp
                            )
                            Button(
                                onClick = { openDirections(context, manualItems) },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Default.Directions, null)
                                Spacer(Modifier.width(8.dp))
                                Text("Rotayı haritada çiz")
                            }
                            OutlinedButton(
                                onClick = { onManualItemsChanged(emptyList()) },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Default.Delete, null)
                                Spacer(Modifier.width(8.dp))
                                Text("Tüm seçilenleri temizle")
                            }
                        }
                    }
                }

                items(manualItems, key = { it.routeKey() }) { place ->
                    val index = manualItems.indexOfFirst { it.samePlace(place) }
                    ManualPlaceCard(
                        place = place,
                        index = index,
                        total = manualItems.size,
                        onMap = { openMap(context, place.latitude, place.longitude, place.name) },
                        onMoveUp = {
                            if (index > 0) onManualItemsChanged(manualItems.swap(index, index - 1))
                        },
                        onMoveDown = {
                            if (index < manualItems.lastIndex) onManualItemsChanged(manualItems.swap(index, index + 1))
                        },
                        onDelete = { onToggleManual(place) },
                        onOpenSection = { tab -> onOpenSection(tab, place.name) }
                    )
                }
            }
        } else {
            item {
                ElevatedCard {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text("Güzergâhını yaz", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                        Text(
                            "Başlangıç ve bitişi yaz. Geçmek istediğin yerleri de virgülle ekleyebilirsin.",
                            fontSize = 13.sp
                        )
                        OutlinedTextField(
                            value = start,
                            onValueChange = { start = it },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("Başlangıç yeri • Örnek: Bursa") },
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = viaText,
                            onValueChange = { viaText = it },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("Güzergâh / ara duraklar (isteğe bağlı)") },
                            placeholder = { Text("İzmir, Efes, Didim, Bodrum, Fethiye, Kaş") },
                            minLines = 2,
                            maxLines = 4
                        )
                        OutlinedTextField(
                            value = end,
                            onValueChange = { end = it },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("Bitiş yeri • Örnek: Antalya") },
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = daysText,
                            onValueChange = { daysText = it.filter(Char::isDigit).take(2) },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("Kaç gün? (2–14)") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Number,
                                imeAction = ImeAction.Done
                            )
                        )
                        Button(
                            onClick = { createCustom(0) },
                            enabled = !loading,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            if (loading) {
                                CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                                Spacer(Modifier.width(10.dp))
                                Text("Rota hazırlanıyor…")
                            } else {
                                Icon(Icons.Default.AltRoute, null)
                                Spacer(Modifier.width(8.dp))
                                Text("ROTAYI ŞİMDİ HAZIRLA")
                            }
                        }
                        Text(
                            "Rota beklemeden hazırlanır ve her gün için deniz, ekonomik yemek, tarih/gizem ile ekonomik konaklama önerisi verir. Daha fazla sonuç düğmeleri yalnız seçilen günlük durağın çevresini açar.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            item {
                ElevatedCard(
                    colors = CardDefaults.elevatedCardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text("Ege’den Akdeniz’e hazır sahil turu", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                        Text(
                            "Başlangıç ve bitiş yazmadan hazır 10 günlük sahil güzergâhı oluşturur. Ayrıntıları gün kartlarından açarsın.",
                            fontSize = 14.sp
                        )
                        Button(
                            onClick = { createCoastal(0) },
                            enabled = !loading,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.Route, null)
                            Spacer(Modifier.width(8.dp))
                            Text("10 günlük Ege–Akdeniz turu oluştur")
                        }
                    }
                }
            }

            error?.let { item { ErrorCard(it) } }

            plan?.let { route ->
                item {
                    RouteSummaryCard(route)
                }
                item {
                    Button(
                        onClick = {
                            openDirections(
                                context,
                                route.stops.map { stop ->
                                    PlaceItem(
                                        name = stop.name,
                                        subtitle = "${stop.day}. gün durağı",
                                        latitude = stop.latitude,
                                        longitude = stop.longitude,
                                        category = PoiCategory.WAYPOINT
                                    )
                                }
                            )
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Directions, null)
                        Spacer(Modifier.width(8.dp))
                        Text("Tüm rotayı haritada çiz")
                    }
                }
                item {
                    OutlinedButton(
                        onClick = {
                            if (route.kind == RouteKind.AEGEAN_MEDITERRANEAN) {
                                createCoastal(route.variant + 1)
                            } else {
                                start = route.startName
                                end = route.endName
                                daysText = route.days.toString()
                                createCustom(route.variant + 1)
                            }
                        },
                        enabled = !loading,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Refresh, null)
                        Spacer(Modifier.width(8.dp))
                        Text("Alternatif rota ve yerler getir")
                    }
                }

                items(route.stops, key = { "${it.day}-${it.name}" }) { stop ->
                    RouteDayCard(
                        stop = stop,
                        manualItems = manualItems,
                        onToggleManual = onToggleManual,
                        onOpenSection = onOpenSection,
                        onMap = { place -> openPlaceOnMap(context, place) }
                    )
                }
            }
        }

        item { AttributionFooter() }
    }
}

@Composable
private fun ManualRouteIntro() {
    ElevatedCard(
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("KENDİ ROTAMI OLUŞTUR", fontWeight = FontWeight.Bold, fontSize = 22.sp)
            Text("Durakları doğrudan yazarak ekle veya diğer bölümlerde bulduğun yerleri seç. Sıralamayı değiştirip tamamını haritada rota olarak aç.")
        }
    }
}

@Composable
private fun RouteSummaryCard(route: RoutePlan) {
    ElevatedCard(
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("${route.startName} → ${route.endName}", fontWeight = FontWeight.Bold, fontSize = 20.sp)
            Text("${route.days} gün • yaklaşık ${route.distanceKm} km • ${route.durationHours} saat sürüş")
            Text(
                "Günlük plan hazır: sabah deniz, öğle ekonomik yemek, öğleden sonra tarih/gizem ve gece ekonomik konaklama. Yerleşik ve canlı açık harita sonuçları doğrudan uygulamanın içinde birleştirilir.",
                fontSize = 13.sp
            )
        }
    }
}

@Composable
private fun RouteDayCard(
    stop: RouteStop,
    manualItems: List<PlaceItem>,
    onToggleManual: (PlaceItem) -> Unit,
    onOpenSection: (AppTab, String) -> Unit,
    onMap: (PlaceItem) -> Unit
) {
    val context = LocalContext.current
    ElevatedCard {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("${stop.day}. Gün", color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.Bold)
            Text(stop.name, fontSize = 22.sp, fontWeight = FontWeight.Bold)

            stop.beach?.let {
                RoutePlaceRow("Sabah • Deniz", Icons.Default.BeachAccess, it, manualItems.any { saved -> saved.samePlace(it) }, onToggleManual, onMap)
            } ?: MissingRouteItem("Plaj ve koylar için aşağıdaki “Daha fazla deniz” düğmesine bas.")
            stop.food?.let {
                RoutePlaceRow("Öğle/Akşam • Ekonomik yemek", Icons.Default.Restaurant, it, manualItems.any { saved -> saved.samePlace(it) }, onToggleManual, onMap)
            } ?: MissingRouteItem("Ekonomik yemek için “Daha fazla yemek” düğmesine bas.")
            stop.mystery?.let {
                RoutePlaceRow("Öğleden sonra • Tarih/Gizem", Icons.Default.Explore, it, manualItems.any { saved -> saved.samePlace(it) }, onToggleManual, onMap)
            } ?: MissingRouteItem("Tarihî ve gizemli yerler için “Daha fazla keşif” düğmesine bas.")
            stop.stay?.let {
                RoutePlaceRow("Gece • Ekonomik konaklama", Icons.Default.Hotel, it, manualItems.any { saved -> saved.samePlace(it) }, onToggleManual, onMap)
            } ?: MissingRouteItem("Konaklama için “Daha fazla konak” düğmesine bas.")

            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AssistChip(onClick = { onOpenSection(AppTab.SEA, stop.name) }, label = { Text("Daha fazla deniz") })
                AssistChip(onClick = { onOpenSection(AppTab.FOOD, stop.name) }, label = { Text("Daha fazla yemek") })
                AssistChip(onClick = { onOpenSection(AppTab.MYSTERY, stop.name) }, label = { Text("Daha fazla keşif") })
                AssistChip(onClick = { onOpenSection(AppTab.LEGEND, stop.name) }, label = { Text("Efsane izleri") })
                AssistChip(onClick = { onOpenSection(AppTab.LOCAL_FLAVOR, stop.name) }, label = { Text("Yöresel lezzet") })
                AssistChip(onClick = { onOpenSection(AppTab.STAY, stop.name) }, label = { Text("Daha fazla konak") })
            }
        }
    }
}

@Composable
private fun RoutePlaceRow(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    place: PlaceItem,
    selected: Boolean,
    onToggleManual: (PlaceItem) -> Unit,
    onMap: (PlaceItem) -> Unit
) {
    ElevatedCard(
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(icon, null, Modifier.size(20.dp))
                Text(label, color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.Bold)
            }
            Text(place.name, fontWeight = FontWeight.Bold)
            Text(place.subtitle, fontSize = 13.sp)
            place.note?.let { note ->
                Text(note, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            place.details.take(3).forEach { detail ->
                Text("• $detail", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = { onMap(place) }) {
                    Text("Konumu aç")
                }
                if (!place.isSearchCard) {
                    TextButton(onClick = { onToggleManual(place) }) {
                        Text(if (selected) "Rotadan çıkar" else "Rotama ekle")
                    }
                }
            }
        }
    }
}

@Composable
private fun MissingRouteItem(text: String) {
    Text(text, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
}

@Composable
private fun ManualPlaceCard(
    place: PlaceItem,
    index: Int,
    total: Int,
    onMap: () -> Unit,
    onMoveUp: () -> Unit,
    onMoveDown: () -> Unit,
    onDelete: () -> Unit,
    onOpenSection: (AppTab) -> Unit
) {
    ElevatedCard {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text("${index + 1}. ${place.name}", fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Text("${categoryLabel(place.category)} • ${place.subtitle}", color = MaterialTheme.colorScheme.secondary)
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                TextButton(onClick = onMap) { Text("Harita") }
                IconButton(onClick = onMoveUp, enabled = index > 0) {
                    Icon(Icons.Default.ArrowUpward, "Yukarı taşı")
                }
                IconButton(onClick = onMoveDown, enabled = index < total - 1) {
                    Icon(Icons.Default.ArrowDownward, "Aşağı taşı")
                }
                IconButton(onClick = onDelete) {
                    Icon(Icons.Default.Delete, "Rotadan çıkar")
                }
            }
            if (place.category == PoiCategory.WAYPOINT) {
                Text("Bu durakta araştır", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AssistChip(onClick = { onOpenSection(AppTab.SEA) }, label = { Text("Deniz") })
                    AssistChip(onClick = { onOpenSection(AppTab.FOOD) }, label = { Text("Yemek") })
                    AssistChip(onClick = { onOpenSection(AppTab.MYSTERY) }, label = { Text("Gizem") })
                    AssistChip(onClick = { onOpenSection(AppTab.LEGEND) }, label = { Text("Efsane") })
                    AssistChip(onClick = { onOpenSection(AppTab.LOCAL_FLAVOR) }, label = { Text("Yöresel") })
                    AssistChip(onClick = { onOpenSection(AppTab.STAY) }, label = { Text("Konak") })
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SeaScreen(
    routePlan: RoutePlan?,
    activeRegion: String,
    manualItems: List<PlaceItem>,
    onRegionChanged: (String) -> Unit,
    onToggleManual: (PlaceItem) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var query by rememberSaveable { mutableStateOf(activeRegion) }
    var beaches by remember { mutableStateOf<List<PlaceItem>>(emptyList()) }
    var selectedPlace by remember { mutableStateOf<PlaceItem?>(null) }
    var conditions by remember { mutableStateOf<SeaConditions?>(null) }
    var loading by remember { mutableStateOf(false) }
    var conditionsLoading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var lastRequestedRegion by rememberSaveable { mutableStateOf("") }

    fun search(region: String) {
        if (region.isBlank()) {
            error = "Bir il, ilçe, koy veya sahil bölgesi yaz."
            return
        }
        lastRequestedRegion = region.trim()
        loading = true
        conditionsLoading = false
        error = null
        conditions = null
        scope.launch {
            runCatching {
                val center = ApiService.geocode(region)
                center
            }.onSuccess { center ->
                query = center.name
                lastRequestedRegion = center.name
                onRegionChanged(center.name)
                selectedPlace = null
                conditions = null
                // Yerleşik öneriler hemen görünür. Canlı yakın çevre sonuçları ve
                // tek bir bölgesel deniz isteği arkadan eklenir.
                beaches = ApiService.quickPlaces(center, PoiCategory.BEACH)
                loading = false

                scope.launch {
                    runCatching { ApiService.getSeaConditions(center.latitude, center.longitude) }
                        .onSuccess { current ->
                            conditions = current
                            beaches = ApiService.withSeaConditions(beaches, current)
                        }
                }
                scope.launch {
                    runCatching { ApiService.searchPlaces(center, PoiCategory.BEACH) }
                        .onSuccess { live ->
                            beaches = conditions?.let { ApiService.withSeaConditions(live, it) } ?: live
                        }
                }
            }.onFailure {
                error = it.userMessage()
                beaches = emptyList()
                selectedPlace = null
                conditions = null
                loading = false
            }
        }
    }

    LaunchedEffect(activeRegion) {
        if (activeRegion.isNotBlank() && activeRegion != lastRequestedRegion) {
            query = activeRegion
            search(activeRegion)
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            ScreenHeader(
                "Deniz Bul",
                "Konumuna bağlı kalmadan Türkiye’de istediğin bölgeyi yaz; plaj ve koy adlarını, ardından güncel deniz koşullarını getirir."
            )
        }
        item {
            RouteRegionSelector(routePlan, manualItems, activeRegion) { region ->
                query = region
                search(region)
            }
        }
        item {
            SearchBox(
                value = query,
                onValueChange = { query = it },
                label = "Herhangi bir bölge yaz: Çeşme, Datça, Kaş…",
                buttonText = "Plaj ve koyları bul",
                loading = loading,
                onSearch = { search(query.trim()) }
            )
        }
        error?.let { item { ErrorCard(it) } }
        conditions?.let { item { SeaConditionsCard(selectedPlace?.name ?: query, it) } }
        if (!loading && beaches.isEmpty() && error == null) {
            item { InfoCard("Bu bölgede uygulama içinde plaj veya koy sonucu bulunamadı. Başka şehirden yer gösterilmedi; yeniden deneyebilirsin.") }
        }
        if (beaches.isNotEmpty()) {
            item { InfoCard("Yerleşik öneriler ile seçilen merkezin yakınındaki canlı açık harita sonuçları birlikte gösterilir. Bölgesel rüzgâr ve dalga verisi tek istekte kartlara eklenir.") }
        }
        items(beaches, key = { it.routeKey() }) { beach ->
            PlaceCard(
                place = beach,
                selectedForRoute = manualItems.any { it.samePlace(beach) },
                actionText = if (!beach.isSearchCard) {
                    if (selectedPlace?.samePlace(beach) == true) "Koşullar gösteriliyor" else "Canlı koşulları göster"
                } else null,
                actionEnabled = !conditionsLoading,
                onAction = if (!beach.isSearchCard) {
                    {
                        conditionsLoading = true
                        selectedPlace = beach
                        scope.launch {
                            runCatching { ApiService.getSeaConditions(beach.latitude, beach.longitude) }
                                .onSuccess { current ->
                                    conditions = current
                                    beaches = ApiService.withSeaConditions(beaches, current)
                                }
                                .onFailure { error = "Canlı deniz verisi alınamadı. Plaj listesi çalışmaya devam ediyor." }
                            conditionsLoading = false
                        }
                    }
                } else null,
                onToggleRoute = { onToggleManual(beach) },
                onMap = { openPlaceOnMap(context, beach) }
            )
        }
        item {
            InfoCard("Bölge kilidi açıktır: Seçtiğin ilçe dışındaki plajlar gösterilmez. Özel beach club ve müşteri plajları listede yoktur. Zemin, erişim, sığlık ve metal dedektör uygunluğu bilinmiyorsa açıkça belirtilir.")
        }
        item { AttributionFooter() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FoodScreen(
    routePlan: RoutePlan?,
    activeRegion: String,
    manualItems: List<PlaceItem>,
    onRegionChanged: (String) -> Unit,
    onToggleManual: (PlaceItem) -> Unit,
    onOpenLocalFlavor: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var query by rememberSaveable("food-query") { mutableStateOf(activeRegion) }
    var selectedKind by rememberSaveable { mutableStateOf(FoodKind.ALL) }
    var featuredResults by remember { mutableStateOf<List<PlaceItem>>(emptyList()) }
    var alternativeResults by remember { mutableStateOf<List<PlaceItem>>(emptyList()) }
    var featuredNotice by remember { mutableStateOf("") }
    var showAlternatives by rememberSaveable { mutableStateOf(false) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var usingPhoneLocation by remember { mutableStateOf(false) }
    var searchJob by remember { mutableStateOf<Job?>(null) }
    var requestCounter by remember { mutableStateOf(0) }
    var lastRequestedRegion by rememberSaveable("food-last-region") { mutableStateOf("") }
    var resolvedCenter by remember { mutableStateOf<GeoPoint?>(null) }

    fun performSearch(
        kind: FoodKind,
        centerProvider: suspend () -> GeoPoint,
        phoneLocation: Boolean
    ) {
        val requestId = requestCounter + 1
        requestCounter = requestId
        searchJob?.cancel()
        loading = true
        error = null
        usingPhoneLocation = phoneLocation
        featuredResults = emptyList()
        alternativeResults = emptyList()
        featuredNotice = ""
        showAlternatives = false
        searchJob = scope.launch {
            try {
                val center = centerProvider()
                if (requestCounter != requestId) return@launch
                resolvedCenter = center
                query = center.name
                lastRequestedRegion = center.name
                onRegionChanged(center.name)

                val quick = ApiService.quickFoodSearch(center, kind)
                if (!quick.isEmpty) {
                    featuredResults = quick.featured
                    alternativeResults = quick.alternatives
                    featuredNotice = quick.featuredNotice
                }

                val found = ApiService.searchFoodSearch(center, kind)
                if (requestCounter != requestId) return@launch
                featuredResults = found.featured
                alternativeResults = found.alternatives
                featuredNotice = found.featuredNotice
                if (found.isEmpty) {
                    error = when (kind) {
                        FoodKind.PIDE -> "Bu merkezin 20 km çevresinde adı veya türü pide/lahmacun olarak işaretlenmiş yer bulunamadı. Başka yemek türü gösterilmedi."
                        FoodKind.KOFTE -> "Bu merkezin 20 km çevresinde köfteci olarak işaretlenmiş yer bulunamadı. Başka yemek türü gösterilmedi."
                        FoodKind.ESNAF -> "Bu merkezin 20 km çevresinde esnaf, aile lokantası veya yerel lokanta eşleşmesi bulunamadı."
                        FoodKind.KEBAB -> "Bu merkezin 20 km çevresinde kebapçı veya dönerci eşleşmesi bulunamadı."
                        FoodKind.SULU -> "Bu merkezin 20 km çevresinde sulu yemek veya ev yemekleri eşleşmesi bulunamadı."
                        FoodKind.ALL -> "Bu merkezin 20 km çevresinde uygun ekonomik yemek sonucu bulunamadı."
                    }
                }
            } catch (_: CancellationException) {
                // Yeni arama başladığında önceki istek iptal edilir.
            } catch (throwable: Throwable) {
                if (requestCounter == requestId) error = throwable.userMessage()
            } finally {
                if (requestCounter == requestId) loading = false
            }
        }
    }

    fun search(region: String, kind: FoodKind = selectedKind) {
        if (region.isBlank()) {
            error = "Bir il, ilçe veya bölge yaz."
            return
        }
        lastRequestedRegion = region.trim()
        performSearch(kind, centerProvider = { ApiService.geocode(region.trim()) }, phoneLocation = false)
    }

    fun searchFromPhoneLocation(kind: FoodKind = selectedKind) {
        performSearch(kind, centerProvider = { LocationHelper.currentPoint(context) }, phoneLocation = true)
    }

    val locationPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        val granted = grants[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            grants[Manifest.permission.ACCESS_COARSE_LOCATION] == true ||
            context.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (granted) searchFromPhoneLocation()
        else error = "En yakın yemek yerlerini göstermek için uygulamayı kullanırken konum izni ver."
    }

    fun requestPhoneLocationSearch() {
        if (LocationHelper.hasPermission(context)) {
            searchFromPhoneLocation()
        } else {
            locationPermissionLauncher.launch(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                )
            )
        }
    }

    fun chooseKind(kind: FoodKind) {
        selectedKind = kind
        error = null
        featuredResults = emptyList()
        alternativeResults = emptyList()
        featuredNotice = ""
        showAlternatives = false
        val center = resolvedCenter
        when {
            center != null -> performSearch(kind, centerProvider = { center }, phoneLocation = usingPhoneLocation)
            query.isNotBlank() -> search(query.trim(), kind)
        }
    }

    LaunchedEffect(activeRegion) {
        if (!usingPhoneLocation && activeRegion.isNotBlank() && activeRegion != lastRequestedRegion) {
            query = activeRegion
            search(activeRegion)
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            ScreenHeader(
                "Ekonomik Yemek",
                "Pide, köfte ve kebapta yalnız kuruluş yılı kaynakla doğrulanmış köklü/meşhur işletmeler üstte gösterilir. Popüler zincirler elenir; yakın yerler ayrı alternatif düğmesindedir."
            )
        }
        item {
            RouteRegionSelector(routePlan, manualItems, activeRegion) { region ->
                query = region
                search(region)
            }
        }
        item {
            ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("Yemek türünü seç", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = selectedKind == FoodKind.PIDE,
                            onClick = { chooseKind(FoodKind.PIDE) },
                            label = { Text("Pide") },
                            modifier = Modifier.weight(1f)
                        )
                        FilterChip(
                            selected = selectedKind == FoodKind.KOFTE,
                            onClick = { chooseKind(FoodKind.KOFTE) },
                            label = { Text("Köfte") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = selectedKind == FoodKind.ESNAF,
                            onClick = { chooseKind(FoodKind.ESNAF) },
                            label = { Text("Esnaf lokantası") },
                            modifier = Modifier.weight(1f)
                        )
                        FilterChip(
                            selected = selectedKind == FoodKind.KEBAB,
                            onClick = { chooseKind(FoodKind.KEBAB) },
                            label = { Text("Kebap / Döner") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = selectedKind == FoodKind.SULU,
                            onClick = { chooseKind(FoodKind.SULU) },
                            label = { Text("Sulu yemek") },
                            modifier = Modifier.weight(1f)
                        )
                        FilterChip(
                            selected = selectedKind == FoodKind.ALL,
                            onClick = { chooseKind(FoodKind.ALL) },
                            label = { Text("Tüm ekonomik") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
        item {
            SearchBox(
                value = query,
                onValueChange = {
                    query = it
                    usingPhoneLocation = false
                    resolvedCenter = null
                },
                label = "Şehir, ilçe, mahalle veya rota durağı",
                buttonText = selectedKind.buttonText,
                loading = loading,
                onSearch = { search(query.trim()) }
            )
        }
        item {
            OutlinedButton(
                onClick = ::requestPhoneLocationSearch,
                enabled = !loading,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Place, null)
                Spacer(Modifier.width(8.dp))
                Text("Konumuma göre en yakın ${selectedKind.title.lowercase()} yerlerini bul")
            }
        }
        item {
            OutlinedButton(onClick = onOpenLocalFlavor, modifier = Modifier.fillMaxWidth()) {
                Text("Yörenin meşhur lezzetini ayrıca araştır")
            }
        }
        if (usingPhoneLocation && (featuredResults.isNotEmpty() || alternativeResults.isNotEmpty())) {
            item { InfoCard("Sonuçlar telefonunun anlık konumuna göre sıralandı; öne çıkanlar üstte, diğer yakın yerler alternatiflerde gösterilir.") }
        }
        if (loading) {
            item { InfoCard("${selectedKind.title} için öne çıkan ve alternatif yerler aranıyor…") }
        }
        error?.let { item { ErrorCard(it) } }
        if (!loading && featuredResults.isEmpty() && alternativeResults.isEmpty() && error == null) {
            item { InfoCard("Yemek türünü seçip bölgeyi yaz veya konumuna göre ara.") }
        }
        if (featuredResults.isNotEmpty()) {
            item {
                Text(
                    if (selectedKind == FoodKind.ESNAF) "ÖNE ÇIKAN ESNAF LOKANTALARI" else "DOĞRULANMIŞ KÖKLÜ / MEŞHUR İŞLETMELER",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary
                )
            }
            item { InfoCard(featuredNotice) }
            items(featuredResults, key = { "featured:${it.routeKey()}" }) { place ->
                PlaceCard(
                    place = place,
                    selectedForRoute = manualItems.any { it.samePlace(place) },
                    actionText = null,
                    onAction = null,
                    onToggleRoute = { onToggleManual(place) },
                    onMap = { openPlaceOnMap(context, place) }
                )
            }
        }
        if (alternativeResults.isNotEmpty()) {
            item {
                OutlinedButton(
                    onClick = { showAlternatives = !showAlternatives },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        if (showAlternatives) "ALTERNATİFLERİ GİZLE" else "ALTERNATİFLERİ GÖSTER (${alternativeResults.size})"
                    )
                }
            }
            if (showAlternatives) {
                item {
                    Text(
                        "YAKIN ALTERNATİFLER",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                items(alternativeResults, key = { "alternative:${it.routeKey()}" }) { place ->
                    PlaceCard(
                        place = place,
                        selectedForRoute = manualItems.any { it.samePlace(place) },
                        actionText = null,
                        onAction = null,
                        onToggleRoute = { onToggleManual(place) },
                        onMap = { openPlaceOnMap(context, place) }
                    )
                }
            }
        }
        item {
            InfoCard("Pastane, kafe, unlu mamuller, tatlıcı, fırın, pizza, burger, lüks restoranlar ve yaygın zincirler elenir. Pide, köfte ve kebapta canlı popülerlik puanı ‘en eski/meşhur’ sayılmaz; üst kart için doğrulanmış kuruluş yılı gerekir.")
        }
        item { AttributionFooter() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DiscoveryScreen(
    routePlan: RoutePlan?,
    activeRegion: String,
    manualItems: List<PlaceItem>,
    onRegionChanged: (String) -> Unit,
    onToggleManual: (PlaceItem) -> Unit,
    onOpenLegend: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var query by rememberSaveable("discovery-query") { mutableStateOf(activeRegion) }
    var selectedKind by rememberSaveable { mutableStateOf(DiscoveryKind.ANCIENT) }
    var results by remember { mutableStateOf<List<PlaceItem>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var usingPhoneLocation by remember { mutableStateOf(false) }
    var searchJob by remember { mutableStateOf<Job?>(null) }
    var requestCounter by remember { mutableStateOf(0) }
    var lastRequestedRegion by rememberSaveable("discovery-last-region") { mutableStateOf("") }
    var resolvedCenter by remember { mutableStateOf<GeoPoint?>(null) }

    fun performSearch(
        kind: DiscoveryKind,
        centerProvider: suspend () -> GeoPoint,
        phoneLocation: Boolean
    ) {
        val requestId = requestCounter + 1
        requestCounter = requestId
        searchJob?.cancel()
        loading = true
        error = null
        usingPhoneLocation = phoneLocation
        results = emptyList()
        searchJob = scope.launch {
            try {
                val center = centerProvider()
                if (requestCounter != requestId) return@launch
                resolvedCenter = center
                query = center.name
                lastRequestedRegion = center.name
                onRegionChanged(center.name)

                val quick = ApiService.quickDiscoveryPlaces(center, kind)
                if (quick.isNotEmpty()) results = quick

                val found = ApiService.searchDiscoveryPlaces(center, kind)
                if (requestCounter != requestId) return@launch
                results = found
                if (found.isEmpty()) {
                    error = when (kind) {
                        DiscoveryKind.ANCIENT -> "Bu bölgenin 25 km çevresinde doğrulanabilir antik kent, ören yeri veya arkeolojik alan bulunamadı. Müze ve sıradan turistik yerlerle liste doldurulmadı."
                        DiscoveryKind.FORTRESS_CAVE -> "Bu bölgenin 25 km çevresinde kale, mağara, yeraltı yapısı veya benzeri tarihî nokta bulunamadı."
                        DiscoveryKind.LEGENDARY -> "Bu bölgenin 30 km çevresinde kaynaklı efsane, rivayet veya gizemli yer bağlantısı bulunamadı. Başka şehirden anlatı getirilmedi."
                    }
                }
            } catch (_: CancellationException) {
                // Yeni arama başladığında önceki istek iptal edilir.
            } catch (throwable: Throwable) {
                if (requestCounter == requestId) error = throwable.userMessage()
            } finally {
                if (requestCounter == requestId) loading = false
            }
        }
    }

    fun search(region: String, kind: DiscoveryKind = selectedKind) {
        if (region.isBlank()) {
            error = "Bir il, ilçe, köy veya rota durağı yaz."
            return
        }
        lastRequestedRegion = region.trim()
        performSearch(kind, centerProvider = { ApiService.geocode(region.trim()) }, phoneLocation = false)
    }

    fun searchFromPhoneLocation(kind: DiscoveryKind = selectedKind) {
        performSearch(kind, centerProvider = { LocationHelper.currentPoint(context) }, phoneLocation = true)
    }

    val locationPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        val granted = grants[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            grants[Manifest.permission.ACCESS_COARSE_LOCATION] == true ||
            context.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (granted) searchFromPhoneLocation()
        else error = "Yakındaki keşif noktalarını göstermek için uygulamayı kullanırken konum izni ver."
    }

    fun requestPhoneLocationSearch() {
        if (LocationHelper.hasPermission(context)) {
            searchFromPhoneLocation()
        } else {
            locationPermissionLauncher.launch(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                )
            )
        }
    }

    fun chooseKind(kind: DiscoveryKind) {
        selectedKind = kind
        error = null
        results = emptyList()
        val center = resolvedCenter
        when {
            center != null -> performSearch(kind, centerProvider = { center }, phoneLocation = usingPhoneLocation)
            query.isNotBlank() -> search(query.trim(), kind)
        }
    }

    LaunchedEffect(activeRegion) {
        if (!usingPhoneLocation && activeRegion.isNotBlank() && activeRegion != lastRequestedRegion) {
            query = activeRegion
            search(activeRegion)
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            ScreenHeader(
                "Tarih ve Gizem",
                "Antik alanlar, kale/mağara noktaları ve efsaneli yerler ayrı ayrı aranır. Bir kategori seçildiğinde diğerleri listeye karıştırılmaz."
            )
        }
        item {
            RouteRegionSelector(routePlan, manualItems, activeRegion) { region ->
                query = region
                search(region)
            }
        }
        item {
            ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("Keşif türünü seç", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    FilterChip(
                        selected = selectedKind == DiscoveryKind.ANCIENT,
                        onClick = { chooseKind(DiscoveryKind.ANCIENT) },
                        label = { Text("Antik / Ören Yeri") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    FilterChip(
                        selected = selectedKind == DiscoveryKind.FORTRESS_CAVE,
                        onClick = { chooseKind(DiscoveryKind.FORTRESS_CAVE) },
                        label = { Text("Kale / Mağara / Yeraltı") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    FilterChip(
                        selected = selectedKind == DiscoveryKind.LEGENDARY,
                        onClick = { chooseKind(DiscoveryKind.LEGENDARY) },
                        label = { Text("Gizemli / Efsaneli / Rivayetli") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
        item {
            SearchBox(
                value = query,
                onValueChange = {
                    query = it
                    usingPhoneLocation = false
                    resolvedCenter = null
                },
                label = "Şehir, ilçe, köy, mahalle veya rota durağı",
                buttonText = selectedKind.buttonText,
                loading = loading,
                onSearch = { search(query.trim()) }
            )
        }
        item {
            OutlinedButton(
                onClick = ::requestPhoneLocationSearch,
                enabled = !loading,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Place, null)
                Spacer(Modifier.width(8.dp))
                Text("Konumuma göre yakın ${selectedKind.title.lowercase()} sonuçlarını bul")
            }
        }
        if (selectedKind == DiscoveryKind.LEGENDARY) {
            item {
                OutlinedButton(onClick = onOpenLegend, modifier = Modifier.fillMaxWidth()) {
                    Text("Yerleşik Efsane İzleri arşivini aç")
                }
            }
        }
        if (usingPhoneLocation && results.isNotEmpty()) {
            item { InfoCard("Sonuçlar telefonunun konumuna göre en yakından uzağa sıralandı.") }
        }
        if (loading) {
            item { InfoCard("${selectedKind.title} sonuçları bölge sınırı içinde araştırılıyor…") }
        }
        error?.let { item { ErrorCard(it) } }
        if (!loading && results.isEmpty() && error == null) {
            item { InfoCard("Keşif türünü seçip bölgeyi yaz veya konumuna göre ara.") }
        }
        if (results.isNotEmpty()) {
            item {
                InfoCard(
                    when (selectedKind) {
                        DiscoveryKind.ANCIENT -> "Yalnız antik kent, ören yeri, arkeolojik alan, kalıntı, nekropol, tümülüs ve antik tapınak sonuçları gösterilir."
                        DiscoveryKind.FORTRESS_CAVE -> "Yalnız kale, hisar, sur kapısı, mağara, maden, batık ve benzeri somut noktalar gösterilir."
                        DiscoveryKind.LEGENDARY -> "Yalnız bölgeyle coğrafi bağı olan kaynaklı efsane, rivayet ve gizem bağlantıları gösterilir; turistik yerler rastgele eklenmez."
                    }
                )
            }
        }
        items(results, key = { it.routeKey() }) { place ->
            PlaceCard(
                place = place,
                selectedForRoute = manualItems.any { it.samePlace(place) },
                actionText = null,
                onAction = null,
                onToggleRoute = { onToggleManual(place) },
                onMap = { openPlaceOnMap(context, place) }
            )
        }
        item { AttributionFooter() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PlacesScreen(
    title: String,
    description: String,
    category: PoiCategory,
    routePlan: RoutePlan?,
    activeRegion: String,
    manualItems: List<PlaceItem>,
    onRegionChanged: (String) -> Unit,
    onToggleManual: (PlaceItem) -> Unit,
    extraButtonText: String? = null,
    onExtraButton: (() -> Unit)? = null
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var query by rememberSaveable(title) { mutableStateOf(activeRegion) }
    var results by remember { mutableStateOf<List<PlaceItem>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var usingPhoneLocation by remember { mutableStateOf(false) }
    var searchJob by remember { mutableStateOf<Job?>(null) }
    var requestCounter by remember { mutableStateOf(0) }
    var lastRequestedRegion by rememberSaveable(title) { mutableStateOf("") }

    fun performSearch(centerProvider: suspend () -> GeoPoint, phoneLocation: Boolean) {
        val requestId = requestCounter + 1
        requestCounter = requestId
        searchJob?.cancel()
        loading = true
        error = null
        usingPhoneLocation = phoneLocation
        searchJob = scope.launch {
            try {
                val center = centerProvider()
                if (requestCounter != requestId) return@launch
                query = center.name
                lastRequestedRegion = center.name
                onRegionChanged(center.name)
                // Kullanıcı boş ekranda beklemez: yerleşik somut sonuçlar hemen
                // görünür; canlı OpenStreetMap sonuçları uygulamanın içine eklenir.
                results = ApiService.quickPlaces(center, category)
                loading = false

                val found = ApiService.searchPlaces(center, category)
                if (requestCounter != requestId) return@launch
                results = found
            } catch (_: CancellationException) {
                // Yeni arama başladığında eski isteği sessizce bırak.
            } catch (throwable: Throwable) {
                if (requestCounter == requestId) {
                    error = throwable.userMessage()
                }
            } finally {
                if (requestCounter == requestId) loading = false
            }
        }
    }

    fun search(region: String) {
        if (region.isBlank()) {
            error = "Bir il, ilçe veya bölge yaz."
            return
        }
        lastRequestedRegion = region.trim()
        performSearch(centerProvider = { ApiService.geocode(region.trim()) }, phoneLocation = false)
    }

    fun searchFromPhoneLocation() {
        performSearch(centerProvider = { LocationHelper.currentPoint(context) }, phoneLocation = true)
    }

    val locationPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        val granted = grants[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            grants[Manifest.permission.ACCESS_COARSE_LOCATION] == true ||
            context.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (granted) searchFromPhoneLocation()
        else error = "En yakın yerleri göstermek için uygulamayı kullanırken konum izni ver."
    }

    fun requestPhoneLocationSearch() {
        if (LocationHelper.hasPermission(context)) {
            searchFromPhoneLocation()
        } else {
            locationPermissionLauncher.launch(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                )
            )
        }
    }

    LaunchedEffect(activeRegion, category) {
        if (!usingPhoneLocation && activeRegion.isNotBlank() && activeRegion != lastRequestedRegion) {
            query = activeRegion
            search(activeRegion)
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { ScreenHeader(title, description) }
        item {
            RouteRegionSelector(routePlan, manualItems, activeRegion) { region ->
                query = region
                search(region)
            }
        }
        if (extraButtonText != null && onExtraButton != null) {
            item {
                Button(
                    onClick = onExtraButton,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(extraButtonText)
                }
            }
        }
        item {
            SearchBox(
                value = query,
                onValueChange = {
                    query = it
                    usingPhoneLocation = false
                },
                label = "Herhangi bir şehir, ilçe veya bölge yaz",
                buttonText = when (category) {
                    PoiCategory.FOOD -> "Ekonomik yemek yerlerini bul"
                    PoiCategory.MYSTERY -> "Tarihî ve gizemli yerleri bul"
                    PoiCategory.STAY -> "Konaklama seçeneklerini bul"
                    PoiCategory.BEACH -> "Ara"
                    PoiCategory.WAYPOINT -> "Rotaya ekle"
                },
                loading = loading,
                onSearch = { search(query.trim()) }
            )
        }
        if (category == PoiCategory.FOOD || category == PoiCategory.STAY || category == PoiCategory.MYSTERY) {
            item {
                OutlinedButton(
                    onClick = ::requestPhoneLocationSearch,
                    enabled = !loading,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Place, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Konumuma göre en yakınları bul")
                }
            }
        }
        if (usingPhoneLocation && results.isNotEmpty()) {
            item {
                InfoCard("Sonuçlar telefonunun anlık konumuna olan uzaklığa göre sıralandı. Bölge: $query")
            }
        }
        if (loading) {
            item { InfoCard("Bölge bulunuyor… Bilinen bölgeler anında, diğer yerler en fazla birkaç saniyede açılır.") }
        }
        error?.let { item { ErrorCard(it) } }
        if (!loading && results.isEmpty() && error == null) {
            item { InfoCard("Bu bölgede uygulama içinde uygun sonuç bulunamadı. Başka şehirden sonuç gösterilmedi; birkaç saniye sonra yeniden deneyebilirsin.") }
        }
        items(results, key = { it.routeKey() }) { place ->
            PlaceCard(
                place = place,
                selectedForRoute = manualItems.any { it.samePlace(place) },
                actionText = null,
                onAction = null,
                onToggleRoute = { onToggleManual(place) },
                onMap = { openPlaceOnMap(context, place) }
            )
        }
        if (category == PoiCategory.FOOD || category == PoiCategory.STAY) {
            item {
                InfoCard("Karttaki fiyatlar 2026 için yaklaşık ekonomik banttır; kesin fiyat değildir. İşletme adı, türü ve yaklaşık uzaklık uygulamanın içinde gösterilir.")
            }
        }
        if (category == PoiCategory.FOOD) {
            item {
                InfoCard("Sadece ekonomik aile lokantası, esnaf lokantası, ev yemekleri, kebapçı, pideci ve lahmacuncular aranır. Pastane, kafe, unlu mamuller, tatlıcı, fırın ve pahalı turistik restoranlar gösterilmez.")
            }
        }
        item { AttributionFooter() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SpecialResearchScreen(
    title: String,
    description: String,
    routePlan: RoutePlan?,
    activeRegion: String,
    manualItems: List<PlaceItem>,
    onRegionChanged: (String) -> Unit,
    onToggleManual: (PlaceItem) -> Unit,
    mode: SpecialResearchMode,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var query by rememberSaveable(title) { mutableStateOf(activeRegion) }
    var results by remember { mutableStateOf<List<PlaceItem>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var searchJob by remember { mutableStateOf<Job?>(null) }
    var lastRequestedRegion by rememberSaveable(title) { mutableStateOf("") }

    fun search(region: String) {
        if (region.isBlank()) {
            error = "Bir il, ilçe, köy veya rota durağı yaz."
            return
        }
        searchJob?.cancel()
        loading = true
        error = null
        lastRequestedRegion = region.trim()
        searchJob = scope.launch {
            try {
                val center = ApiService.geocode(region.trim())
                query = center.name
                lastRequestedRegion = center.name
                onRegionChanged(center.name)

                val local = when (mode) {
                    SpecialResearchMode.LEGEND -> SpecialCatalog.legendResults(center)
                    SpecialResearchMode.LOCAL_FLAVOR -> SpecialCatalog.localFlavorResults(center)
                }
                results = local
                loading = local.isEmpty()

                val live: List<PlaceItem> = coroutineScope {
                    val articleJob = async<List<PlaceItem>> {
                        runCatching<List<PlaceItem>> {
                            when (mode) {
                                SpecialResearchMode.LEGEND -> ApiService.searchLegendArticles(center)
                                SpecialResearchMode.LOCAL_FLAVOR -> ApiService.searchLocalFlavorArticles(center)
                            }
                        }.getOrElse { emptyList() }
                    }
                    // Yöresel lezzet ekranına genel restoran listesi karıştırılmaz.
                    // Ekonomik pide, köfte, kebap, esnaf ve sulu yemek alternatifleri
                    // Yemek ekranındaki ayrı butonlardan aranır.
                    articleJob.await()
                }

                results = (local + live)
                    .distinctBy { "${it.category}:${it.name.lowercase()}" }
                    .sortedWith(compareBy<PlaceItem> { it.priority }.thenBy { it.name })
                if (results.isEmpty()) {
                    error = "Bu bölge için uygulama içinde doğrulanabilir sonuç bulunamadı. Başka şehirden içerik gösterilmedi."
                }
            } catch (_: CancellationException) {
                // Yeni arama başladığında önceki arama sessizce bırakılır.
            } catch (throwable: Throwable) {
                error = throwable.userMessage()
                // Yerleşik sonuçlar geldiyse ekranda kalır; yalnız hata mesajı güncellenir.
            } finally {
                loading = false
            }
        }
    }

    LaunchedEffect(activeRegion, mode) {
        if (activeRegion.isNotBlank() && activeRegion != lastRequestedRegion) {
            query = activeRegion
            search(activeRegion)
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { ScreenHeader(title, description) }
        item {
            OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) {
                Text(if (mode == SpecialResearchMode.LEGEND) "Gizem bölümüne dön" else "Yemek bölümüne dön")
            }
        }
        item {
            RouteRegionSelector(routePlan, manualItems, activeRegion) { region ->
                query = region
                search(region)
            }
        }
        item {
            SearchBox(
                value = query,
                onValueChange = { query = it },
                label = "Gideceğin il, ilçe, köy veya rota durağı",
                buttonText = if (mode == SpecialResearchMode.LEGEND) {
                    "Efsane ve rivayetleri araştır"
                } else {
                    "Yörenin meşhur lezzetini bul"
                },
                loading = loading,
                onSearch = { search(query.trim()) }
            )
        }
        if (loading) {
            item { InfoCard("Bölge doğrulanıyor… Sonuçlar başka şehirden doldurulmadan yalnız seçtiğin rota durağına göre hazırlanıyor.") }
        }
        error?.let { item { ErrorCard(it) } }
        if (!loading && results.isEmpty() && error == null) {
            item {
                InfoCard(
                    if (mode == SpecialResearchMode.LEGEND) {
                        "Bir bölge seç. Yerleşik anlatılar ve canlı Türkçe kaynak özetleri doğrudan uygulamanın içinde gösterilir."
                    } else {
                        "Bir bölge seç. Yalnız o bölgenin imza lezzeti, köklü/meşhur işletme adayı ve yemekle doğrudan ilgili kaynak özeti gösterilir. Genel restoranlar bu listeye karıştırılmaz."
                    }
                )
            }
        }
        items(results, key = { it.routeKey() }) { place ->
            PlaceCard(
                place = place,
                selectedForRoute = manualItems.any { it.samePlace(place) },
                actionText = null,
                onAction = null,
                onToggleRoute = { onToggleManual(place) },
                onMap = { openPlaceOnMap(context, place) }
            )
        }
        item {
            InfoCard(
                if (mode == SpecialResearchMode.LEGEND) {
                    "Bilinen tarih, yerel sözlü anlatı ve modern internet söylentisi ayrı gösterilir. Kaynağı doğrulanmayan anlatı tarihî gerçek gibi sunulmaz."
                } else {
                    "Bu ekran yalnız yöresel lezzeti ve doğrulanabilir köklü/meşhur işletme adayını gösterir. Ekonomik alternatifler için Yemek ekranındaki Pide, Köfte, Esnaf Lokantası, Kebap/Döner ve Sulu Yemek butonlarını kullan."
                }
            )
        }
        item { AttributionFooter() }
    }
}

@Composable
private fun ScreenHeader(title: String, subtitle: String) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(title, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text(
            "Sürüm ${BuildConfig.VERSION_NAME}",
            color = MaterialTheme.colorScheme.secondary,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold
        )
        Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant, lineHeight = 22.sp)
    }
}

@Composable
private fun SearchBox(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    buttonText: String,
    loading: Boolean,
    onSearch: () -> Unit
) {
    ElevatedCard {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(
                value = value,
                onValueChange = onValueChange,
                modifier = Modifier.fillMaxWidth(),
                label = { Text(label) },
                singleLine = true,
                trailingIcon = {
                    if (value.isNotBlank()) {
                        IconButton(onClick = onSearch) { Icon(Icons.Default.Refresh, "Ara") }
                    }
                }
            )
            Button(onClick = onSearch, enabled = !loading, modifier = Modifier.fillMaxWidth()) {
                if (loading) {
                    CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(10.dp))
                    Text("Araştırılıyor…")
                } else {
                    Icon(Icons.Default.Place, null)
                    Spacer(Modifier.width(8.dp))
                    Text(buttonText)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RouteRegionSelector(
    routePlan: RoutePlan?,
    manualItems: List<PlaceItem>,
    activeRegion: String,
    onSelect: (String) -> Unit
) {
    val routeRegions = routePlan?.stops.orEmpty().map { it.name }
    val manualRegions = manualItems
        .filter { it.category == PoiCategory.WAYPOINT }
        .map { it.name }
    val regions = (routeRegions + manualRegions).distinct()
    ElevatedCard(
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Rotadan seç veya aşağıya istediğin yeri yaz", fontWeight = FontWeight.Bold)
            if (regions.isEmpty()) {
                Text("Rota oluşturmadıysan sorun değil; arama kutusuna Türkiye’de istediğin bölgeyi yazabilirsin.", fontSize = 13.sp)
            } else {
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    regions.forEach { region ->
                        FilterChip(
                            selected = activeRegion == region,
                            onClick = { onSelect(region) },
                            label = { Text(region, maxLines = 1) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PlaceCard(
    place: PlaceItem,
    selectedForRoute: Boolean,
    actionText: String?,
    actionEnabled: Boolean = true,
    onAction: (() -> Unit)?,
    onToggleRoute: () -> Unit,
    onMap: () -> Unit
) {
    val context = LocalContext.current
    ElevatedCard {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(place.name, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text(place.subtitle, color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.Medium)
            place.note?.let {
                Text(it, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
            }
            place.details.forEach { detail ->
                Text("• $detail", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
            }
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Araştırma Google'a bırakılmaz. Harita düğmesi yalnız uygulama
                // içinde adı ve ayrıntısı bulunan somut bir yer için gösterilir.
                if (!place.isSearchCard) {
                    OutlinedButton(onClick = onMap) {
                        Icon(Icons.Default.Map, null, Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Konumu aç")
                    }
                    OutlinedButton(onClick = onToggleRoute) {
                        Icon(if (selectedForRoute) Icons.Default.Delete else Icons.Default.AddRoad, null, Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(if (selectedForRoute) "Rotadan çıkar" else "Rotama ekle")
                    }
                    if (place.webSearchQuery?.startsWith("https://") == true) {
                        OutlinedButton(onClick = { openSourceUrl(context, place.webSearchQuery) }) {
                            Text("Kaynağı aç")
                        }
                    }
                }
                if (actionText != null && onAction != null) {
                    TextButton(onClick = onAction, enabled = actionEnabled) { Text(actionText) }
                }
            }
        }
    }
}

@Composable
private fun SeaConditionsCard(placeName: String, conditions: SeaConditions) {
    ElevatedCard(
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(placeName, fontSize = 21.sp, fontWeight = FontWeight.Bold)
            Text("Güncel koşullar", color = MaterialTheme.colorScheme.secondary)
            Text("Hava: ${conditions.weatherText}")
            Text("Sıcaklık: ${conditions.airTemperature.format("°C")} • Hissedilen: ${conditions.apparentTemperature.format("°C")}")
            Text("Rüzgâr: ${conditions.windSpeed.format(" km/sa")} • Hamle: ${conditions.windGust.format(" km/sa")}")
            Text("Dalga: ${conditions.waveHeight.format(" m")} (${waveLabel(conditions.waveHeight)})")
            Text("Dalga yönü: ${conditions.waveDirection.format("°")} • Periyot: ${conditions.wavePeriod.format(" sn")}")
            Text("Deniz sıcaklığı: ${conditions.seaTemperature.format("°C")}")
        }
    }
}

@Composable
private fun ErrorCard(message: String) {
    ElevatedCard(
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.error.copy(alpha = 0.14f)
        )
    ) {
        Text(message, Modifier.padding(16.dp), color = MaterialTheme.colorScheme.error)
    }
}

@Composable
private fun InfoCard(message: String) {
    ElevatedCard(
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Text(message, Modifier.padding(16.dp), fontSize = 14.sp)
    }
}

@Composable
private fun AttributionFooter() {
    Text(
        "V20 kesin bölge kilidi: Yöresel lezzete genel restoran karıştırılmaz; antik alan, kale/mağara ve efsaneli yerler ayrı veri kümeleriyle aranır.",
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        fontSize = 12.sp,
        modifier = Modifier.padding(vertical = 8.dp)
    )
}

private fun openSourceUrl(context: Context, url: String?) {
    if (url.isNullOrBlank() || !url.startsWith("https://")) return
    runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
}

private fun openPlaceOnMap(context: Context, place: PlaceItem) {
    val search = place.mapSearchQuery
    if (search.isNullOrBlank()) {
        openMap(context, place.latitude, place.longitude, place.name)
        return
    }
    val encoded = Uri.encode(search)
    val geoUri = Uri.parse("geo:${place.latitude},${place.longitude}?q=$encoded")
    val osmFallback = Uri.parse("https://www.openstreetmap.org/search?query=$encoded")
    runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, geoUri)) }
        .onFailure { context.startActivity(Intent(Intent.ACTION_VIEW, osmFallback)) }
}

private fun openMap(context: Context, latitude: Double, longitude: Double, label: String) {
    val encodedLabel = Uri.encode(label)
    val geoUri = Uri.parse("geo:$latitude,$longitude?q=$latitude,$longitude($encodedLabel)")
    val geoIntent = Intent(Intent.ACTION_VIEW, geoUri)
    val osmFallback = Intent(
        Intent.ACTION_VIEW,
        Uri.parse("https://www.openstreetmap.org/?mlat=$latitude&mlon=$longitude#map=16/$latitude/$longitude")
    )
    runCatching { context.startActivity(geoIntent) }
        .onFailure { context.startActivity(osmFallback) }
}

private fun openDirections(context: Context, places: List<PlaceItem>) {
    if (places.isEmpty()) return
    if (places.size == 1) {
        val item = places.first()
        openMap(context, item.latitude, item.longitude, item.name)
        return
    }
    val origin = places.first()
    val destination = places.last()
    val route = Uri.encode("${origin.latitude},${origin.longitude};${destination.latitude},${destination.longitude}")
    val url = Uri.parse(
        "https://www.openstreetmap.org/directions?engine=fossgis_osrm_car&route=$route"
    )
    context.startActivity(Intent(Intent.ACTION_VIEW, url))
}

private fun categoryLabel(category: PoiCategory): String = when (category) {
    PoiCategory.WAYPOINT -> "Rota durağı"
    PoiCategory.BEACH -> "Deniz"
    PoiCategory.FOOD -> "Yemek"
    PoiCategory.MYSTERY -> "Tarih ve gizem"
    PoiCategory.STAY -> "Konaklama"
}

private fun PlaceItem.samePlace(other: PlaceItem): Boolean =
    category == other.category &&
        name.equals(other.name, ignoreCase = true) &&
        kotlin.math.abs(latitude - other.latitude) < 0.0001 &&
        kotlin.math.abs(longitude - other.longitude) < 0.0001

private fun PlaceItem.routeKey(): String = "$category-$name-$latitude-$longitude"

private fun <T> List<T>.swap(first: Int, second: Int): List<T> {
    if (first !in indices || second !in indices) return this
    return toMutableList().also { list ->
        val temporary = list[first]
        list[first] = list[second]
        list[second] = temporary
    }
}
