package com.altayaytin.denizgizemrotamsifir

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddRoad
import androidx.compose.material.icons.filled.AltRoute
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.BeachAccess
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Directions
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Hotel
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.Route
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            DenizGizemTheme {
                DenizGizemApp()
            }
        }
    }
}

private val AppColors: ColorScheme = darkColorScheme(
    primary = Color(0xFF8ED6F1),
    onPrimary = Color(0xFF06202A),
    secondary = Color(0xFFE7C97D),
    background = Color(0xFF15171B),
    surface = Color(0xFF20252A),
    surfaceVariant = Color(0xFF293138),
    onBackground = Color(0xFFF1F2F4),
    onSurface = Color(0xFFF1F2F4),
    onSurfaceVariant = Color(0xFFD6DCE1),
    error = Color(0xFFFFB4AB)
)

@Composable
private fun DenizGizemTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = AppColors, content = content)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DenizGizemApp() {
    val context = LocalContext.current
    var selectedTab by rememberSaveable { mutableStateOf(AppTab.ROUTE) }
    var routePlan by remember { mutableStateOf(RouteStore.load(context)) }
    var activeRegion by rememberSaveable {
        mutableStateOf(routePlan?.stops?.lastOrNull()?.name.orEmpty())
    }
    var manualItems by remember { mutableStateOf(ManualRouteStore.load(context)) }

    fun setManualItems(items: List<PlaceItem>) {
        manualItems = items
        ManualRouteStore.save(context, items)
    }

    fun toggleManual(place: PlaceItem) {
        val exists = manualItems.any { it.samePlace(place) }
        setManualItems(
            if (exists) manualItems.filterNot { it.samePlace(place) }
            else manualItems + place
        )
    }

    Scaffold(
        bottomBar = {
            NavigationBar {
                AppTab.values().forEach { tab ->
                    NavigationBarItem(
                        selected = selectedTab == tab,
                        onClick = { selectedTab = tab },
                        icon = { Icon(tab.icon, contentDescription = tab.label) },
                        label = {
                            Text(
                                text = tab.label,
                                fontSize = 11.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Clip
                            )
                        },
                        alwaysShowLabel = true
                    )
                }
            }
        }
    ) { innerPadding ->
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            color = MaterialTheme.colorScheme.background
        ) {
            when (selectedTab) {
                AppTab.ROUTE -> RouteScreen(
                    currentPlan = routePlan,
                    manualItems = manualItems,
                    onManualItemsChanged = ::setManualItems,
                    onToggleManual = ::toggleManual,
                    onPlanCreated = { plan ->
                        routePlan = plan
                        activeRegion = plan.stops.lastOrNull()?.name.orEmpty()
                        RouteStore.save(context, plan)
                    },
                    onOpenSection = { tab, region ->
                        activeRegion = region
                        selectedTab = tab
                    }
                )

                AppTab.SEA -> SeaScreen(
                    routePlan = routePlan,
                    activeRegion = activeRegion,
                    manualItems = manualItems,
                    onRegionChanged = { activeRegion = it },
                    onToggleManual = ::toggleManual
                )

                AppTab.FOOD -> PlacesScreen(
                    title = "Ekonomik Yemek",
                    description = "Sadece esnaf lokantası, ev yemekleri, pide, lahmacun, kebap, döner ve köfte türleri gösterilir. Pastane, kafe, unlu mamuller, tatlıcı, burger ve pizza sonuçları tamamen elenir.",
                    category = PoiCategory.FOOD,
                    routePlan = routePlan,
                    activeRegion = activeRegion,
                    manualItems = manualItems,
                    onRegionChanged = { activeRegion = it },
                    onToggleManual = ::toggleManual
                )

                AppTab.MYSTERY -> PlacesScreen(
                    title = "Tarih ve Gizem",
                    description = "Yazdığın herhangi bir bölgedeki antik kent, ören yeri, kale, mağara, müze ve tarihî noktaları araştırır.",
                    category = PoiCategory.MYSTERY,
                    routePlan = routePlan,
                    activeRegion = activeRegion,
                    manualItems = manualItems,
                    onRegionChanged = { activeRegion = it },
                    onToggleManual = ::toggleManual
                )

                AppTab.STAY -> PlacesScreen(
                    title = "Konaklama",
                    description = "Konumuna bağlı kalmadan yazdığın bölgede kamp, karavan alanı, pansiyon, hostel, apart, motel ve otelleri listeler.",
                    category = PoiCategory.STAY,
                    routePlan = routePlan,
                    activeRegion = activeRegion,
                    manualItems = manualItems,
                    onRegionChanged = { activeRegion = it },
                    onToggleManual = ::toggleManual
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RouteScreen(
    currentPlan: RoutePlan?,
    manualItems: List<PlaceItem>,
    onManualItemsChanged: (List<PlaceItem>) -> Unit,
    onToggleManual: (PlaceItem) -> Unit,
    onPlanCreated: (RoutePlan) -> Unit,
    onOpenSection: (AppTab, String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var manualMode by rememberSaveable { mutableStateOf(false) }
    var start by rememberSaveable { mutableStateOf(currentPlan?.startName.orEmpty()) }
    var end by rememberSaveable { mutableStateOf(currentPlan?.endName.orEmpty()) }
    var viaText by rememberSaveable { mutableStateOf("") }
    var daysText by rememberSaveable { mutableStateOf(currentPlan?.days?.toString() ?: "10") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var plan by remember { mutableStateOf(currentPlan) }
    var manualQuery by rememberSaveable { mutableStateOf("") }
    var manualLoading by remember { mutableStateOf(false) }
    var manualError by remember { mutableStateOf<String?>(null) }

    fun addManualWaypoint() {
        if (manualQuery.isBlank()) {
            manualError = "Rotaya eklemek istediğin şehir, ilçe, plaj veya gezilecek yeri yaz."
            return
        }
        manualLoading = true
        manualError = null
        scope.launch {
            runCatching { ApiService.geocode(manualQuery.trim()) }
                .onSuccess { point ->
                    val item = PlaceItem(
                        name = point.name,
                        subtitle = "Elle eklenen rota durağı",
                        latitude = point.latitude,
                        longitude = point.longitude,
                        category = PoiCategory.WAYPOINT,
                        priority = 0,
                        note = "İlk seçilen yer başlangıç, son seçilen yer bitiş kabul edilir."
                    )
                    if (manualItems.none { it.samePlace(item) }) {
                        onManualItemsChanged(manualItems + item)
                    }
                    manualQuery = ""
                }
                .onFailure { manualError = it.userMessage() }
            manualLoading = false
        }
    }

    fun createCustom(variant: Int = 0) {
        val days = daysText.toIntOrNull()?.coerceIn(2, 14)
        if (start.isBlank() || end.isBlank() || days == null) {
            error = "Başlangıç, bitiş ve 2–14 arasında gün sayısı gir."
            return
        }
        val viaStops = viaText
            .split(',', ';', '\n', '>', '→')
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .distinct()
            .take(10)

        loading = true
        error = null
        scope.launch {
            runCatching {
                ApiService.createSmartRoute(
                    startQuery = start.trim(),
                    endQuery = end.trim(),
                    days = days,
                    variant = variant,
                    viaQueries = viaStops
                )
            }
                .onSuccess {
                    plan = it
                    onPlanCreated(it)
                }
                .onFailure { error = it.userMessage() }
            loading = false
        }
    }

    fun createCoastal(variant: Int = 0) {
        loading = true
        error = null
        daysText = "10"
        scope.launch {
            runCatching { ApiService.createAegeanMediterraneanTour(10, variant) }
                .onSuccess {
                    plan = it
                    start = it.startName
                    end = it.endName
                    onPlanCreated(it)
                }
                .onFailure { error = it.userMessage() }
            loading = false
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            ScreenHeader(
                title = "Rotam",
                subtitle = "Hazır gezi planı oluşturabilir veya bulduğun yerleri seçip kendi rotanı kurabilirsin."
            )
        }

        item {
            ElevatedCard(
                colors = CardDefaults.elevatedCardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("Rota türünü seç", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    if (!manualMode) {
                        Button(onClick = { manualMode = false }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.AltRoute, null)
                            Spacer(Modifier.width(8.dp))
                            Text("BANA ROTA HAZIRLA (AÇIK)")
                        }
                        OutlinedButton(onClick = { manualMode = true }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.AddRoad, null)
                            Spacer(Modifier.width(8.dp))
                            Text("KENDİ ROTAMI OLUŞTUR (${manualItems.size})")
                        }
                    } else {
                        OutlinedButton(onClick = { manualMode = false }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.AltRoute, null)
                            Spacer(Modifier.width(8.dp))
                            Text("BANA ROTA HAZIRLA")
                        }
                        Button(onClick = { manualMode = true }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.AddRoad, null)
                            Spacer(Modifier.width(8.dp))
                            Text("KENDİ ROTAMI OLUŞTUR (${manualItems.size})")
                        }
                    }
                }
            }
        }

        if (manualMode) {
            item {
                ManualRouteIntro()
            }
            item {
                ElevatedCard {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text("İstediğin durağı kendin ekle", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text(
                            "Başlangıcı önce, bitişi en son ekle. Araya istediğin kadar şehir, koy, plaj veya gezilecek yer koyabilirsin.",
                            fontSize = 13.sp
                        )
                        OutlinedTextField(
                            value = manualQuery,
                            onValueChange = { manualQuery = it },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("Örnek: Bursa, Efes, Didim, Kaş") },
                            singleLine = true
                        )
                        Button(
                            onClick = { addManualWaypoint() },
                            enabled = !manualLoading,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            if (manualLoading) {
                                CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                                Spacer(Modifier.width(8.dp))
                                Text("Yer bulunuyor…")
                            } else {
                                Icon(Icons.Default.AddRoad, null)
                                Spacer(Modifier.width(8.dp))
                                Text("Rotanın sonuna ekle")
                            }
                        }
                    }
                }
            }
            manualError?.let { item { ErrorCard(it) } }
            if (manualItems.isEmpty()) {
                item {
                    InfoCard("Yukarıdaki kutudan durak ekle veya Deniz, Yemek, Gizem ve Konaklama bölümlerindeki “Rotama ekle” düğmesini kullan.")
                }
            } else {
                item {
                    ElevatedCard(
                        colors = CardDefaults.elevatedCardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant
                        )
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text("Seçtiğin rota", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                            Text(
                                "Yerler aşağıdaki sırayla haritaya aktarılır. En fazla ilk 10 durak açılır.",
                                fontSize = 13.sp
                            )
                            Button(
                                onClick = { openDirections(context, manualItems) },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Default.Directions, null)
                                Spacer(Modifier.width(8.dp))
                                Text("Rotayı haritada çiz")
                            }
                            OutlinedButton(
                                onClick = { onManualItemsChanged(emptyList()) },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Default.Delete, null)
                                Spacer(Modifier.width(8.dp))
                                Text("Tüm seçilenleri temizle")
                            }
                        }
                    }
                }

                items(manualItems, key = { it.routeKey() }) { place ->
                    val index = manualItems.indexOfFirst { it.samePlace(place) }
                    ManualPlaceCard(
                        place = place,
                        index = index,
                        total = manualItems.size,
                        onMap = { openMap(context, place.latitude, place.longitude, place.name) },
                        onMoveUp = {
                            if (index > 0) onManualItemsChanged(manualItems.swap(index, index - 1))
                        },
                        onMoveDown = {
                            if (index < manualItems.lastIndex) onManualItemsChanged(manualItems.swap(index, index + 1))
                        },
                        onDelete = { onToggleManual(place) }
                    )
                }
            }
        } else {
            item {
                ElevatedCard {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text("Güzergâhını yaz", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                        Text(
                            "Başlangıç ve bitişi yaz. Geçmek istediğin yerleri de virgülle ekleyebilirsin.",
                            fontSize = 13.sp
                        )
                        OutlinedTextField(
                            value = start,
                            onValueChange = { start = it },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("Başlangıç yeri • Örnek: Bursa") },
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = viaText,
                            onValueChange = { viaText = it },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("Güzergâh / ara duraklar (isteğe bağlı)") },
                            placeholder = { Text("İzmir, Efes, Didim, Bodrum, Fethiye, Kaş") },
                            minLines = 2,
                            maxLines = 4
                        )
                        OutlinedTextField(
                            value = end,
                            onValueChange = { end = it },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("Bitiş yeri • Örnek: Antalya") },
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = daysText,
                            onValueChange = { daysText = it.filter(Char::isDigit).take(2) },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("Kaç gün? (2–14)") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Number,
                                imeAction = ImeAction.Done
                            )
                        )
                        Button(
                            onClick = { createCustom(0) },
                            enabled = !loading,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            if (loading) {
                                CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                                Spacer(Modifier.width(10.dp))
                                Text("Rota hazırlanıyor…")
                            } else {
                                Icon(Icons.Default.AltRoute, null)
                                Spacer(Modifier.width(8.dp))
                                Text("ROTAYI ŞİMDİ HAZIRLA")
                            }
                        }
                        Text(
                            "Rota önce hızlıca hazırlanır. Plaj, yemek, gizem ve konaklama ayrıntılarını her günün altındaki düğmelerden ayrıca açabilirsin.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            item {
                ElevatedCard(
                    colors = CardDefaults.elevatedCardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text("Ege’den Akdeniz’e hazır sahil turu", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                        Text(
                            "Başlangıç ve bitiş yazmadan hazır 10 günlük sahil güzergâhı oluşturur. Ayrıntıları gün kartlarından açarsın.",
                            fontSize = 14.sp
                        )
                        Button(
                            onClick = { createCoastal(0) },
                            enabled = !loading,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.Route, null)
                            Spacer(Modifier.width(8.dp))
                            Text("10 günlük Ege–Akdeniz turu oluştur")
                        }
                    }
                }
            }

            error?.let { item { ErrorCard(it) } }

            plan?.let { route ->
                item {
                    RouteSummaryCard(route)
                }
                item {
                    Button(
                        onClick = {
                            openDirections(
                                context,
                                route.stops.map { stop ->
                                    PlaceItem(
                                        name = stop.name,
                                        subtitle = "${stop.day}. gün durağı",
                                        latitude = stop.latitude,
                                        longitude = stop.longitude,
                                        category = PoiCategory.WAYPOINT
                                    )
                                }
                            )
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Directions, null)
                        Spacer(Modifier.width(8.dp))
                        Text("Tüm rotayı haritada çiz")
                    }
                }
                item {
                    OutlinedButton(
                        onClick = {
                            if (route.kind == RouteKind.AEGEAN_MEDITERRANEAN) {
                                createCoastal(route.variant + 1)
                            } else {
                                start = route.startName
                                end = route.endName
                                daysText = route.days.toString()
                                createCustom(route.variant + 1)
                            }
                        },
                        enabled = !loading,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Refresh, null)
                        Spacer(Modifier.width(8.dp))
                        Text("Alternatif rota ve yerler getir")
                    }
                }

                items(route.stops, key = { "${it.day}-${it.name}" }) { stop ->
                    RouteDayCard(
                        stop = stop,
                        manualItems = manualItems,
                        onToggleManual = onToggleManual,
                        onOpenSection = onOpenSection,
                        onMap = { lat, lon, label -> openMap(context, lat, lon, label) }
                    )
                }
            }
        }

        item { AttributionFooter() }
    }
}

@Composable
private fun ManualRouteIntro() {
    ElevatedCard(
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("KENDİ ROTAMI OLUŞTUR", fontWeight = FontWeight.Bold, fontSize = 22.sp)
            Text("Durakları doğrudan yazarak ekle veya diğer bölümlerde bulduğun yerleri seç. Sıralamayı değiştirip tamamını haritada rota olarak aç.")
        }
    }
}

@Composable
private fun RouteSummaryCard(route: RoutePlan) {
    ElevatedCard(
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("${route.startName} → ${route.endName}", fontWeight = FontWeight.Bold, fontSize = 20.sp)
            Text("${route.days} gün • yaklaşık ${route.distanceKm} km • ${route.durationHours} saat sürüş")
            Text(
                "Güzergâh hazır. Her günün altındaki Deniz, Yemek, Keşif ve Konak düğmeleri o bölgenin ayrıntılarını ayrı ve daha hızlı araştırır.",
                fontSize = 13.sp
            )
        }
    }
}

@Composable
private fun RouteDayCard(
    stop: RouteStop,
    manualItems: List<PlaceItem>,
    onToggleManual: (PlaceItem) -> Unit,
    onOpenSection: (AppTab, String) -> Unit,
    onMap: (Double, Double, String) -> Unit
) {
    ElevatedCard {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("${stop.day}. Gün", color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.Bold)
            Text(stop.name, fontSize = 22.sp, fontWeight = FontWeight.Bold)

            stop.beach?.let {
                RoutePlaceRow("Deniz", Icons.Default.BeachAccess, it, manualItems.any { saved -> saved.samePlace(it) }, onToggleManual, onMap)
            } ?: MissingRouteItem("Plaj ve koylar için aşağıdaki “Daha fazla deniz” düğmesine bas.")
            stop.food?.let {
                RoutePlaceRow("Yemek", Icons.Default.Restaurant, it, manualItems.any { saved -> saved.samePlace(it) }, onToggleManual, onMap)
            } ?: MissingRouteItem("Ekonomik yemek için “Daha fazla yemek” düğmesine bas.")
            stop.mystery?.let {
                RoutePlaceRow("Keşif", Icons.Default.Explore, it, manualItems.any { saved -> saved.samePlace(it) }, onToggleManual, onMap)
            } ?: MissingRouteItem("Tarihî ve gizemli yerler için “Daha fazla keşif” düğmesine bas.")
            stop.stay?.let {
                RoutePlaceRow("Konak", Icons.Default.Hotel, it, manualItems.any { saved -> saved.samePlace(it) }, onToggleManual, onMap)
            } ?: MissingRouteItem("Konaklama için “Daha fazla konak” düğmesine bas.")

            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AssistChip(onClick = { onOpenSection(AppTab.SEA, stop.name) }, label = { Text("Daha fazla deniz") })
                AssistChip(onClick = { onOpenSection(AppTab.FOOD, stop.name) }, label = { Text("Daha fazla yemek") })
                AssistChip(onClick = { onOpenSection(AppTab.MYSTERY, stop.name) }, label = { Text("Daha fazla keşif") })
                AssistChip(onClick = { onOpenSection(AppTab.STAY, stop.name) }, label = { Text("Daha fazla konak") })
            }
        }
    }
}

@Composable
private fun RoutePlaceRow(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    place: PlaceItem,
    selected: Boolean,
    onToggleManual: (PlaceItem) -> Unit,
    onMap: (Double, Double, String) -> Unit
) {
    ElevatedCard(
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(icon, null, Modifier.size(20.dp))
                Text(label, color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.Bold)
            }
            Text(place.name, fontWeight = FontWeight.Bold)
            Text(place.subtitle, fontSize = 13.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = { onMap(place.latitude, place.longitude, place.name) }) {
                    Text("Harita")
                }
                TextButton(onClick = { onToggleManual(place) }) {
                    Text(if (selected) "Rotadan çıkar" else "Rotama ekle")
                }
            }
        }
    }
}

@Composable
private fun MissingRouteItem(text: String) {
    Text(text, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
}

@Composable
private fun ManualPlaceCard(
    place: PlaceItem,
    index: Int,
    total: Int,
    onMap: () -> Unit,
    onMoveUp: () -> Unit,
    onMoveDown: () -> Unit,
    onDelete: () -> Unit
) {
    ElevatedCard {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text("${index + 1}. ${place.name}", fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Text("${categoryLabel(place.category)} • ${place.subtitle}", color = MaterialTheme.colorScheme.secondary)
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                TextButton(onClick = onMap) { Text("Harita") }
                IconButton(onClick = onMoveUp, enabled = index > 0) {
                    Icon(Icons.Default.ArrowUpward, "Yukarı taşı")
                }
                IconButton(onClick = onMoveDown, enabled = index < total - 1) {
                    Icon(Icons.Default.ArrowDownward, "Aşağı taşı")
                }
                IconButton(onClick = onDelete) {
                    Icon(Icons.Default.Delete, "Rotadan çıkar")
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SeaScreen(
    routePlan: RoutePlan?,
    activeRegion: String,
    manualItems: List<PlaceItem>,
    onRegionChanged: (String) -> Unit,
    onToggleManual: (PlaceItem) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var query by rememberSaveable { mutableStateOf(activeRegion) }
    var beaches by remember { mutableStateOf<List<PlaceItem>>(emptyList()) }
    var selectedPlace by remember { mutableStateOf<PlaceItem?>(null) }
    var conditions by remember { mutableStateOf<SeaConditions?>(null) }
    var loading by remember { mutableStateOf(false) }
    var conditionsLoading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(activeRegion) {
        if (activeRegion.isNotBlank() && activeRegion != query) query = activeRegion
    }

    fun search(region: String) {
        if (region.isBlank()) {
            error = "Bir il, ilçe, koy veya sahil bölgesi yaz."
            return
        }
        loading = true
        conditionsLoading = false
        error = null
        conditions = null
        scope.launch {
            runCatching {
                val center = ApiService.geocode(region)
                center to ApiService.searchPlaces(center, PoiCategory.BEACH)
            }.onSuccess { result ->
                val center = result.first
                val found = result.second
                val target = found.firstOrNull()
                    ?: PlaceItem(center.name, "Bölge merkezi", center.latitude, center.longitude, PoiCategory.BEACH)

                beaches = found
                selectedPlace = target
                query = center.name
                onRegionChanged(center.name)
                loading = false

                conditionsLoading = true
                scope.launch {
                    runCatching { ApiService.getSeaConditions(target.latitude, target.longitude) }
                        .onSuccess { conditions = it }
                        .onFailure { error = "Plajlar geldi; canlı deniz verisi alınamadı: ${it.userMessage()}" }
                    conditionsLoading = false
                }
            }.onFailure {
                error = it.userMessage()
                beaches = emptyList()
                selectedPlace = null
                conditions = null
                loading = false
            }
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            ScreenHeader(
                "Deniz Bul",
                "Konumuna bağlı kalmadan Türkiye’de istediğin bölgeyi yaz; plaj ve koy adlarını, ardından güncel deniz koşullarını getirir."
            )
        }
        item {
            RouteRegionSelector(routePlan, activeRegion) { region ->
                query = region
                search(region)
            }
        }
        item {
            SearchBox(
                value = query,
                onValueChange = { query = it },
                label = "Herhangi bir bölge yaz: Çeşme, Datça, Kaş…",
                buttonText = "Plaj ve koyları bul",
                loading = loading,
                onSearch = { search(query.trim()) }
            )
        }
        error?.let { item { ErrorCard(it) } }
        conditions?.let { item { SeaConditionsCard(selectedPlace?.name ?: query, it) } }
        if (!loading && beaches.isEmpty() && error == null) {
            item { InfoCard("Bir bölge yazıp aradığında gerçek plaj ve koy adları burada görünür.") }
        }
        items(beaches, key = { it.routeKey() }) { beach ->
            PlaceCard(
                place = beach,
                selectedForRoute = manualItems.any { it.samePlace(beach) },
                actionText = if (selectedPlace?.samePlace(beach) == true) "Koşullar gösteriliyor" else "Canlı koşulları göster",
                actionEnabled = !conditionsLoading,
                onAction = {
                    conditionsLoading = true
                    selectedPlace = beach
                    scope.launch {
                        runCatching { ApiService.getSeaConditions(beach.latitude, beach.longitude) }
                            .onSuccess { conditions = it }
                            .onFailure { error = it.userMessage() }
                        conditionsLoading = false
                    }
                },
                onToggleRoute = { onToggleManual(beach) },
                onMap = { openMap(context, beach.latitude, beach.longitude, beach.name) }
            )
        }
        item {
            InfoCard("Özel beach club, ücretli ve müşteriye özel olarak işaretlenmiş yerler elenir. Her kartta zemin, ücret/erişim, sığlık verisi ve metal dedektör hobine uygunluk açıkça gösterilir. Eksik bilgi uydurulmaz.")
        }
        item { AttributionFooter() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PlacesScreen(
    title: String,
    description: String,
    category: PoiCategory,
    routePlan: RoutePlan?,
    activeRegion: String,
    manualItems: List<PlaceItem>,
    onRegionChanged: (String) -> Unit,
    onToggleManual: (PlaceItem) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var query by rememberSaveable(title) { mutableStateOf(activeRegion) }
    var results by remember { mutableStateOf<List<PlaceItem>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(activeRegion) {
        if (activeRegion.isNotBlank() && activeRegion != query) query = activeRegion
    }

    fun search(region: String) {
        if (region.isBlank()) {
            error = "Bir il, ilçe veya bölge yaz."
            return
        }
        loading = true
        error = null
        scope.launch {
            runCatching {
                val center = ApiService.geocode(region)
                center to ApiService.searchPlaces(center, category)
            }.onSuccess { result ->
                val center = result.first
                val found = result.second
                query = center.name
                onRegionChanged(center.name)
                results = found
                if (found.isEmpty()) error = when (category) {
                    PoiCategory.FOOD -> "Bu bölgede yalnızca istediğin ekonomik yemek türleriyle eşleşen sonuç bulunamadı. Yakındaki ilçe adını dene."
                    PoiCategory.BEACH -> "Ücretsiz/doğal plaj adayı bulunamadı. Yakındaki sahil ilçesini dene."
                    else -> "Bu bölgede adlandırılmış sonuç bulunamadı. Yakındaki ilçe adını dene."
                }
            }.onFailure {
                results = emptyList()
                error = it.userMessage()
            }
            loading = false
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { ScreenHeader(title, description) }
        item {
            RouteRegionSelector(routePlan, activeRegion) { region ->
                query = region
                search(region)
            }
        }
        item {
            SearchBox(
                value = query,
                onValueChange = { query = it },
                label = "Herhangi bir şehir, ilçe veya bölge yaz",
                buttonText = when (category) {
                    PoiCategory.FOOD -> "Ekonomik yemek yerlerini bul"
                    PoiCategory.MYSTERY -> "Tarihî ve gizemli yerleri bul"
                    PoiCategory.STAY -> "Konaklama seçeneklerini bul"
                    PoiCategory.BEACH -> "Ara"
                    PoiCategory.WAYPOINT -> "Rotaya ekle"
                },
                loading = loading,
                onSearch = { search(query.trim()) }
            )
        }
        error?.let { item { ErrorCard(it) } }
        if (!loading && results.isEmpty() && error == null) {
            item { InfoCard("Bölge yazıp arama yaptığında gerçek yer adları burada görünür.") }
        }
        items(results, key = { it.routeKey() }) { place ->
            PlaceCard(
                place = place,
                selectedForRoute = manualItems.any { it.samePlace(place) },
                actionText = null,
                onAction = null,
                onToggleRoute = { onToggleManual(place) },
                onMap = { openMap(context, place.latitude, place.longitude, place.name) }
            )
        }
        if (category == PoiCategory.FOOD) {
            item {
                InfoCard("Pastane, kafe, unlu mamuller, tatlıcı, fırın, burger, pizza ve genel turistik restoranlar gösterilmez. Yalnızca esnaf lokantası, ev yemekleri, pide, lahmacun, kebap, döner, köfte ve benzeri ekonomik yemek adayları listelenir. Güncel fiyat uydurulmaz.")
            }
        }
        item { AttributionFooter() }
    }
}

@Composable
private fun ScreenHeader(title: String, subtitle: String) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(title, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text(
            "Sürüm ${BuildConfig.VERSION_NAME}",
            color = MaterialTheme.colorScheme.secondary,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold
        )
        Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant, lineHeight = 22.sp)
    }
}

@Composable
private fun SearchBox(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    buttonText: String,
    loading: Boolean,
    onSearch: () -> Unit
) {
    ElevatedCard {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(
                value = value,
                onValueChange = onValueChange,
                modifier = Modifier.fillMaxWidth(),
                label = { Text(label) },
                singleLine = true,
                trailingIcon = {
                    if (value.isNotBlank()) {
                        IconButton(onClick = onSearch) { Icon(Icons.Default.Refresh, "Ara") }
                    }
                }
            )
            Button(onClick = onSearch, enabled = !loading, modifier = Modifier.fillMaxWidth()) {
                if (loading) {
                    CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(10.dp))
                    Text("Araştırılıyor…")
                } else {
                    Icon(Icons.Default.Place, null)
                    Spacer(Modifier.width(8.dp))
                    Text(buttonText)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RouteRegionSelector(
    routePlan: RoutePlan?,
    activeRegion: String,
    onSelect: (String) -> Unit
) {
    val stops = routePlan?.stops.orEmpty()
    ElevatedCard(
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Rotadan seç veya aşağıya istediğin yeri yaz", fontWeight = FontWeight.Bold)
            if (stops.isEmpty()) {
                Text("Rota oluşturmadıysan sorun değil; arama kutusuna Türkiye’de istediğin bölgeyi yazabilirsin.", fontSize = 13.sp)
            } else {
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    stops.distinctBy { it.name }.forEach { stop ->
                        FilterChip(
                            selected = activeRegion == stop.name,
                            onClick = { onSelect(stop.name) },
                            label = { Text(stop.name, maxLines = 1) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PlaceCard(
    place: PlaceItem,
    selectedForRoute: Boolean,
    actionText: String?,
    actionEnabled: Boolean = true,
    onAction: (() -> Unit)?,
    onToggleRoute: () -> Unit,
    onMap: () -> Unit
) {
    ElevatedCard {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(place.name, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text(place.subtitle, color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.Medium)
            place.note?.let {
                Text(it, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
            }
            place.details.forEach { detail ->
                Text("• $detail", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
            }
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(onClick = onMap) {
                    Icon(Icons.Default.Map, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Haritada aç")
                }
                OutlinedButton(onClick = onToggleRoute) {
                    Icon(if (selectedForRoute) Icons.Default.Delete else Icons.Default.AddRoad, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(if (selectedForRoute) "Rotadan çıkar" else "Rotama ekle")
                }
                if (actionText != null && onAction != null) {
                    TextButton(onClick = onAction, enabled = actionEnabled) { Text(actionText) }
                }
            }
        }
    }
}

@Composable
private fun SeaConditionsCard(placeName: String, conditions: SeaConditions) {
    ElevatedCard(
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(placeName, fontSize = 21.sp, fontWeight = FontWeight.Bold)
            Text("Güncel koşullar", color = MaterialTheme.colorScheme.secondary)
            Text("Hava: ${conditions.weatherText}")
            Text("Sıcaklık: ${conditions.airTemperature.format("°C")} • Hissedilen: ${conditions.apparentTemperature.format("°C")}")
            Text("Rüzgâr: ${conditions.windSpeed.format(" km/sa")} • Hamle: ${conditions.windGust.format(" km/sa")}")
            Text("Dalga: ${conditions.waveHeight.format(" m")} (${waveLabel(conditions.waveHeight)})")
            Text("Dalga yönü: ${conditions.waveDirection.format("°")} • Periyot: ${conditions.wavePeriod.format(" sn")}")
            Text("Deniz sıcaklığı: ${conditions.seaTemperature.format("°C")}")
        }
    }
}

@Composable
private fun ErrorCard(message: String) {
    ElevatedCard(
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.error.copy(alpha = 0.14f)
        )
    ) {
        Text(message, Modifier.padding(16.dp), color = MaterialTheme.colorScheme.error)
    }
}

@Composable
private fun InfoCard(message: String) {
    ElevatedCard(
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Text(message, Modifier.padding(16.dp), fontSize = 14.sp)
    }
}

@Composable
private fun AttributionFooter() {
    Text(
        "Veriler: OpenStreetMap katkıcıları, Open-Meteo ve OSRM. Açık veri kapsamına göre bazı bölgelerde sonuç sayısı değişebilir.",
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        fontSize = 12.sp,
        modifier = Modifier.padding(vertical = 8.dp)
    )
}

private fun openMap(context: Context, latitude: Double, longitude: Double, label: String) {
    val encodedLabel = Uri.encode(label)
    val geoUri = Uri.parse("geo:$latitude,$longitude?q=$latitude,$longitude($encodedLabel)")
    val geoIntent = Intent(Intent.ACTION_VIEW, geoUri)
    val fallback = Intent(
        Intent.ACTION_VIEW,
        Uri.parse("https://www.google.com/maps/search/?api=1&query=$latitude,$longitude")
    )
    runCatching { context.startActivity(geoIntent) }
        .onFailure { context.startActivity(fallback) }
}

private fun openDirections(context: Context, places: List<PlaceItem>) {
    if (places.isEmpty()) return
    if (places.size == 1) {
        val item = places.first()
        openMap(context, item.latitude, item.longitude, item.name)
        return
    }
    val limited = places.take(10)
    val origin = "${limited.first().latitude},${limited.first().longitude}"
    val destination = "${limited.last().latitude},${limited.last().longitude}"
    val middle = limited.drop(1).dropLast(1)
        .joinToString("|") { "${it.latitude},${it.longitude}" }
    val url = buildString {
        append("https://www.google.com/maps/dir/?api=1")
        append("&origin=${Uri.encode(origin)}")
        append("&destination=${Uri.encode(destination)}")
        if (middle.isNotBlank()) append("&waypoints=${Uri.encode(middle)}")
        append("&travelmode=driving")
    }
    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
}

private fun categoryLabel(category: PoiCategory): String = when (category) {
    PoiCategory.WAYPOINT -> "Rota durağı"
    PoiCategory.BEACH -> "Deniz"
    PoiCategory.FOOD -> "Yemek"
    PoiCategory.MYSTERY -> "Tarih ve gizem"
    PoiCategory.STAY -> "Konaklama"
}

private fun PlaceItem.samePlace(other: PlaceItem): Boolean =
    category == other.category &&
        name.equals(other.name, ignoreCase = true) &&
        kotlin.math.abs(latitude - other.latitude) < 0.0001 &&
        kotlin.math.abs(longitude - other.longitude) < 0.0001

private fun PlaceItem.routeKey(): String = "$category-$name-$latitude-$longitude"

private fun <T> List<T>.swap(first: Int, second: Int): List<T> {
    if (first !in indices || second !in indices) return this
    return toMutableList().also { list ->
        val temporary = list[first]
        list[first] = list[second]
        list[second] = temporary
    }
}
