package com.altayaytin.denizgizemrotamsifir

import java.util.Locale
import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * V20 özel araştırma katmanı.
 *
 * Bilinen bölgesel başlıkları hemen gösterir. Canlı Türkçe kaynak özetleri ve
 * ekonomik işletme sonuçları ApiService tarafından uygulamanın içinde eklenir.
 */
internal object SpecialCatalog {
    private val tr = Locale("tr", "TR")

    private data class LegendEntry(
        val regionKeys: Set<String>,
        val name: String,
        val storyType: String,
        val summary: String,
        val sourceStatus: String,
        val mapQuery: String,
        val webQuery: String
    )

    private data class FlavorProfile(
        val regionKeys: Set<String>,
        val dish: String,
        val reason: String,
        val mapQuery: String,
        val webQuery: String,
        val candidateName: String? = null,
        val candidateQuery: String? = null
    )

    /**
     * Yalnız kuruluş yılı ve köklülük kaynağı önceden doğrulanmış işletmeler.
     * Canlı harita sonuçları bu listeye kendiliğinden giremez; böylece popüler
     * zincirler "en eski / en meşhur" diye öne çıkarılmaz.
     */
    private data class VerifiedFoodVenue(
        val province: String,
        val localities: Set<String>,
        val kinds: Set<FoodKind>,
        val name: String,
        val foundedYear: Int,
        val specialty: String,
        val latitude: Double,
        val longitude: Double,
        val address: String,
        val sourceLabel: String,
        val sourceUrl: String,
        val mapQuery: String
    )

    private data class MatchedVerifiedVenue(
        val venue: VerifiedFoodVenue,
        val distanceKm: Double,
        val localityMatch: Boolean,
        val provinceWideMatch: Boolean
    )

    private data class GuideVenue(
        val regionKeys: Set<String>,
        val name: String,
        val cuisine: String,
        val whatToEat: String,
        val sourceLabel: String,
        val economicNote: String,
        val mapQuery: String,
        val webQuery: String
    )

    private val legends = listOf(
        LegendEntry(
            setOf("ayvalik", "balikesir"),
            "Şeytan Sofrası ve ayak izi rivayeti",
            "Yerel efsane",
            "Ayvalık'ın güneyindeki tepede bulunan doğal oluşum, halk arasında Şeytan'ın ayak izi olarak anlatılır; ziyaretçilerin para bıraktığı ve dilek dilediği rivayet geleneğiyle ilişkilidir.",
            "Kültür Portalı ve yerel anlatı kaynakları; efsane tarihî olay gibi sunulmaz.",
            "Şeytan Sofrası Ayvalık",
            "Şeytan Sofrası Ayvalık efsanesi Kültür Portalı"
        ),
        LegendEntry(
            setOf("tarsus", "mersin"),
            "Şahmeran anlatısı",
            "Yerel efsane",
            "Tarsus çevresinde yüzyıllardır anlatılan yarı insan yarı yılan bilge varlık hikâyesi.",
            "Sözlü gelenek ve ikincil kaynaklar; tarihî olay olarak sunulmaz.",
            "Şahmeran Tarsus",
            "Tarsus Şahmeran efsanesi yerel kaynaklar"
        ),
        LegendEntry(
            setOf("tarsus", "mersin"),
            "Eshab-ı Kehf / Yedi Uyurlar rivayeti",
            "Dinî ve tarihî rivayet",
            "Uzun süre mağarada uyuyan gençlere ilişkin anlatının Tarsus çevresindeki yerel varyantı.",
            "Farklı şehirler aynı anlatıyla ilişkilendirilir; yerel iddia kaynaklardan karşılaştırılmalıdır.",
            "Eshab-ı Kehf Tarsus",
            "Eshab-ı Kehf Tarsus rivayeti kaynak"
        ),
        LegendEntry(
            setOf("kizkalesi", "mersin", "erdemli"),
            "Kızkalesi ve yılanlı prenses efsanesi",
            "Yerel efsane",
            "Kehanetten kaçınmak için adaya kapatılan prenses ve sepette gelen yılan anlatısı.",
            "Yerel efsane; kale tarihinden ayrı değerlendirilmelidir.",
            "Kızkalesi Mersin",
            "Kızkalesi yılanlı prenses efsanesi kaynak"
        ),
        LegendEntry(
            setOf("efes", "selcuk", "izmir"),
            "Efes Yedi Uyurlar anlatısı",
            "Dinî ve tarihî rivayet",
            "Mağarada uzun süre uyuyan gençlere bağlanan Efes varyantı.",
            "Dinî gelenek ve yerel rivayet; farklı coğrafyalarda başka yerlerle de ilişkilendirilir.",
            "Yedi Uyurlar Mağarası Efes",
            "Efes Yedi Uyurlar rivayeti kaynak"
        ),
        LegendEntry(
            setOf("bodrum"),
            "Salmakis ve Hermaphroditos anlatısı",
            "Antik mitolojik anlatı",
            "Halikarnassos çevresiyle ilişkilendirilen Salmakis pınarı ve dönüşüm miti.",
            "Antik edebî anlatı; modern yerel söylentilerden ayrı tutulmalıdır.",
            "Salmakis Bodrum",
            "Salmakis Hermaphroditos Halikarnassos antik kaynak"
        ),
        LegendEntry(
            setOf("kiyikislacik", "iasos", "milas"),
            "İasoslu çocuk ve yunus anlatısı",
            "Antik anlatı",
            "İasos ile ilişkilendirilen çocuk ve yunus dostluğu hikâyesinin antik aktarımları.",
            "Antik yazarların aktardığı anlatı olarak araştırılmalı; modern süslemelerden ayrılmalıdır.",
            "İasos Antik Kenti Kıyıkışlacık",
            "İasos çocuk yunus Hermias antik anlatı kaynak"
        ),
        LegendEntry(
            setOf("didim", "didyma"),
            "Didyma kehanet anlatıları",
            "Antik din ve mitoloji",
            "Apollon kutsal alanındaki kehanet geleneği çevresinde oluşan tarihî ve mitolojik anlatılar.",
            "Arkeolojik bilgi, antik metin ve modern söylenti ayrı başlıklarla karşılaştırılmalıdır.",
            "Didyma Apollon Tapınağı",
            "Didyma Apollon kehanetleri antik kaynak"
        ),
        LegendEntry(
            setOf("dalyan", "kaunos", "ortaca", "koycegiz"),
            "Kaunos ve Byblis anlatısı",
            "Antik kuruluş efsanesi",
            "Dalyan karşısındaki Kaunos kentinin kuruluşu, Kaunos ile ikiz kardeşi Byblis arasında geçen trajik mitolojik anlatıyla ilişkilendirilir.",
            "Muğla İl Kültür ve Turizm Müdürlüğü anlatımı ve antik edebî aktarım; tarihî olay gibi sunulmaz.",
            "Kaunos Antik Kenti Dalyan",
            "Kaunos Byblis efsanesi Muğla Kültür Turizm"
        ),
        LegendEntry(
            setOf("oludeniz", "belcekiz", "fethiye"),
            "Belcekız ve Ölüdeniz anlatısı",
            "Yerel kıyı efsanesi",
            "Korunaklı koya sığınmak isteyen denizci oğul ile ona inanmayan babası çevresinde anlatılan trajik hikâye, Belcekız ve Ölüdeniz adlarıyla ilişkilendirilir.",
            "Yerel turizm anlatısı ve sözlü rivayet; kesin tarihî olay olarak sunulmaz.",
            "Belcekız Plajı Ölüdeniz",
            "Ölüdeniz Belcekız efsanesi"
        ),
        LegendEntry(
            setOf("fethiye", "kayakoy"),
            "Kayaköy hakkında modern paranormal söylentiler",
            "Modern söylenti",
            "Terk edilmiş yerleşim görünümü çevresinde oluşan hayaletli veya uğursuz yer anlatıları.",
            "Modern internet ve ziyaretçi söylentileri; tarihî nüfus mübadelesi gerçeğiyle karıştırılmamalıdır.",
            "Kayaköy Fethiye",
            "Kayaköy hayalet söylentileri yerel anlatı tarih"
        ),
        LegendEntry(
            setOf("kas", "kekova", "demre"),
            "Kekova batık kent anlatıları",
            "Yerel söylenti ve tarihî anlatı",
            "Su altındaki kalıntılar çevresinde oluşan kayıp şehir ve afet hikâyeleri.",
            "Arkeolojik veriler ile yerel söylentiler ayrı kaynaklardan kontrol edilmelidir.",
            "Kekova Batık Şehir",
            "Kekova batık şehir efsaneleri arkeolojik kaynak"
        )
    )

    private val flavors = listOf(
        FlavorProfile(
            setOf("inegol"),
            "İnegöl köftesi",
            "İnegöl’ün imza yemeği olarak bilinen köfte geleneği.",
            "uygun fiyatlı İnegöl köftesi İnegöl",
            "İnegöl köftesi tarihi en eski köfteci kuruluş yılı",
            candidateName = "Besler Köftecisi — köklü/meşhur aday",
            candidateQuery = "Besler Köftecisi İnegöl kuruluş yılı tarihçe"
        ),
        FlavorProfile(
            setOf("bursa"),
            "İskender kebap, pideli köfte ve cantık",
            "Bursa mutfağının en çok aranan sıcak yemekleri.",
            "uygun fiyatlı Bursa pideli köfte cantık esnaf lokantası",
            "Bursa en eski meşhur pideli köfte cantık lokantası tarihçe"
        ),
        FlavorProfile(
            setOf("balikesir", "erdek"),
            "Balıkesir köftesi ve yerel esnaf yemekleri",
            "Bölgenin köfte ve ev yemeği geleneğini ekonomik lokantalarda araştırır.",
            "uygun fiyatlı Balıkesir köftesi esnaf lokantası",
            "Balıkesir en eski meşhur köfteci yöresel yemek"
        ),
        FlavorProfile(
            setOf("ayvalik"),
            "Ayvalık tostu ve yerel Ege yemekleri",
            "Ayvalık’ın bilinen sokak lezzeti ile zeytinyağlı yerel yemekleri.",
            "uygun fiyatlı Ayvalık tostu esnaf lokantası",
            "Ayvalık en eski meşhur tostçu yerel lokanta"
        ),
        FlavorProfile(
            setOf("izmir", "cesme", "alacati", "foca", "seferihisar", "sigacik"),
            "Boyoz, kumru, söğüş ve Ege otları",
            "İzmir çevresinin öne çıkan yöresel lezzetleri.",
            "uygun fiyatlı yöresel İzmir kumru söğüş esnaf lokantası",
            "İzmir en eski meşhur kumrucu söğüşçü boyozcu tarihçe"
        ),
        FlavorProfile(
            setOf("aydin", "kusadasi", "didim"),
            "Aydın pidesi ve Çine köftesi",
            "Aydın ilinin pide ve köfte geleneği; turistik zincir yerine yerel işletme aranır.",
            "uygun fiyatlı Aydın pidesi Çine köftesi esnaf lokantası",
            "Aydın en eski meşhur pideci Çine köfteci"
        ),
        FlavorProfile(
            setOf("milas", "kiyikislacik", "iasos"),
            "Milas köftesi ve Çökertme kebabı",
            "Milas ve çevresinde aranabilecek yerel sıcak yemekler.",
            "uygun fiyatlı Milas köftesi Çökertme kebabı Kıyıkışlacık",
            "Milas en eski meşhur köfteci Çökertme kebabı lokantası"
        ),
        FlavorProfile(
            setOf("bodrum"),
            "Çökertme kebabı ve Bodrum usulü yerel yemekler",
            "Pahalı sahil restoranları yerine merkez ve mahallelerdeki ekonomik yerel lokantalar aranır.",
            "uygun fiyatlı Çökertme kebabı Bodrum esnaf lokantası",
            "Bodrum en eski meşhur yerel lokanta Çökertme kebabı"
        ),
        FlavorProfile(
            setOf("mugla", "marmaris", "datca", "akyaka", "fethiye", "dalyan"),
            "Muğla köftesi, Çökertme kebabı ve yerel ev yemekleri",
            "Muğla çevresinin sıcak yemeklerini ekonomik aile işletmelerinde araştırır.",
            "uygun fiyatlı Muğla köftesi Çökertme kebabı esnaf lokantası",
            "Muğla en eski meşhur yöresel lokanta"
        ),
        FlavorProfile(
            setOf("antalya", "kas", "kalkan", "side"),
            "Antalya tahinli piyazı ve şiş köfte",
            "Antalya mutfağının öne çıkan piyaz-köfte ikilisi; doğrulanmış köklü işletme önce, yakın ekonomik alternatifler sonra gösterilir.",
            "uygun fiyatlı Antalya piyazı şiş köfte esnaf lokantası",
            "Antalya en eski meşhur piyazcı şiş köfteci",
            candidateName = "Piyazcı Sami — 1933",
            candidateQuery = "Piyazcı Sami Antalya 1933 tarihçe"
        ),
        FlavorProfile(
            setOf("mersin", "tarsus"),
            "Tantuni, Tarsus humusu ve kebap",
            "Mersin–Tarsus hattının bilinen sıcak yemekleri.",
            "uygun fiyatlı tantuni Tarsus humusu kebap esnaf lokantası",
            "Mersin Tarsus en eski meşhur tantunici humusçu"
        ),
        FlavorProfile(
            setOf("adana"),
            "Adana kebabı ve ciğer",
            "Şehrin imza lezzetlerini ekonomik ocakbaşı ve kebapçılarda araştırır.",
            "uygun fiyatlı Adana kebabı ciğer esnaf kebapçı",
            "Adana en eski meşhur kebapçı kuruluş yılı"
        ),
        FlavorProfile(
            setOf("hatay", "antakya"),
            "Tepsi kebabı ve Antakya ev yemekleri",
            "Hatay mutfağının sıcak yemeklerini aile ve esnaf işletmelerinde araştırır.",
            "uygun fiyatlı Hatay tepsi kebabı Antakya esnaf lokantası",
            "Antakya en eski meşhur tepsi kebabı lokantası"
        ),
        FlavorProfile(
            setOf("gaziantep", "antep"),
            "Beyran, kebap ve yuvalama",
            "Gaziantep’in öne çıkan sıcak yemeklerini yerel ve ekonomik işletmelerde araştırır.",
            "uygun fiyatlı Gaziantep beyran kebap esnaf lokantası",
            "Gaziantep en eski meşhur beyrancı kebapçı"
        )
    )

    private val verifiedFoodVenues = listOf(
        VerifiedFoodVenue(
            province = "Antalya",
            localities = setOf("antalya", "muratpasa"),
            kinds = setOf(FoodKind.KOFTE),
            name = "Piyazcı Sami — 1933",
            foundedYear = 1933,
            specialty = "Antalya tahinli piyazı, şiş/ızgara köfte ve kabak tatlısı",
            latitude = 36.8870,
            longitude = 30.7040,
            address = "Elmalı Mahallesi, 25. Sokak No:5, Muratpaşa / Antalya",
            sourceLabel = "100 Tarihi Lokanta ve yerel tarihçe kaydı",
            sourceUrl = "https://www.100tarihilokanta.com/piyazci-sami/",
            mapQuery = "Piyazcı Sami Antalya"
        ),
        VerifiedFoodVenue(
            province = "Bursa",
            localities = setOf("bursa", "inegol"),
            kinds = setOf(FoodKind.KOFTE),
            name = "Besler İnegöl Köftecisi — 1893",
            foundedYear = 1893,
            specialty = "İnegöl köftesi",
            latitude = 40.0781,
            longitude = 29.5133,
            address = "Altay Caddesi, İnegöl / Bursa",
            sourceLabel = "İşletmenin resmî tarihçesi",
            sourceUrl = "https://www.besler1893.com/",
            mapQuery = "Besler 1893 İnegöl Köftecisi"
        ),
        VerifiedFoodVenue(
            province = "Bursa",
            localities = setOf("bursa", "osmangazi", "kayhan"),
            kinds = setOf(FoodKind.KEBAB),
            name = "Kebapçı İskender — Tarihi Mavi Dükkân — 1867",
            foundedYear = 1867,
            specialty = "Bursa kebabı / İskender kebap",
            latitude = 40.1833214,
            longitude = 29.0653209,
            address = "Atatürk Caddesi No:60, Osmangazi / Bursa",
            sourceLabel = "Kebapçı İskender resmî tarihçesi",
            sourceUrl = "https://www.iskender.com.tr/iskenderin-tarihi.html",
            mapQuery = "Tarihi Mavi Dükkan İskender 1867 Bursa"
        ),
        VerifiedFoodVenue(
            province = "Bursa",
            localities = setOf("bursa", "osmangazi", "kayhan"),
            kinds = setOf(FoodKind.PIDE),
            name = "Acı Dayı Cantık Salonu — 1959",
            foundedYear = 1959,
            specialty = "Bursa cantığı ve pide",
            latitude = 40.1827,
            longitude = 29.0712,
            address = "Kayhan Çarşısı, Boğaz Sokak, Osmangazi / Bursa",
            sourceLabel = "100 Tarihi Lokanta işletme tarihçesi",
            sourceUrl = "https://www.100tarihilokanta.com/aci-dayi-cantik-salonu/",
            mapQuery = "Acı Dayı Cantık Salonu Bursa"
        ),
        VerifiedFoodVenue(
            province = "Şanlıurfa",
            localities = setOf("sanliurfa", "urfa", "eyyubiye"),
            kinds = setOf(FoodKind.KEBAB),
            name = "Şark Kebap — 1959",
            foundedYear = 1959,
            specialty = "Urfa kebabı, patlıcanlı, domatesli, soğanlı ve keme kebabı",
            latitude = 37.1509,
            longitude = 38.7898,
            address = "Göl Caddesi, 1232. Sokak No:4, Eyyübiye / Şanlıurfa",
            sourceLabel = "100 Tarihi Lokanta işletme tarihçesi",
            sourceUrl = "https://www.100tarihilokanta.com/sark-kebap/",
            mapQuery = "Şark Kebap Şanlıurfa"
        ),
        VerifiedFoodVenue(
            province = "İzmir",
            localities = setOf("izmir", "odemiş", "odemiş merkez"),
            kinds = setOf(FoodKind.PIDE),
            name = "Meşhur Tarihi Töngül Pide Fırını — 1893",
            foundedYear = 1893,
            specialty = "Ödemiş usulü kıymalı pide",
            latitude = 38.2278,
            longitude = 27.9695,
            address = "Meşrutiyet Mahallesi, Ödemiş / İzmir",
            sourceLabel = "Ege'de Sonsöz ve Visit İzmir tarihçe kaydı",
            sourceUrl = "https://www.egedesonsoz.com/foto-galeri/izmir-in-128-yillik-lezzeti-tongul-pide",
            mapQuery = "Tarihi Töngül Pide Fırını Ödemiş"
        ),
        VerifiedFoodVenue(
            province = "İzmir",
            localities = setOf("izmir", "selcuk", "efes"),
            kinds = setOf(FoodKind.KOFTE),
            name = "Selçuk Köftecisi — 1959",
            foundedYear = 1959,
            specialty = "Izgara köfte ve Selçuk usulü yerel yemekler",
            latitude = 37.9499,
            longitude = 27.3697,
            address = "Atatürk Mahallesi, Şehabettin Dede Caddesi No:10, Selçuk / İzmir",
            sourceLabel = "100 Tarihi Lokanta işletme tarihçesi",
            sourceUrl = "https://www.100tarihilokanta.com/selcuk-koftecisi/",
            mapQuery = "Selçuk Köftecisi İzmir"
        ),
        VerifiedFoodVenue(
            province = "Mersin",
            localities = setOf("mersin", "tarsus"),
            kinds = setOf(FoodKind.KEBAB),
            name = "Kebapçı Eyüp — 1918",
            foundedYear = 1918,
            specialty = "Tarsus kebabı",
            latitude = 36.9177,
            longitude = 34.8928,
            address = "Tarsus / Mersin",
            sourceLabel = "100 Tarihi Lokanta işletme tarihçesi",
            sourceUrl = "https://www.100tarihilokanta.com/kebapci-eyup/",
            mapQuery = "Kebapçı Eyüp Tarsus"
        ),
        VerifiedFoodVenue(
            province = "Isparta",
            localities = setOf("isparta"),
            kinds = setOf(FoodKind.KEBAB, FoodKind.PIDE, FoodKind.KOFTE),
            name = "Hacıbenlioğlu Kebap — yaklaşık 1833",
            foundedYear = 1833,
            specialty = "Isparta kebabı, pide, şiş köfte ve kabune pilavı",
            latitude = 37.7648,
            longitude = 30.5566,
            address = "Isparta Merkez / Isparta",
            sourceLabel = "100 Tarihi Lokanta işletme tarihçesi",
            sourceUrl = "https://www.100tarihilokanta.com/hacibenlioglu-kebap/",
            mapQuery = "Hacıbenlioğlu Kebap Isparta"
        ),
        VerifiedFoodVenue(
            province = "Konya",
            localities = setOf("konya", "karatay", "meram"),
            kinds = setOf(FoodKind.KEBAB),
            name = "Hacı Şükrü — 1907",
            foundedYear = 1907,
            specialty = "Konya fırın kebabı",
            latitude = 37.8715,
            longitude = 32.4932,
            address = "Konya Merkez / Konya",
            sourceLabel = "100 Tarihi Lokanta işletme tarihçesi",
            sourceUrl = "https://www.100tarihilokanta.com/haci-sukru/",
            mapQuery = "Hacı Şükrü Konya"
        ),
        VerifiedFoodVenue(
            province = "Gaziantep",
            localities = setOf("gaziantep", "antep", "sahinbey"),
            kinds = setOf(FoodKind.KEBAB),
            name = "İmam Çağdaş — 1887",
            foundedYear = 1887,
            specialty = "Gaziantep kebapları ve baklava",
            latitude = 37.0628,
            longitude = 37.3828,
            address = "Şahinbey / Gaziantep",
            sourceLabel = "100 Tarihi Lokanta işletme tarihçesi",
            sourceUrl = "https://www.100tarihilokanta.com/imam-cagdas/",
            mapQuery = "İmam Çağdaş Gaziantep"
        ),
        VerifiedFoodVenue(
            province = "Adana",
            localities = setOf("adana", "seyhan"),
            kinds = setOf(FoodKind.KEBAB),
            name = "Hasan Kolcuoğlu — 1910",
            foundedYear = 1910,
            specialty = "Adana kebabı",
            latitude = 37.0000,
            longitude = 35.3213,
            address = "Seyhan / Adana",
            sourceLabel = "100 Tarihi Lokanta işletme tarihçesi",
            sourceUrl = "https://www.100tarihilokanta.com/hasan-kolcuoglu-restaurant/",
            mapQuery = "Hasan Kolcuoğlu Adana"
        ),
        VerifiedFoodVenue(
            province = "İstanbul",
            localities = setOf("istanbul", "fatih", "sirkeci"),
            kinds = setOf(FoodKind.KOFTE),
            name = "Filibe Köftecisi — 1893",
            foundedYear = 1893,
            specialty = "Filibe usulü ızgara köfte",
            latitude = 41.0148,
            longitude = 28.9750,
            address = "Sirkeci, Fatih / İstanbul",
            sourceLabel = "100 Tarihi Lokanta işletme tarihçesi",
            sourceUrl = "https://www.100tarihilokanta.com/filibe-koftecisi/",
            mapQuery = "Filibe Köftecisi Sirkeci"
        ),
        VerifiedFoodVenue(
            province = "Zonguldak",
            localities = setOf("zonguldak", "eregli", "karadeniz eregli"),
            kinds = setOf(FoodKind.PIDE),
            name = "Meşhur Pideci Hasan — 1936",
            foundedYear = 1936,
            specialty = "Karadeniz Ereğli pidesi",
            latitude = 41.2797,
            longitude = 31.4202,
            address = "Karadeniz Ereğli / Zonguldak",
            sourceLabel = "100 Tarihi Lokanta işletme tarihçesi",
            sourceUrl = "https://www.100tarihilokanta.com/meshur-pideci-hasan/",
            mapQuery = "Meşhur Pideci Hasan Karadeniz Ereğli"
        ),
        VerifiedFoodVenue(
            province = "Antalya",
            localities = setOf("antalya", "muratpasa"),
            kinds = setOf(FoodKind.KEBAB, FoodKind.KOFTE),
            name = "Topçu Kebap — 1885",
            foundedYear = 1885,
            specialty = "Antalya şiş köftesi, piyaz, kuzu şiş ve döner",
            latitude = 36.8879,
            longitude = 30.7056,
            address = "Kazım Özalp Caddesi No:21, Antalya",
            sourceLabel = "100 Tarihi Lokanta işletme tarihçesi",
            sourceUrl = "https://www.100tarihilokanta.com/topcu-kebap/",
            mapQuery = "Topçu Kebap Antalya"
        ),
        VerifiedFoodVenue(
            province = "Manisa",
            localities = setOf("manisa", "sehzadeler"),
            kinds = setOf(FoodKind.KEBAB),
            name = "Gülcemal Manisa Kebapçısı — 1957",
            foundedYear = 1957,
            specialty = "Tereyağlı Manisa kebabı",
            latitude = 38.6140,
            longitude = 27.4296,
            address = "1. Anafartalar Mahallesi, 1603 Sokak No:3, Şehzadeler / Manisa",
            sourceLabel = "100 Tarihi Lokanta işletme tarihçesi",
            sourceUrl = "https://www.100tarihilokanta.com/gulcemal-manisa-kebapcisi/",
            mapQuery = "Gülcemal Manisa Kebapçısı"
        ),
        VerifiedFoodVenue(
            province = "Manisa",
            localities = setOf("manisa", "salihli"),
            kinds = setOf(FoodKind.KOFTE),
            name = "Azaklar Odun Köfte — 1911",
            foundedYear = 1911,
            specialty = "Salihli odun köftesi",
            latitude = 38.4826,
            longitude = 28.1386,
            address = "Belediye Caddesi No:113, Salihli / Manisa",
            sourceLabel = "100 Tarihi Lokanta işletme tarihçesi",
            sourceUrl = "https://www.100tarihilokanta.com/azaklar-odun-kofte-1911/",
            mapQuery = "Azaklar Odun Köfte Salihli"
        ),
        VerifiedFoodVenue(
            province = "İstanbul",
            localities = setOf("istanbul", "fatih", "sultanahmet"),
            kinds = setOf(FoodKind.KOFTE),
            name = "Tarihi Sultanahmet Köftecisi — 1920",
            foundedYear = 1920,
            specialty = "Sultanahmet köftesi",
            latitude = 41.0077,
            longitude = 28.9768,
            address = "Sultanahmet, Fatih / İstanbul",
            sourceLabel = "100 Tarihi Lokanta işletme tarihçesi",
            sourceUrl = "https://www.100tarihilokanta.com/tarihi-sultanahmet-koftecisi/",
            mapQuery = "Tarihi Sultanahmet Köftecisi"
        ),
        VerifiedFoodVenue(
            province = "İstanbul",
            localities = setOf("istanbul", "fatih"),
            kinds = setOf(FoodKind.KEBAB, FoodKind.PIDE),
            name = "Öz Kilis Kebap — 1953",
            foundedYear = 1953,
            specialty = "İnce lahmacun, oruk kebabı, Kilis tava ve yöresel Kilis yemekleri",
            latitude = 41.0187,
            longitude = 28.9436,
            address = "Hırka-i Şerif Caddesi, Bedrettin Simavi Sokak No:5, Fatih / İstanbul",
            sourceLabel = "100 Tarihi Lokanta işletme tarihçesi",
            sourceUrl = "https://www.100tarihilokanta.com/oz-kilis-kebap/",
            mapQuery = "Öz Kilis Kebap Fatih"
        ),
        VerifiedFoodVenue(
            province = "Edirne",
            localities = setOf("edirne"),
            kinds = setOf(FoodKind.KEBAB),
            name = "Meşhur Edirne Ciğercisi — 1964",
            foundedYear = 1964,
            specialty = "Edirne yaprak ciğeri",
            latitude = 41.6771,
            longitude = 26.5557,
            address = "Balıkpazarı, Osmaniye Caddesi No:43, Edirne",
            sourceLabel = "100 Tarihi Lokanta işletme tarihçesi",
            sourceUrl = "https://www.100tarihilokanta.com/meshur-edirne-cigercisi/",
            mapQuery = "Meşhur Edirne Ciğercisi Kazım ve İlhan Usta"
        ),
        VerifiedFoodVenue(
            province = "Bursa",
            localities = setOf("bursa", "osmangazi", "ivazpasa"),
            kinds = setOf(FoodKind.KOFTE),
            name = "Üç Köfte — 1930",
            foundedYear = 1930,
            specialty = "Bursa usulü ızgara köfte ve piyaz",
            latitude = 40.1820,
            longitude = 29.0615,
            address = "İvazpaşa Kapalı Çarşısı No:3, Bursa",
            sourceLabel = "100 Tarihi Lokanta işletme tarihçesi",
            sourceUrl = "https://www.100tarihilokanta.com/uc-kofte/",
            mapQuery = "Üç Köfte Bursa"
        )
    )

    private val guideVenues = listOf(
        GuideVenue(
            regionKeys = setOf("marmaris"),
            name = "Denizkızı Restoran (Muhammed'in Yeri)",
            cuisine = "Balık ve deniz ürünü",
            whatToEat = "Ne yenir: Balık, ahtapot, kalamar ve deniz ürünleri; güncel menüyü işletmeden doğrula.",
            sourceLabel = "Gurman Atlas / Vedat Milor onaylı mekan",
            economicNote = "Ekonomik filtre: Güncel fiyat açık kaynaktan doğrulanmadan ekonomik kabul edilmez; ana ekonomik yemek listesinden ayrı gösterilir.",
            mapQuery = "Denizkızı Restoran Muhammed'in Yeri Söğüt Marmaris",
            webQuery = "Gurman Atlas Denizkızı Restoran Muhammed'in Yeri Marmaris"
        ),
        GuideVenue(
            regionKeys = setOf("marmaris"),
            name = "Manzara Restaurant",
            cuisine = "Balık ve deniz ürünü",
            whatToEat = "Ne yenir: Balık, deniz ürünleri ve mezeler; güncel menü ile fiyatı gitmeden doğrula.",
            sourceLabel = "Gurman Atlas / Vedat Milor onaylı mekan",
            economicNote = "Ekonomik filtre: Fiyatı doğrulanmadığı için otomatik olarak uygun fiyatlı sayılmaz; yalnız meşhur mekan bilgisi olarak gösterilir.",
            mapQuery = "Manzara Restaurant Söğüt Marmaris",
            webQuery = "Gurman Atlas Manzara Restaurant Marmaris"
        )
    )

    fun legendResults(center: GeoPoint): List<PlaceItem> {
        val key = regionKey(center.name)
        return legends
            .filter { entry -> entry.regionKeys.any { matches(key, it) } }
            .mapIndexed { index, entry ->
                PlaceItem(
                    name = entry.name,
                    subtitle = entry.storyType,
                    latitude = center.latitude,
                    longitude = center.longitude,
                    category = PoiCategory.MYSTERY,
                    priority = index,
                    note = entry.summary,
                    details = listOf(
                        "Kaynak durumu: ${entry.sourceStatus}",
                        "Bölge kilidi: ${center.name}",
                        "Bilinen tarih, yerel anlatı ve modern söylenti ayrı değerlendirilir"
                    ),
                    mapSearchQuery = entry.mapQuery
                )
            }
            .distinctBy { it.name.lowercase(tr) }
    }

    fun featuredFoodResults(center: GeoPoint, kind: FoodKind): List<PlaceItem> {
        if (kind == FoodKind.ESNAF || kind == FoodKind.SULU || kind == FoodKind.ALL) return emptyList()
        return matchedVerifiedVenues(center, kind)
            .take(2)
            .map { match ->
                val venue = match.venue
                val scope = when {
                    match.localityMatch -> "Seçilen ilçe/merkezle doğrudan eşleşiyor"
                    match.provinceWideMatch -> "İl genelindeki doğrulanmış köklü seçenek"
                    else -> "Seçilen merkeze yakın doğrulanmış seçenek"
                }
                PlaceItem(
                    name = venue.name,
                    subtitle = "Doğrulanmış köklü / meşhur işletme",
                    latitude = venue.latitude,
                    longitude = venue.longitude,
                    category = PoiCategory.FOOD,
                    priority = -200,
                    note = "Kuruluş yılı ve işletme geçmişi kaynakla doğrulanmıştır. Canlı popülerlik veya şube sayısı bu sıralamayı belirlemez.",
                    details = listOf(
                        "Seçilen buton: ${kind.title}",
                        "Kuruluş: ${venue.foundedYear}",
                        "Öne çıkan lezzet: ${venue.specialty}",
                        "Mesafe: ${String.format(tr, "%.1f km", match.distanceKm)}",
                        "Kapsam: $scope",
                        "Adres: ${venue.address}",
                        "Kaynak: ${venue.sourceLabel}",
                        "Doğrulama durumu: Kuruluş yılı kayıtlı"
                    ),
                    mapSearchQuery = venue.mapQuery,
                    webSearchQuery = venue.sourceUrl
                )
            }
    }

    fun localFlavorResults(center: GeoPoint): List<PlaceItem> {
        val key = regionKey(center.name)
        val scoredProfiles = flavors.mapNotNull { profile ->
            val score = profile.regionKeys
                .filter { matches(key, it) }
                .maxOfOrNull { regionKey(it).length }
            score?.let { profile to it }
        }
        val bestScore = scoredProfiles.maxOfOrNull { it.second }
        val matching = scoredProfiles
            .filter { bestScore != null && it.second == bestScore }
            .map { it.first }
        val profileCards = if (matching.isEmpty()) {
            TurkeyFlavorProfiles.forCenter(center)?.let { profile ->
                listOf(
                    PlaceItem(
                        name = "Yörenin imza lezzeti: ${profile.dishes}",
                        subtitle = "81 il geneli yöresel lezzet profili",
                        latitude = center.latitude,
                        longitude = center.longitude,
                        category = PoiCategory.FOOD,
                        priority = 0,
                        note = "${profile.province} ile yaygın biçimde ilişkilendirilen lezzetlerdir. İşletme için en eski/meşhur iddiası ayrıca kaynak ve kuruluş yılıyla doğrulanır.",
                        details = listOf(
                            "İl kilidi: ${profile.province}",
                            "Aranan merkez: ${center.name}",
                            "Popüler zincirler köklü/meşhur diye öne çıkarılmaz",
                            "Doğrulanmış tarihî işletme yoksa sahte kuruluş yılı gösterilmez"
                        ),
                        isSearchCard = true
                    )
                )
            }.orEmpty()
        } else matching.flatMapIndexed { index, profile ->
            buildList {
                add(
                    PlaceItem(
                        name = "Yörenin imza lezzeti: ${profile.dish}",
                        subtitle = "Yöresel lezzet önerisi",
                        latitude = center.latitude,
                        longitude = center.longitude,
                        category = PoiCategory.FOOD,
                        priority = index,
                        note = profile.reason,
                        details = listOf(
                            "Seçim ölçütü: Yöreyle güçlü biçimde ilişkilendirilen lezzet",
                            "Bölge kilidi: ${center.name}",
                            "En eski/meşhur işletme iddiası kaynak ve kuruluş yılıyla doğrulanır",
                            "Ekonomik alternatif için aile/esnaf işletmeleri öne alınır"
                        ),
                        isSearchCard = true
                    )
                )
                if (!profile.candidateName.isNullOrBlank() && !profile.candidateQuery.isNullOrBlank()) {
                    add(
                        PlaceItem(
                            name = profile.candidateName,
                            subtitle = "Köklü işletme araştırma adayı",
                            latitude = center.latitude,
                            longitude = center.longitude,
                            category = PoiCategory.FOOD,
                            priority = index + 10,
                            note = "Bu işletmenin ‘en eski’ veya ‘en meşhur’ olduğu otomatik kabul edilmez; kuruluş yılı ve bağımsız kaynaklar açılarak doğrulanır.",
                            details = listOf(
                                "Kullanıcı örneği ve araştırma adayı",
                                "Güncel fiyat, açık olma durumu ve şube bilgisi haritada kontrol edilir"
                            ),
                            mapSearchQuery = "${profile.candidateName.substringBefore('—').trim()} ${center.name}"
                        )
                    )
                }
            }
        }

        val verifiedVenueCards = matchedVerifiedVenues(center, null)
            .take(2)
            .map { match ->
                val venue = match.venue
                PlaceItem(
                    name = venue.name,
                    subtitle = "Kaynakla doğrulanmış köklü yöresel işletme",
                    latitude = venue.latitude,
                    longitude = venue.longitude,
                    category = PoiCategory.FOOD,
                    priority = -100,
                    note = "Bu işletme canlı popülerlik sıralamasıyla değil, kuruluş yılı ve tarihçe kaydıyla öne çıkar.",
                    details = listOf(
                        "Kuruluş: ${venue.foundedYear}",
                        "Ne yenir: ${venue.specialty}",
                        "Mesafe: ${String.format(tr, "%.1f km", match.distanceKm)}",
                        "Adres: ${venue.address}",
                        "Kaynak: ${venue.sourceLabel}"
                    ),
                    mapSearchQuery = venue.mapQuery,
                    webSearchQuery = venue.sourceUrl
                )
            }

        // Rehber/yazar önerileri ve genel restoranlar yöresel lezzet sonucuna
        // otomatik eklenmez. Çünkü pahalı olabilir veya bölgenin imza yemeğini
        // temsil etmeyebilir. Bu ekran yalnız imza lezzet ve kaynakla doğrulanmış
        // köklü/meşhur işletmeleri gösterir.
        return (profileCards + verifiedVenueCards).distinctBy { it.name.lowercase(tr) }
    }

    private fun matchedVerifiedVenues(center: GeoPoint, kind: FoodKind?): List<MatchedVerifiedVenue> {
        val targetProvince = center.province?.takeIf { it.isNotBlank() }
            ?: TurkeyRegions.resolveProvince(center.name, center.latitude, center.longitude)
            ?: return emptyList()
        val targetProvinceKey = regionKey(targetProvince)
        val centerKey = regionKey(center.name)
        val provinceWide = TurkeyRegions.isProvinceCenter(center)

        return verifiedFoodVenues
            .asSequence()
            .filter { venue -> kind == null || kind in venue.kinds }
            .filter { venue -> regionKey(venue.province) == targetProvinceKey }
            .map { venue ->
                val localityMatch = venue.localities.any { locality -> matches(centerKey, locality) }
                val distance = distanceKm(center.latitude, center.longitude, venue.latitude, venue.longitude)
                MatchedVerifiedVenue(
                    venue = venue,
                    distanceKm = distance,
                    localityMatch = localityMatch,
                    provinceWideMatch = provinceWide
                )
            }
            .filter { match ->
                match.provinceWideMatch || match.localityMatch || match.distanceKm <= 55.0
            }
            .sortedWith(
                compareByDescending<MatchedVerifiedVenue> { it.localityMatch }
                    .thenBy { it.venue.foundedYear }
                    .thenBy { it.distanceKm }
                    .thenBy { it.venue.name }
            )
            .toList()
    }

    private fun distanceKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val earth = 6371.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2) * sin(dLat / 2) +
            cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) *
            sin(dLon / 2) * sin(dLon / 2)
        return 2 * earth * asin(sqrt(a.coerceIn(0.0, 1.0)))
    }

    private fun regionKey(value: String): String = value
        .lowercase(tr)
        .replace('ı', 'i')
        .replace('ğ', 'g')
        .replace('ü', 'u')
        .replace('ş', 's')
        .replace('ö', 'o')
        .replace('ç', 'c')
        .replace(Regex("[^a-z0-9]+"), " ")
        .trim()

    private fun matches(centerKey: String, regionKey: String): Boolean {
        val target = regionKey(regionKey)
        return centerKey == target || centerKey.contains(target) || target.contains(centerKey)
    }
}
