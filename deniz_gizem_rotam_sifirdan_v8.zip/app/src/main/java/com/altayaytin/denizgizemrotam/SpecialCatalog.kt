package com.altayaytin.denizgizemrotamsifir

import java.util.Locale

/**
 * V20 özel araştırma katmanı.
 *
 * Bilinen bölgesel başlıkları hemen gösterir. Canlı Türkçe kaynak özetleri ve
 * ekonomik işletme sonuçları ApiService tarafından uygulamanın içinde eklenir.
 */
internal object SpecialCatalog {
    private val tr = Locale("tr", "TR")

    private data class LegendEntry(
        val regionKeys: Set<String>,
        val name: String,
        val storyType: String,
        val summary: String,
        val sourceStatus: String,
        val mapQuery: String,
        val webQuery: String
    )

    private data class FlavorProfile(
        val regionKeys: Set<String>,
        val dish: String,
        val reason: String,
        val mapQuery: String,
        val webQuery: String,
        val candidateName: String? = null,
        val candidateQuery: String? = null
    )


    private data class GuideVenue(
        val regionKeys: Set<String>,
        val name: String,
        val cuisine: String,
        val whatToEat: String,
        val sourceLabel: String,
        val economicNote: String,
        val mapQuery: String,
        val webQuery: String
    )

    private val legends = listOf(
        LegendEntry(
            setOf("tarsus", "mersin"),
            "Şahmeran anlatısı",
            "Yerel efsane",
            "Tarsus çevresinde yüzyıllardır anlatılan yarı insan yarı yılan bilge varlık hikâyesi.",
            "Sözlü gelenek ve ikincil kaynaklar; tarihî olay olarak sunulmaz.",
            "Şahmeran Tarsus",
            "Tarsus Şahmeran efsanesi yerel kaynaklar"
        ),
        LegendEntry(
            setOf("tarsus", "mersin"),
            "Eshab-ı Kehf / Yedi Uyurlar rivayeti",
            "Dinî ve tarihî rivayet",
            "Uzun süre mağarada uyuyan gençlere ilişkin anlatının Tarsus çevresindeki yerel varyantı.",
            "Farklı şehirler aynı anlatıyla ilişkilendirilir; yerel iddia kaynaklardan karşılaştırılmalıdır.",
            "Eshab-ı Kehf Tarsus",
            "Eshab-ı Kehf Tarsus rivayeti kaynak"
        ),
        LegendEntry(
            setOf("kizkalesi", "mersin", "erdemli"),
            "Kızkalesi ve yılanlı prenses efsanesi",
            "Yerel efsane",
            "Kehanetten kaçınmak için adaya kapatılan prenses ve sepette gelen yılan anlatısı.",
            "Yerel efsane; kale tarihinden ayrı değerlendirilmelidir.",
            "Kızkalesi Mersin",
            "Kızkalesi yılanlı prenses efsanesi kaynak"
        ),
        LegendEntry(
            setOf("efes", "selcuk", "izmir"),
            "Efes Yedi Uyurlar anlatısı",
            "Dinî ve tarihî rivayet",
            "Mağarada uzun süre uyuyan gençlere bağlanan Efes varyantı.",
            "Dinî gelenek ve yerel rivayet; farklı coğrafyalarda başka yerlerle de ilişkilendirilir.",
            "Yedi Uyurlar Mağarası Efes",
            "Efes Yedi Uyurlar rivayeti kaynak"
        ),
        LegendEntry(
            setOf("bodrum"),
            "Salmakis ve Hermaphroditos anlatısı",
            "Antik mitolojik anlatı",
            "Halikarnassos çevresiyle ilişkilendirilen Salmakis pınarı ve dönüşüm miti.",
            "Antik edebî anlatı; modern yerel söylentilerden ayrı tutulmalıdır.",
            "Salmakis Bodrum",
            "Salmakis Hermaphroditos Halikarnassos antik kaynak"
        ),
        LegendEntry(
            setOf("kiyikislacik", "iasos", "milas"),
            "İasoslu çocuk ve yunus anlatısı",
            "Antik anlatı",
            "İasos ile ilişkilendirilen çocuk ve yunus dostluğu hikâyesinin antik aktarımları.",
            "Antik yazarların aktardığı anlatı olarak araştırılmalı; modern süslemelerden ayrılmalıdır.",
            "İasos Antik Kenti Kıyıkışlacık",
            "İasos çocuk yunus Hermias antik anlatı kaynak"
        ),
        LegendEntry(
            setOf("didim", "didyma"),
            "Didyma kehanet anlatıları",
            "Antik din ve mitoloji",
            "Apollon kutsal alanındaki kehanet geleneği çevresinde oluşan tarihî ve mitolojik anlatılar.",
            "Arkeolojik bilgi, antik metin ve modern söylenti ayrı başlıklarla karşılaştırılmalıdır.",
            "Didyma Apollon Tapınağı",
            "Didyma Apollon kehanetleri antik kaynak"
        ),
        LegendEntry(
            setOf("fethiye", "kayakoy"),
            "Kayaköy hakkında modern paranormal söylentiler",
            "Modern söylenti",
            "Terk edilmiş yerleşim görünümü çevresinde oluşan hayaletli veya uğursuz yer anlatıları.",
            "Modern internet ve ziyaretçi söylentileri; tarihî nüfus mübadelesi gerçeğiyle karıştırılmamalıdır.",
            "Kayaköy Fethiye",
            "Kayaköy hayalet söylentileri yerel anlatı tarih"
        ),
        LegendEntry(
            setOf("kas", "kekova", "demre"),
            "Kekova batık kent anlatıları",
            "Yerel söylenti ve tarihî anlatı",
            "Su altındaki kalıntılar çevresinde oluşan kayıp şehir ve afet hikâyeleri.",
            "Arkeolojik veriler ile yerel söylentiler ayrı kaynaklardan kontrol edilmelidir.",
            "Kekova Batık Şehir",
            "Kekova batık şehir efsaneleri arkeolojik kaynak"
        )
    )

    private val flavors = listOf(
        FlavorProfile(
            setOf("inegol"),
            "İnegöl köftesi",
            "İnegöl’ün imza yemeği olarak bilinen köfte geleneği.",
            "uygun fiyatlı İnegöl köftesi İnegöl",
            "İnegöl köftesi tarihi en eski köfteci kuruluş yılı",
            candidateName = "Besler Köftecisi — köklü/meşhur aday",
            candidateQuery = "Besler Köftecisi İnegöl kuruluş yılı tarihçe"
        ),
        FlavorProfile(
            setOf("bursa"),
            "İskender kebap, pideli köfte ve cantık",
            "Bursa mutfağının en çok aranan sıcak yemekleri.",
            "uygun fiyatlı Bursa pideli köfte cantık esnaf lokantası",
            "Bursa en eski meşhur pideli köfte cantık lokantası tarihçe"
        ),
        FlavorProfile(
            setOf("balikesir", "erdek"),
            "Balıkesir köftesi ve yerel esnaf yemekleri",
            "Bölgenin köfte ve ev yemeği geleneğini ekonomik lokantalarda araştırır.",
            "uygun fiyatlı Balıkesir köftesi esnaf lokantası",
            "Balıkesir en eski meşhur köfteci yöresel yemek"
        ),
        FlavorProfile(
            setOf("ayvalik"),
            "Ayvalık tostu ve yerel Ege yemekleri",
            "Ayvalık’ın bilinen sokak lezzeti ile zeytinyağlı yerel yemekleri.",
            "uygun fiyatlı Ayvalık tostu esnaf lokantası",
            "Ayvalık en eski meşhur tostçu yerel lokanta"
        ),
        FlavorProfile(
            setOf("izmir", "cesme", "alacati", "foca", "seferihisar", "sigacik"),
            "Boyoz, kumru, söğüş ve Ege otları",
            "İzmir çevresinin öne çıkan yöresel lezzetleri.",
            "uygun fiyatlı yöresel İzmir kumru söğüş esnaf lokantası",
            "İzmir en eski meşhur kumrucu söğüşçü boyozcu tarihçe"
        ),
        FlavorProfile(
            setOf("aydin", "kusadasi", "didim"),
            "Aydın pidesi ve Çine köftesi",
            "Aydın ilinin pide ve köfte geleneği; turistik zincir yerine yerel işletme aranır.",
            "uygun fiyatlı Aydın pidesi Çine köftesi esnaf lokantası",
            "Aydın en eski meşhur pideci Çine köfteci"
        ),
        FlavorProfile(
            setOf("milas", "kiyikislacik", "iasos"),
            "Milas köftesi ve Çökertme kebabı",
            "Milas ve çevresinde aranabilecek yerel sıcak yemekler.",
            "uygun fiyatlı Milas köftesi Çökertme kebabı Kıyıkışlacık",
            "Milas en eski meşhur köfteci Çökertme kebabı lokantası"
        ),
        FlavorProfile(
            setOf("bodrum"),
            "Çökertme kebabı ve Bodrum usulü yerel yemekler",
            "Pahalı sahil restoranları yerine merkez ve mahallelerdeki ekonomik yerel lokantalar aranır.",
            "uygun fiyatlı Çökertme kebabı Bodrum esnaf lokantası",
            "Bodrum en eski meşhur yerel lokanta Çökertme kebabı"
        ),
        FlavorProfile(
            setOf("mugla", "marmaris", "datca", "akyaka", "fethiye", "dalyan"),
            "Muğla köftesi, Çökertme kebabı ve yerel ev yemekleri",
            "Muğla çevresinin sıcak yemeklerini ekonomik aile işletmelerinde araştırır.",
            "uygun fiyatlı Muğla köftesi Çökertme kebabı esnaf lokantası",
            "Muğla en eski meşhur yöresel lokanta"
        ),
        FlavorProfile(
            setOf("antalya", "kas", "kalkan", "side"),
            "Antalya piyazı ve şiş köfte",
            "Antalya mutfağının en bilinen ikilisini ekonomik köfteci ve esnaf lokantalarında arar.",
            "uygun fiyatlı Antalya piyazı şiş köfte esnaf lokantası",
            "Antalya en eski meşhur piyazcı şiş köfteci"
        ),
        FlavorProfile(
            setOf("mersin", "tarsus"),
            "Tantuni, Tarsus humusu ve kebap",
            "Mersin–Tarsus hattının bilinen sıcak yemekleri.",
            "uygun fiyatlı tantuni Tarsus humusu kebap esnaf lokantası",
            "Mersin Tarsus en eski meşhur tantunici humusçu"
        ),
        FlavorProfile(
            setOf("adana"),
            "Adana kebabı ve ciğer",
            "Şehrin imza lezzetlerini ekonomik ocakbaşı ve kebapçılarda araştırır.",
            "uygun fiyatlı Adana kebabı ciğer esnaf kebapçı",
            "Adana en eski meşhur kebapçı kuruluş yılı"
        ),
        FlavorProfile(
            setOf("hatay", "antakya"),
            "Tepsi kebabı ve Antakya ev yemekleri",
            "Hatay mutfağının sıcak yemeklerini aile ve esnaf işletmelerinde araştırır.",
            "uygun fiyatlı Hatay tepsi kebabı Antakya esnaf lokantası",
            "Antakya en eski meşhur tepsi kebabı lokantası"
        ),
        FlavorProfile(
            setOf("gaziantep", "antep"),
            "Beyran, kebap ve yuvalama",
            "Gaziantep’in öne çıkan sıcak yemeklerini yerel ve ekonomik işletmelerde araştırır.",
            "uygun fiyatlı Gaziantep beyran kebap esnaf lokantası",
            "Gaziantep en eski meşhur beyrancı kebapçı"
        )
    )

    private val guideVenues = listOf(
        GuideVenue(
            regionKeys = setOf("marmaris"),
            name = "Denizkızı Restoran (Muhammed'in Yeri)",
            cuisine = "Balık ve deniz ürünü",
            whatToEat = "Ne yenir: Balık, ahtapot, kalamar ve deniz ürünleri; güncel menüyü işletmeden doğrula.",
            sourceLabel = "Gurman Atlas / Vedat Milor onaylı mekan",
            economicNote = "Ekonomik filtre: Güncel fiyat açık kaynaktan doğrulanmadan ekonomik kabul edilmez; ana ekonomik yemek listesinden ayrı gösterilir.",
            mapQuery = "Denizkızı Restoran Muhammed'in Yeri Söğüt Marmaris",
            webQuery = "Gurman Atlas Denizkızı Restoran Muhammed'in Yeri Marmaris"
        ),
        GuideVenue(
            regionKeys = setOf("marmaris"),
            name = "Manzara Restaurant",
            cuisine = "Balık ve deniz ürünü",
            whatToEat = "Ne yenir: Balık, deniz ürünleri ve mezeler; güncel menü ile fiyatı gitmeden doğrula.",
            sourceLabel = "Gurman Atlas / Vedat Milor onaylı mekan",
            economicNote = "Ekonomik filtre: Fiyatı doğrulanmadığı için otomatik olarak uygun fiyatlı sayılmaz; yalnız meşhur mekan bilgisi olarak gösterilir.",
            mapQuery = "Manzara Restaurant Söğüt Marmaris",
            webQuery = "Gurman Atlas Manzara Restaurant Marmaris"
        )
    )

    fun legendResults(center: GeoPoint): List<PlaceItem> {
        val key = regionKey(center.name)
        return legends
            .filter { entry -> entry.regionKeys.any { matches(key, it) } }
            .mapIndexed { index, entry ->
                PlaceItem(
                    name = entry.name,
                    subtitle = entry.storyType,
                    latitude = center.latitude,
                    longitude = center.longitude,
                    category = PoiCategory.MYSTERY,
                    priority = index,
                    note = entry.summary,
                    details = listOf(
                        "Kaynak durumu: ${entry.sourceStatus}",
                        "Bölge kilidi: ${center.name}",
                        "Bilinen tarih, yerel anlatı ve modern söylenti ayrı değerlendirilir"
                    ),
                    mapSearchQuery = entry.mapQuery
                )
            }
            .distinctBy { it.name.lowercase(tr) }
    }

    fun featuredFoodResults(center: GeoPoint, kind: FoodKind): List<PlaceItem> {
        if (kind == FoodKind.ESNAF || kind == FoodKind.SULU || kind == FoodKind.ALL) return emptyList()
        val key = regionKey(center.name)
        val scoredProfiles = flavors.mapNotNull { profile ->
            val score = profile.regionKeys
                .filter { matches(key, it) }
                .maxOfOrNull { regionKey(it).length }
            score?.let { profile to it }
        }
        val bestScore = scoredProfiles.maxOfOrNull { it.second } ?: return emptyList()
        return scoredProfiles
            .filter { it.second == bestScore }
            .map { it.first }
            .filter { profile ->
                val dishKey = regionKey(profile.dish)
                when (kind) {
                    FoodKind.PIDE -> "pide" in dishKey || "lahmacun" in dishKey || "cantik" in dishKey
                    FoodKind.KOFTE -> "kofte" in dishKey
                    FoodKind.KEBAB -> "kebap" in dishKey || "kebab" in dishKey || "doner" in dishKey || "ciger" in dishKey
                    else -> false
                }
            }
            .mapNotNull { profile ->
                val candidate = profile.candidateName?.substringBefore('—')?.trim().orEmpty()
                if (candidate.isBlank()) return@mapNotNull null
                PlaceItem(
                    name = candidate,
                    subtitle = "Köklü / meşhur işletme adayı",
                    latitude = center.latitude,
                    longitude = center.longitude,
                    category = PoiCategory.FOOD,
                    priority = -100,
                    note = "Bu aday yöresel profil içinde öne çıkıyor. Kuruluş yılı ve ‘en eski’ iddiası doğrulanmadan kesin hüküm verilmez.",
                    details = listOf(
                        "Seçilen buton: ${kind.title}",
                        "Öne çıkan durum: Köklü / meşhur aday",
                        "Bölge: ${center.name}",
                        "Doğrulama: Kuruluş yılı ve bağımsız kaynak kaydı gerekli"
                    ),
                    mapSearchQuery = "$candidate ${center.name}"
                )
            }
            .distinctBy { it.name.lowercase(tr) }
            .take(2)
    }

    fun localFlavorResults(center: GeoPoint): List<PlaceItem> {
        val key = regionKey(center.name)
        val scoredProfiles = flavors.mapNotNull { profile ->
            val score = profile.regionKeys
                .filter { matches(key, it) }
                .maxOfOrNull { regionKey(it).length }
            score?.let { profile to it }
        }
        val bestScore = scoredProfiles.maxOfOrNull { it.second }
        val matching = scoredProfiles
            .filter { bestScore != null && it.second == bestScore }
            .map { it.first }
        val profileCards = if (matching.isEmpty()) {
            emptyList()
        } else matching.flatMapIndexed { index, profile ->
            buildList {
                add(
                    PlaceItem(
                        name = "Yörenin imza lezzeti: ${profile.dish}",
                        subtitle = "Yöresel lezzet önerisi",
                        latitude = center.latitude,
                        longitude = center.longitude,
                        category = PoiCategory.FOOD,
                        priority = index,
                        note = profile.reason,
                        details = listOf(
                            "Seçim ölçütü: Yöreyle güçlü biçimde ilişkilendirilen lezzet",
                            "Bölge kilidi: ${center.name}",
                            "En eski/meşhur işletme iddiası kaynak ve kuruluş yılıyla doğrulanır",
                            "Ekonomik alternatif için aile/esnaf işletmeleri öne alınır"
                        ),
                        isSearchCard = true
                    )
                )
                if (!profile.candidateName.isNullOrBlank() && !profile.candidateQuery.isNullOrBlank()) {
                    add(
                        PlaceItem(
                            name = profile.candidateName,
                            subtitle = "Köklü işletme araştırma adayı",
                            latitude = center.latitude,
                            longitude = center.longitude,
                            category = PoiCategory.FOOD,
                            priority = index + 10,
                            note = "Bu işletmenin ‘en eski’ veya ‘en meşhur’ olduğu otomatik kabul edilmez; kuruluş yılı ve bağımsız kaynaklar açılarak doğrulanır.",
                            details = listOf(
                                "Kullanıcı örneği ve araştırma adayı",
                                "Güncel fiyat, açık olma durumu ve şube bilgisi haritada kontrol edilir"
                            ),
                            mapSearchQuery = "${profile.candidateName.substringBefore('—').trim()} ${center.name}"
                        )
                    )
                }
            }
        }

        // Rehber/yazar önerileri ve genel restoranlar yöresel lezzet sonucuna
        // otomatik eklenmez. Çünkü pahalı olabilir veya bölgenin imza yemeğini
        // temsil etmeyebilir. Bu ekran yalnız imza lezzet ve doğrulanabilir
        // köklü/meşhur işletme adaylarını gösterir.
        // V16: Google/web arama kartları kaldırıldı. Uygulama içi canlı kaynak
        // sonuçları ApiService tarafından bu somut kartlara eklenir.
        return profileCards.distinctBy { it.name.lowercase(tr) }
    }

    private fun regionKey(value: String): String = value
        .lowercase(tr)
        .replace('ı', 'i')
        .replace('ğ', 'g')
        .replace('ü', 'u')
        .replace('ş', 's')
        .replace('ö', 'o')
        .replace('ç', 'c')
        .replace(Regex("[^a-z0-9]+"), " ")
        .trim()

    private fun matches(centerKey: String, regionKey: String): Boolean {
        val target = regionKey(regionKey)
        return centerKey == target || centerKey.contains(target) || target.contains(centerKey)
    }
}
